<?php
// visitor.php - Visitor Management
session_start();
include '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'student';

// Get user's student details
$student = null;
try {
    $stmt = $db->prepare("SELECT * FROM students WHERE user_id = ? OR id = ?");
    $stmt->execute([$user_id, $user_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

$student_id = $student['id'] ?? 0;

// Handle visitor registration
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_visitor'])) {
    $visitor_name = trim($_POST['visitor_name'] ?? '');
    $visitor_phone = trim($_POST['visitor_phone'] ?? '');
    $relation = trim($_POST['relation'] ?? '');
    $purpose = trim($_POST['purpose'] ?? '');
    $visit_date = $_POST['visit_date'] ?? date('Y-m-d');
    $entry_time = $_POST['entry_time'] ?? date('H:i');
    $id_proof_type = $_POST['id_proof_type'] ?? '';
    $id_proof_number = trim($_POST['id_proof_number'] ?? '');
    
    if (empty($visitor_name) || empty($visitor_phone) || empty($relation)) {
        $error = "Please fill in all required fields.";
    } else {
        try {
            $stmt = $db->prepare("
                INSERT INTO visitors 
                (student_id, visitor_name, visitor_phone, relation, purpose, visit_date, entry_time, status, id_proof_type, id_proof_number, created_by) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 'checked_in', ?, ?, ?)
            ");
            $stmt->execute([
                $student_id,
                $visitor_name,
                $visitor_phone,
                $relation,
                $purpose,
                $visit_date,
                $entry_time,
                $id_proof_type,
                $id_proof_number,
                $user_id
            ]);
            
            $message = "Visitor registered successfully! Visitor has been checked in.";
        } catch (PDOException $e) {
            $error = "Failed to register visitor: " . $e->getMessage();
        }
    }
}

// Handle check-out
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout_visitor'])) {
    $visitor_id = (int)($_POST['visitor_id'] ?? 0);
    
    if ($visitor_id > 0) {
        try {
            $stmt = $db->prepare("
                UPDATE visitors 
                SET status = 'checked_out', exit_time = NOW(), updated_at = NOW() 
                WHERE id = ? AND student_id = ?
            ");
            $stmt->execute([$visitor_id, $student_id]);
            
            $message = "Visitor checked out successfully.";
        } catch (PDOException $e) {
            $error = "Failed to check out visitor: " . $e->getMessage();
        }
    }
}

// Fetch today's visitors
$today_visitors = [];
try {
    $stmt = $db->prepare("
        SELECT * FROM visitors 
        WHERE student_id = ? AND visit_date = CURDATE()
        ORDER BY entry_time DESC
    ");
    $stmt->execute([$student_id]);
    $today_visitors = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch visitor history
$visitor_history = [];
try {
    $stmt = $db->prepare("
        SELECT * FROM visitors 
        WHERE student_id = ? AND visit_date < CURDATE()
        ORDER BY visit_date DESC, entry_time DESC
        LIMIT 20
    ");
    $stmt->execute([$student_id]);
    $visitor_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visitor Management - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --sidebar-width: 270px;
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) { width: 600px; height: 600px; background: #8B5CF6; top: -200px; left: -200px; animation-delay: 0s; }
        .bg-orbs:nth-child(2) { width: 400px; height: 400px; background: #EC4899; bottom: -150px; right: -100px; animation-delay: -7s; }
        .bg-orbs:nth-child(3) { width: 300px; height: 300px; background: #10B981; top: 50%; left: 50%; transform: translate(-50%, -50%); animation-delay: -14s; }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: rgba(18, 18, 26, 0.92);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--glass-border);
            z-index: 1000;
            padding: 1.5rem 0;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 1.5rem;
            text-decoration: none;
        }

        .sidebar-brand .brand-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-1);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
            margin-right: 12px;
            box-shadow: 0 4px 16px rgba(139, 92, 246, 0.3);
            flex-shrink: 0;
        }

        .sidebar-brand .brand-text {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .sidebar-brand .brand-text span { color: #8B5CF6; }
        .sidebar-brand .brand-sub {
            display: block;
            font-size: 0.55rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 0 0.75rem;
        }

        .sidebar-nav::-webkit-scrollbar { width: 4px; }
        .sidebar-nav::-webkit-scrollbar-track { background: transparent; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }

        .nav-section-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--text-muted);
            padding: 0.75rem 1rem 0.5rem;
        }

        .nav-item { margin-bottom: 2px; }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
            font-weight: 500;
            position: relative;
        }

        .nav-link i {
            width: 1.6rem;
            font-size: 1rem;
            color: var(--text-muted);
            transition: all 0.3s ease;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(139, 92, 246, 0.12);
            color: var(--text-primary);
        }

        .nav-link:hover i, .nav-link.active i { color: #8B5CF6; }

        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 24px;
            background: var(--gradient-1);
            border-radius: 0 4px 4px 0;
        }

        .sidebar-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .sidebar-footer .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.6rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .sidebar-footer .user-card:hover { background: rgba(255, 255, 255, 0.06); }

        .sidebar-footer .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            color: white;
            flex-shrink: 0;
        }

        .sidebar-footer .user-info { flex: 1; min-width: 0; }

        .sidebar-footer .user-info .name {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .sidebar-footer .user-info .role {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: capitalize;
        }

        #content-wrapper {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem 2rem;
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1.5rem;
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .btn-toggle-sidebar {
            display: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-toggle-sidebar:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .page-title h1 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .page-title p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .topbar-user:hover { background: rgba(255, 255, 255, 0.08); }

        .topbar-user .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .topbar-user .user-name {
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        .topbar-user .user-role {
            font-size: 0.65rem;
            color: var(--text-muted);
        }

        .alert {
            border-radius: 12px;
            border: none;
            padding: 0.8rem 1.2rem;
            font-size: 0.85rem;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.12);
            color: #34D399;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.12);
            color: #F87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        /* Form Card */
        .form-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .form-card .card-title {
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 1.25rem;
        }

        .form-card .card-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        .form-group label {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 0.3rem;
            display: block;
        }

        .form-group label .required {
            color: #EF4444;
        }

        .form-control,
        .form-select {
            background: rgba(255, 255, 255, 0.04) !important;
            border: 1px solid var(--glass-border) !important;
            border-radius: 12px !important;
            padding: 0.7rem 1rem !important;
            color: var(--text-primary) !important;
            font-size: 0.85rem !important;
            transition: all 0.3s ease;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #8B5CF6 !important;
            box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15) !important;
        }

        .form-control::placeholder {
            color: var(--text-muted);
        }

        .form-select option {
            background: var(--bg-secondary);
            color: var(--text-primary);
        }

        .btn-submit {
            padding: 0.6rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            background: var(--gradient-1);
            border: none;
            color: white;
            transition: all 0.3s ease;
        }

        .btn-submit:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        .btn-checkout {
            padding: 0.3rem 1rem;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.7rem;
            background: rgba(16, 185, 129, 0.12);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: #10B981;
            transition: all 0.3s ease;
        }

        .btn-checkout:hover {
            background: rgba(16, 185, 129, 0.2);
        }

        /* Visitor Cards */
        .visitor-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 1.25rem;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }

        .visitor-card:hover {
            border-color: rgba(139, 92, 246, 0.2);
        }

        .visitor-card .visitor-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 0.5rem;
        }

        .visitor-card .visitor-name {
            font-weight: 600;
            font-size: 1rem;
        }

        .visitor-card .visitor-status {
            font-size: 0.6rem;
            font-weight: 600;
            padding: 0.15rem 0.7rem;
            border-radius: 50px;
            text-transform: uppercase;
        }

        .visitor-status.checked_in {
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
        }

        .visitor-status.checked_out {
            background: rgba(255, 255, 255, 0.04);
            color: var(--text-muted);
        }

        .visitor-card .visitor-details {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 0.5rem;
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        .visitor-card .visitor-details .detail-item .detail-label {
            font-size: 0.6rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
        }

        .visitor-card .visitor-details .detail-item .detail-value {
            color: var(--text-primary);
        }

        .visitor-card .visitor-actions {
            margin-top: 0.75rem;
            padding-top: 0.75rem;
            border-top: 1px solid var(--glass-border);
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
        }

        .empty-state i {
            font-size: 3rem;
            color: var(--text-muted);
            margin-bottom: 1rem;
        }

        .empty-state h5 {
            color: var(--text-primary);
        }

        .empty-state p {
            color: var(--text-secondary);
        }

        .footer {
            text-align: center;
            padding: 1.5rem 0 0.5rem;
            border-top: 1px solid var(--glass-border);
            margin-top: 2rem;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            #content-wrapper {
                margin-left: 0;
                padding: 1rem;
            }

            .btn-toggle-sidebar {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .topbar {
                padding: 0.5rem 1rem;
                border-radius: 16px;
            }

            .page-title h1 { font-size: 1rem; }
            .page-title p { font-size: 0.7rem; }

            .topbar-user .user-name,
            .topbar-user .user-role { display: none; }

            .visitor-card .visitor-header {
                flex-direction: column;
                gap: 0.5rem;
            }

            .visitor-card .visitor-details {
                grid-template-columns: 1fr;
            }
        }

        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: var(--bg-primary); }
        ::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(139, 92, 246, 0.5); }

        .dropdown-menu {
            background: var(--bg-secondary) !important;
            border: 1px solid var(--glass-border) !important;
        }

        .dropdown-item {
            color: var(--text-secondary) !important;
        }

        .dropdown-item:hover {
            background: rgba(139, 92, 246, 0.1) !important;
            color: var(--text-primary) !important;
        }

        .dropdown-divider {
            border-color: var(--glass-border) !important;
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <a href="indexview.php" class="sidebar-brand">
            <div class="brand-icon"><i class="fas fa-home"></i></div>
            <div>
                <div class="brand-text">Graceful<span>Living</span></div>
                <span class="brand-sub">Management System</span>
            </div>
        </a>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Main</div>
            <div class="nav-item">
                <a href="indexview.php" class="nav-link">
                    <i class="fas fa-th-large"></i> Dashboard
                </a>
            </div>

            <div class="nav-section-label">Management</div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i> My Profile
                </a>
            </div>
            <div class="nav-item">
                <a href="viewrooms.php" class="nav-link">
                    <i class="fas fa-bed"></i> Rooms
                </a>
            </div>
            <div class="nav-item">
                <a href="booking.php" class="nav-link">
                    <i class="fas fa-calendar-check"></i> Booking
                </a>
            </div>
            <div class="nav-item">
                <a href="visitor.php" class="nav-link active">
                    <i class="fas fa-user-friends"></i> Visitors
                </a>
            </div>
            <div class="nav-item">
                <a href="payments.php" class="nav-link">
                    <i class="fas fa-credit-card"></i> Payments
                </a>
            </div>

            <div class="nav-section-label">Account</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </nav>

        <div class="sidebar-footer">
            <a href="profile.php" class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($user_name); ?></div>
                    <div class="role"><?php echo htmlspecialchars($user_role); ?></div>
                </div>
                <i class="fas fa-ellipsis-v" style="color: var(--text-muted); font-size: 0.7rem;"></i>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div id="content-wrapper">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left">
                <button class="btn-toggle-sidebar" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Visitor Management</h1>
                    <p>Register and manage your visitors</p>
                </div>
            </div>
            <div class="topbar-right">
                <a href="profile.php" class="topbar-user">
                    <div class="avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                    <div>
                        <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
                        <div class="user-role"><?php echo htmlspecialchars($user_role); ?></div>
                    </div>
                </a>
            </div>
        </header>

        <!-- Messages -->
        <?php if ($message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <!-- Register Visitor Form -->
        <div class="form-card">
            <div class="card-title">
                <i class="fas fa-user-plus"></i> Register Visitor
            </div>
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Visitor Name <span class="required">*</span></label>
                            <input type="text" class="form-control" name="visitor_name" placeholder="Full name" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Phone Number <span class="required">*</span></label>
                            <input type="tel" class="form-control" name="visitor_phone" placeholder="Phone number" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Relation <span class="required">*</span></label>
                            <select class="form-select" name="relation" required>
                                <option value="Father">Father</option>
                                <option value="Mother">Mother</option>
                                <option value="Brother">Brother</option>
                                <option value="Sister">Sister</option>
                                <option value="Friend">Friend</option>
                                <option value="Relative">Relative</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Purpose</label>
                            <input type="text" class="form-control" name="purpose" placeholder="Purpose of visit">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Visit Date</label>
                            <input type="date" class="form-control" name="visit_date" value="<?php echo date('Y-m-d'); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Entry Time</label>
                            <input type="time" class="form-control" name="entry_time" value="<?php echo date('H:i'); ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>ID Proof Type</label>
                            <select class="form-select" name="id_proof_type">
                                <option value="">Select ID Type</option>
                                <option value="Aadhar Card">Aadhar Card</option>
                                <option value="PAN Card">PAN Card</option>
                                <option value="Driving License">Driving License</option>
                                <option value="Voter ID">Voter ID</option>
                                <option value="Passport">Passport</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>ID Proof Number</label>
                            <input type="text" class="form-control" name="id_proof_number" placeholder="ID number">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" name="register_visitor" class="btn-submit">
                            <i class="fas fa-check-circle me-2"></i>Register Visitor
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Today's Visitors -->
        <h5 class="mb-3"><i class="fas fa-calendar-day me-2" style="color:#8B5CF6;"></i>Today's Visitors</h5>
        
        <?php if (!empty($today_visitors)): ?>
            <?php foreach ($today_visitors as $visitor): ?>
                <div class="visitor-card">
                    <div class="visitor-header">
                        <div class="visitor-name">
                            <?php echo htmlspecialchars($visitor['visitor_name']); ?>
                            <span style="font-size:0.8rem;font-weight:400;color:var(--text-secondary);">
                                (<?php echo htmlspecialchars($visitor['relation']); ?>)
                            </span>
                        </div>
                        <span class="visitor-status <?php echo $visitor['status']; ?>">
                            <?php if ($visitor['status'] === 'checked_in'): ?>
                                <i class="fas fa-check-circle me-1"></i>
                            <?php else: ?>
                                <i class="fas fa-check-double me-1"></i>
                            <?php endif; ?>
                            <?php echo ucfirst(str_replace('_', ' ', $visitor['status'])); ?>
                        </span>
                    </div>
                    <div class="visitor-details">
                        <div class="detail-item">
                            <div class="detail-label">Phone</div>
                            <div class="detail-value"><?php echo htmlspecialchars($visitor['visitor_phone']); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Purpose</div>
                            <div class="detail-value"><?php echo htmlspecialchars($visitor['purpose'] ?: 'Not specified'); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Entry Time</div>
                            <div class="detail-value"><?php echo date('g:i A', strtotime($visitor['entry_time'])); ?></div>
                        </div>
                        <?php if ($visitor['exit_time']): ?>
                            <div class="detail-item">
                                <div class="detail-label">Exit Time</div>
                                <div class="detail-value"><?php echo date('g:i A', strtotime($visitor['exit_time'])); ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if ($visitor['id_proof_type']): ?>
                            <div class="detail-item">
                                <div class="detail-label">ID Proof</div>
                                <div class="detail-value"><?php echo htmlspecialchars($visitor['id_proof_type']); ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($visitor['status'] === 'checked_in'): ?>
                        <div class="visitor-actions">
                            <form method="POST" action="" style="display:inline;">
                                <input type="hidden" name="visitor_id" value="<?php echo $visitor['id']; ?>">
                                <button type="submit" name="checkout_visitor" class="btn-checkout" 
                                        onclick="return confirm('Check out <?php echo htmlspecialchars($visitor['visitor_name']); ?>?')">
                                    <i class="fas fa-sign-out-alt me-1"></i>Check Out
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state" style="background:rgba(18,18,26,0.6);border-radius:20px;border:1px solid var(--glass-border);">
                <i class="fas fa-user-friends" style="color:#8B5CF6;"></i>
                <h5>No Visitors Today</h5>
                <p>You haven't registered any visitors for today.</p>
            </div>
        <?php endif; ?>

        <!-- Visitor History -->
        <?php if (!empty($visitor_history)): ?>
            <h5 class="mb-3 mt-4"><i class="fas fa-history me-2" style="color:#8B5CF6;"></i>Visitor History</h5>
            
            <?php foreach ($visitor_history as $visitor): ?>
                <div class="visitor-card" style="opacity:0.8;">
                    <div class="visitor-header">
                        <div class="visitor-name">
                            <?php echo htmlspecialchars($visitor['visitor_name']); ?>
                            <span style="font-size:0.8rem;font-weight:400;color:var(--text-secondary);">
                                (<?php echo htmlspecialchars($visitor['relation']); ?>)
                            </span>
                        </div>
                        <span class="visitor-status checked_out">
                            <i class="fas fa-check-double me-1"></i>Checked Out
                        </span>
                    </div>
                    <div class="visitor-details">
                        <div class="detail-item">
                            <div class="detail-label">Date</div>
                            <div class="detail-value"><?php echo date('M j, Y', strtotime($visitor['visit_date'])); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Phone</div>
                            <div class="detail-value"><?php echo htmlspecialchars($visitor['visitor_phone']); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Entry</div>
                            <div class="detail-value"><?php echo date('g:i A', strtotime($visitor['entry_time'])); ?></div>
                        </div>
                        <?php if ($visitor['exit_time']): ?>
                            <div class="detail-item">
                                <div class="detail-label">Exit</div>
                                <div class="detail-value"><?php echo date('g:i A', strtotime($visitor['exit_time'])); ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Footer -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Graceful Living — All rights reserved.</p>
        </footer>
    </div>

    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Ready to Leave?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-secondary" style="color: var(--text-secondary) !important;">
                    Select "Logout" below if you are ready to end your current session.
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $('#sidebarToggle').on('click', function() {
            $('#sidebar').toggleClass('open');
        });

        $(document).on('click', function(e) {
            if ($(window).width() <= 768) {
                if (!$(e.target).closest('#sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
                    $('#sidebar').removeClass('open');
                }
            }
        });

        // Auto-close alerts
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>