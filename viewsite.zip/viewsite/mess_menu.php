<?php
// mess_menu.php - Weekly Mess Menu View
session_start();
include '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'student';

// Fetch mess menu templates
$templates = [];
try {
    $stmt = $db->query("SELECT * FROM mess_menu_templates ORDER BY name");
    $templates = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch weekly menu
$weekly_menu = [];
$days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
try {
    $stmt = $db->query("SELECT * FROM mess_menu WHERE is_current = 1");
    $menus = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Organize by day
    foreach ($menus as $menu) {
        $weekly_menu[$menu['day']] = $menu;
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Get current day
$current_day = strtolower(date('l'));
$day_names = [
    'monday' => 'Monday',
    'tuesday' => 'Tuesday',
    'wednesday' => 'Wednesday',
    'thursday' => 'Thursday',
    'friday' => 'Friday',
    'saturday' => 'Saturday',
    'sunday' => 'Sunday'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mess Menu - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --gradient-3: linear-gradient(135deg, #10B981, #34D399);
            --sidebar-width: 270px;
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) { width: 600px; height: 600px; background: #8B5CF6; top: -200px; left: -200px; animation-delay: 0s; }
        .bg-orbs:nth-child(2) { width: 400px; height: 400px; background: #EC4899; bottom: -150px; right: -100px; animation-delay: -7s; }
        .bg-orbs:nth-child(3) { width: 300px; height: 300px; background: #F59E0B; top: 50%; left: 50%; transform: translate(-50%, -50%); animation-delay: -14s; }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: rgba(18, 18, 26, 0.92);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--glass-border);
            z-index: 1000;
            padding: 1.5rem 0;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 1.5rem;
            text-decoration: none;
        }

        .sidebar-brand .brand-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-1);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
            margin-right: 12px;
            box-shadow: 0 4px 16px rgba(139, 92, 246, 0.3);
            flex-shrink: 0;
        }

        .sidebar-brand .brand-text {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .sidebar-brand .brand-text span { color: #8B5CF6; }
        .sidebar-brand .brand-sub {
            display: block;
            font-size: 0.55rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 0 0.75rem;
        }

        .sidebar-nav::-webkit-scrollbar { width: 4px; }
        .sidebar-nav::-webkit-scrollbar-track { background: transparent; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }

        .nav-section-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--text-muted);
            padding: 0.75rem 1rem 0.5rem;
        }

        .nav-item { margin-bottom: 2px; }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
            font-weight: 500;
            position: relative;
        }

        .nav-link i {
            width: 1.6rem;
            font-size: 1rem;
            color: var(--text-muted);
            transition: all 0.3s ease;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(139, 92, 246, 0.12);
            color: var(--text-primary);
        }

        .nav-link:hover i, .nav-link.active i { color: #8B5CF6; }

        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 24px;
            background: var(--gradient-1);
            border-radius: 0 4px 4px 0;
        }

        .sidebar-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .sidebar-footer .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.6rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .sidebar-footer .user-card:hover { background: rgba(255, 255, 255, 0.06); }

        .sidebar-footer .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            color: white;
            flex-shrink: 0;
        }

        .sidebar-footer .user-info { flex: 1; min-width: 0; }

        .sidebar-footer .user-info .name {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .sidebar-footer .user-info .role {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: capitalize;
        }

        #content-wrapper {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem 2rem;
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1.5rem;
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .btn-toggle-sidebar {
            display: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-toggle-sidebar:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .page-title h1 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .page-title p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .topbar-user:hover { background: rgba(255, 255, 255, 0.08); }

        .topbar-user .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .topbar-user .user-name {
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        .topbar-user .user-role {
            font-size: 0.65rem;
            color: var(--text-muted);
        }

        /* Today's Special */
        .today-special {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.5rem 2rem;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .today-special .today-label {
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
            letter-spacing: 0.5px;
        }

        .today-special .today-day {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .today-special .today-meals {
            display: flex;
            gap: 2rem;
        }

        .today-special .today-meals .meal-item .meal-label {
            font-size: 0.6rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
        }

        .today-special .today-meals .meal-item .meal-value {
            font-size: 0.9rem;
            color: var(--text-secondary);
        }

        .today-badge {
            background: var(--gradient-3);
            color: white;
            padding: 0.3rem 1rem;
            border-radius: 50px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        /* Menu Grid */
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .menu-day-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 1rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .menu-day-card:hover {
            border-color: rgba(139, 92, 246, 0.2);
            transform: translateY(-4px);
        }

        .menu-day-card.today {
            border-color: rgba(16, 185, 129, 0.3);
            background: rgba(16, 185, 129, 0.05);
        }

        .menu-day-card .day-name {
            font-size: 0.8rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .menu-day-card .day-name .today-indicator {
            display: block;
            font-size: 0.5rem;
            font-weight: 600;
            color: #10B981;
            text-transform: uppercase;
        }

        .menu-day-card .meal-section {
            padding: 0.3rem 0;
            border-bottom: 1px solid var(--glass-border);
        }

        .menu-day-card .meal-section:last-child {
            border-bottom: none;
        }

        .menu-day-card .meal-section .meal-label {
            font-size: 0.5rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
        }

        .menu-day-card .meal-section .meal-value {
            font-size: 0.7rem;
            color: var(--text-secondary);
        }

        /* Templates */
        .templates-section {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.5rem;
        }

        .templates-section .section-title {
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .templates-section .section-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .template-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1rem;
        }

        .template-card {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            padding: 1rem;
            transition: all 0.3s ease;
        }

        .template-card:hover {
            border-color: rgba(139, 92, 246, 0.2);
        }

        .template-card .template-name {
            font-weight: 600;
            margin-bottom: 0.3rem;
        }

        .template-card .template-name .default-badge {
            font-size: 0.5rem;
            font-weight: 600;
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
            padding: 0.1rem 0.5rem;
            border-radius: 50px;
            margin-left: 0.5rem;
        }

        .template-card .template-desc {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }

        .template-card .template-meals {
            display: flex;
            gap: 1rem;
            font-size: 0.7rem;
        }

        .template-card .template-meals .meal-label {
            color: var(--text-muted);
        }

        .template-card .template-meals .meal-value {
            color: var(--text-secondary);
        }

        .footer {
            text-align: center;
            padding: 1.5rem 0 0.5rem;
            border-top: 1px solid var(--glass-border);
            margin-top: 2rem;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        .footer .footer-links {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            margin-top: 0.5rem;
            flex-wrap: wrap;
        }

        .footer .footer-links a {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.7rem;
            transition: color 0.3s ease;
        }

        .footer .footer-links a:hover {
            color: var(--text-secondary);
        }

        @media (max-width: 1024px) {
            .menu-grid {
                grid-template-columns: repeat(4, 1fr);
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            #content-wrapper {
                margin-left: 0;
                padding: 1rem;
            }

            .btn-toggle-sidebar {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .topbar {
                padding: 0.5rem 1rem;
                border-radius: 16px;
            }

            .page-title h1 { font-size: 1rem; }
            .page-title p { font-size: 0.7rem; }

            .topbar-user .user-name,
            .topbar-user .user-role { display: none; }

            .today-special {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }

            .today-special .today-meals {
                flex-direction: column;
                gap: 0.5rem;
            }

            .menu-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .template-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 480px) {
            .menu-grid {
                grid-template-columns: 1fr;
            }
        }

        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: var(--bg-primary); }
        ::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(139, 92, 246, 0.5); }

        .dropdown-menu {
            background: var(--bg-secondary) !important;
            border: 1px solid var(--glass-border) !important;
        }

        .dropdown-item {
            color: var(--text-secondary) !important;
        }

        .dropdown-item:hover {
            background: rgba(139, 92, 246, 0.1) !important;
            color: var(--text-primary) !important;
        }

        .dropdown-divider {
            border-color: var(--glass-border) !important;
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <a href="indexview.php" class="sidebar-brand">
            <div class="brand-icon"><i class="fas fa-home"></i></div>
            <div>
                <div class="brand-text">Graceful<span>Living</span></div>
                <span class="brand-sub">Management System</span>
            </div>
        </a>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Main</div>
            <div class="nav-item">
                <a href="indexview.php" class="nav-link">
                    <i class="fas fa-th-large"></i> Dashboard
                </a>
            </div>

            <div class="nav-section-label">Management</div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i> My Profile
                </a>
            </div>
            <div class="nav-item">
                <a href="viewrooms.php" class="nav-link">
                    <i class="fas fa-bed"></i> Rooms
                </a>
            </div>
            <div class="nav-item">
                <a href="mess_menu.php" class="nav-link active">
                    <i class="fas fa-utensils"></i> Mess Menu
                </a>
            </div>
            <div class="nav-item">
                <a href="payments.php" class="nav-link">
                    <i class="fas fa-credit-card"></i> Payments
                </a>
            </div>

            <div class="nav-section-label">Account</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </nav>

        <div class="sidebar-footer">
            <a href="profile.php" class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($user_name); ?></div>
                    <div class="role"><?php echo htmlspecialchars($user_role); ?></div>
                </div>
                <i class="fas fa-ellipsis-v" style="color: var(--text-muted); font-size: 0.7rem;"></i>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div id="content-wrapper">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left">
                <button class="btn-toggle-sidebar" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Mess Menu</h1>
                    <p>Weekly meal schedule</p>
                </div>
            </div>
            <div class="topbar-right">
                <a href="profile.php" class="topbar-user">
                    <div class="avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                    <div>
                        <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
                        <div class="user-role"><?php echo htmlspecialchars($user_role); ?></div>
                    </div>
                </a>
            </div>
        </header>

        <!-- Today's Special -->
        <?php if (isset($weekly_menu[$current_day])): ?>
            <?php $today = $weekly_menu[$current_day]; ?>
            <div class="today-special">
                <div>
                    <div class="today-label">Today's Menu</div>
                    <div class="today-day"><?php echo $day_names[$current_day]; ?></div>
                </div>
                <div class="today-meals">
                    <div class="meal-item">
                        <div class="meal-label"><i class="fas fa-sun me-1"></i>Breakfast</div>
                        <div class="meal-value"><?php echo htmlspecialchars($today['breakfast']); ?></div>
                    </div>
                    <div class="meal-item">
                        <div class="meal-label"><i class="fas fa-sun me-1"></i>Lunch</div>
                        <div class="meal-value"><?php echo htmlspecialchars($today['lunch']); ?></div>
                    </div>
                    <div class="meal-item">
                        <div class="meal-label"><i class="fas fa-moon me-1"></i>Dinner</div>
                        <div class="meal-value"><?php echo htmlspecialchars($today['dinner']); ?></div>
                    </div>
                </div>
                <span class="today-badge"><i class="fas fa-star me-1"></i>Today's Special</span>
            </div>
        <?php endif; ?>

        <!-- Weekly Menu Grid -->
        <h5 class="mb-3"><i class="fas fa-calendar-alt me-2" style="color:#8B5CF6;"></i>Weekly Schedule</h5>
        <div class="menu-grid">
            <?php foreach ($days as $day): ?>
                <div class="menu-day-card <?php echo ($day === $current_day) ? 'today' : ''; ?>">
                    <div class="day-name">
                        <?php echo $day_names[$day]; ?>
                        <?php if ($day === $current_day): ?>
                            <span class="today-indicator">Today</span>
                        <?php endif; ?>
                    </div>
                    <?php if (isset($weekly_menu[$day])): ?>
                        <?php $menu = $weekly_menu[$day]; ?>
                        <div class="meal-section">
                            <div class="meal-label">Breakfast</div>
                            <div class="meal-value"><?php echo htmlspecialchars($menu['breakfast']); ?></div>
                        </div>
                        <div class="meal-section">
                            <div class="meal-label">Lunch</div>
                            <div class="meal-value"><?php echo htmlspecialchars($menu['lunch']); ?></div>
                        </div>
                        <div class="meal-section">
                            <div class="meal-label">Dinner</div>
                            <div class="meal-value"><?php echo htmlspecialchars($menu['dinner']); ?></div>
                        </div>
                        <?php if (!empty($menu['special_notes'])): ?>
                            <div style="margin-top:0.3rem;font-size:0.6rem;color:#F59E0B;">
                                <i class="fas fa-info-circle me-1"></i>
                                <?php echo htmlspecialchars($menu['special_notes']); ?>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div style="color:var(--text-muted);font-size:0.7rem;padding:0.5rem 0;">
                            <i class="fas fa-minus me-1"></i> No menu set
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Menu Templates -->
        <?php if (!empty($templates)): ?>
            <div class="templates-section">
                <div class="section-title">
                    <i class="fas fa-file-alt"></i> Meal Templates
                </div>
                <div class="template-grid">
                    <?php foreach ($templates as $template): ?>
                        <div class="template-card">
                            <div class="template-name">
                                <?php echo htmlspecialchars($template['name']); ?>
                                <?php if ($template['is_default']): ?>
                                    <span class="default-badge">Default</span>
                                <?php endif; ?>
                            </div>
                            <div class="template-desc"><?php echo htmlspecialchars($template['description']); ?></div>
                            <div class="template-meals">
                                <div>
                                    <span class="meal-label">Breakfast:</span>
                                    <span class="meal-value"><?php echo htmlspecialchars($template['breakfast_items']); ?></span>
                                </div>
                            </div>
                            <div class="template-meals">
                                <div>
                                    <span class="meal-label">Lunch:</span>
                                    <span class="meal-value"><?php echo htmlspecialchars($template['lunch_items']); ?></span>
                                </div>
                            </div>
                            <div class="template-meals">
                                <div>
                                    <span class="meal-label">Dinner:</span>
                                    <span class="meal-value"><?php echo htmlspecialchars($template['dinner_items']); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Footer -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Graceful Living — All rights reserved.</p>
            <div class="footer-links">
                <a href="about.php">About</a>
                <a href="contact.php">Contact</a>
                <a href="terms.php">Terms</a>
                <a href="privacy.php">Privacy</a>
            </div>
        </footer>
    </div>

    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Ready to Leave?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-secondary" style="color: var(--text-secondary) !important;">
                    Select "Logout" below if you are ready to end your current session.
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $('#sidebarToggle').on('click', function() {
            $('#sidebar').toggleClass('open');
        });

        $(document).on('click', function(e) {
            if ($(window).width() <= 768) {
                if (!$(e.target).closest('#sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
                    $('#sidebar').removeClass('open');
                }
            }
        });
    </script>
</body>
</html>