<?php
// booking.php - Complete Booking Management System
session_start();
include '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'student';
$user_email = $_SESSION['user_email'] ?? '';

// Get user's student details
$student = null;
try {
    $stmt = $db->prepare("SELECT * FROM students WHERE user_id = ? OR id = ?");
    $stmt->execute([$user_id, $user_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

$student_id = $student['id'] ?? 0;

// Get room types for filter
$room_types = [];
try {
    $stmt = $db->query("SELECT DISTINCT type FROM rooms");
    $room_types = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $room_types = [];
}

// Get available rooms
$available_rooms = [];
try {
    $stmt = $db->query("
        SELECT r.*, 
               COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0) as occupied_count,
               (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) as available_spots
        FROM rooms r 
        WHERE r.status = 'available' 
        AND (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) > 0
        ORDER BY r.rent ASC
    ");
    $available_rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Get user's active bookings
$active_bookings = [];
$has_active_booking = false;
try {
    $stmt = $db->prepare("
        SELECT ra.*, r.room_number, r.floor, r.type, r.rent, r.facilities
        FROM room_allocations ra
        JOIN rooms r ON ra.room_id = r.id
        WHERE ra.student_id = ? AND ra.status IN ('pending', 'confirmed')
        ORDER BY ra.created_at DESC
    ");
    $stmt->execute([$student_id]);
    $active_bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $has_active_booking = !empty($active_bookings);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Get booking history
$booking_history = [];
try {
    $stmt = $db->prepare("
        SELECT ra.*, r.room_number, r.floor, r.type, r.rent
        FROM room_allocations ra
        JOIN rooms r ON ra.room_id = r.id
        WHERE ra.student_id = ? AND ra.status IN ('cancelled', 'completed')
        ORDER BY ra.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$student_id]);
    $booking_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Handle Search
$search_results = [];
$search_performed = false;
$has_results = false;
$search_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search_rooms'])) {
    $search_performed = true;
    $check_in = $_POST['check_in'] ?? '';
    $check_out = $_POST['check_out'] ?? '';
    $guests = (int)($_POST['guests'] ?? 1);
    $room_type = $_POST['room_type'] ?? '';
    $min_price = $_POST['min_price'] ?? '';
    $max_price = $_POST['max_price'] ?? '';
    
    if (empty($check_in) || empty($check_out)) {
        $search_error = "Please select both check-in and check-out dates.";
    } elseif ($check_in >= $check_out) {
        $search_error = "Check-out date must be after check-in date.";
    } else {
        $sql = "
            SELECT r.*, 
                   COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0) as occupied_count,
                   (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) as available_spots
            FROM rooms r 
            WHERE r.status = 'available' 
            AND (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) >= ?
        ";
        
        $params = [$guests];
        
        if (!empty($room_type)) {
            $sql .= " AND r.type = ?";
            $params[] = $room_type;
        }
        
        if (!empty($min_price)) {
            $sql .= " AND r.rent >= ?";
            $params[] = $min_price;
        }
        
        if (!empty($max_price)) {
            $sql .= " AND r.rent <= ?";
            $params[] = $max_price;
        }
        
        $sql .= " ORDER BY r.rent ASC";
        
        try {
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $search_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $has_results = !empty($search_results);
        } catch (PDOException $e) {
            $search_error = "Search failed: " . $e->getMessage();
        }
    }
}

// Handle Booking Request
$booking_message = '';
$booking_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_room'])) {
    if ($has_active_booking) {
        $booking_error = "You already have an active booking. Please cancel or complete it before booking a new room.";
    } else {
        $room_id = (int)($_POST['room_id'] ?? 0);
        $move_in_date = $_POST['move_in_date'] ?? '';
        $special_requirements = $_POST['special_requirements'] ?? '';
        $duration = (int)($_POST['duration'] ?? 1);
        
        if ($room_id <= 0 || empty($move_in_date)) {
            $booking_error = "Please select a room and move-in date.";
        } else {
            try {
                // Check room availability again
                $stmt = $db->prepare("
                    SELECT r.*, 
                           COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0) as occupied_count
                    FROM rooms r 
                    WHERE r.id = ? AND r.status = 'available'
                ");
                $stmt->execute([$room_id]);
                $room = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$room) {
                    throw new Exception("Room is no longer available.");
                }
                
                if (($room['occupied_count'] ?? 0) >= ($room['capacity'] ?? 1)) {
                    throw new Exception("Room is fully occupied.");
                }
                
                $db->beginTransaction();
                
                // Create room allocation
                $stmt = $db->prepare("
                    INSERT INTO room_allocations 
                    (student_id, room_id, move_in_date, special_requirements, status) 
                    VALUES (?, ?, ?, ?, 'pending')
                ");
                $stmt->execute([$student_id, $room_id, $move_in_date, $special_requirements]);
                $allocation_id = $db->lastInsertId();
                
                // Update room occupied count
                $new_occupied = ($room['occupied_count'] ?? 0) + 1;
                $new_status = ($new_occupied >= $room['capacity']) ? 'occupied' : 'available';
                
                $stmt = $db->prepare("
                    UPDATE rooms SET occupied = ?, status = ? WHERE id = ?
                ");
                $stmt->execute([$new_occupied, $new_status, $room_id]);
                
                // Update student's room assignment
                $stmt = $db->prepare("UPDATE students SET room_id = ? WHERE id = ?");
                $stmt->execute([$room_id, $student_id]);
                
                // Create initial payment record
                $receipt_number = 'RENT' . date('YmdHis') . rand(100, 999);
                $due_date = date('Y-m-d', strtotime('+7 days'));
                
                $stmt = $db->prepare("
                    INSERT INTO payments 
                    (student_id, amount, payment_type, due_date, status, description, receipt_number) 
                    VALUES (?, ?, 'rent', ?, 'pending', ?, ?)
                ");
                $stmt->execute([
                    $student_id,
                    $room['rent'],
                    $due_date,
                    "Monthly hostel rent for Room " . $room['room_number'] . " - " . date('F Y'),
                    $receipt_number
                ]);
                
                // Create security deposit payment
                $security_amount = $room['rent'] * 2;
                $security_receipt = 'SEC' . date('YmdHis') . rand(100, 999);
                
                $stmt = $db->prepare("
                    INSERT INTO payments 
                    (student_id, amount, payment_type, due_date, status, description, receipt_number) 
                    VALUES (?, ?, 'security', ?, 'pending', ?, ?)
                ");
                $stmt->execute([
                    $student_id,
                    $security_amount,
                    $due_date,
                    "Security deposit for Room " . $room['room_number'],
                    $security_receipt
                ]);
                
                $db->commit();
                
                $booking_message = "Room booking request submitted successfully! Please complete the payments within 7 days.";
                $has_active_booking = true;
                
                // Refresh active bookings
                $stmt = $db->prepare("
                    SELECT ra.*, r.room_number, r.floor, r.type, r.rent, r.facilities
                    FROM room_allocations ra
                    JOIN rooms r ON ra.room_id = r.id
                    WHERE ra.student_id = ? AND ra.status IN ('pending', 'confirmed')
                    ORDER BY ra.created_at DESC
                ");
                $stmt->execute([$student_id]);
                $active_bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                // Refresh available rooms
                $stmt = $db->query("
                    SELECT r.*, 
                           COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0) as occupied_count,
                           (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) as available_spots
                    FROM rooms r 
                    WHERE r.status = 'available' 
                    AND (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) > 0
                    ORDER BY r.rent ASC
                ");
                $available_rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
            } catch (Exception $e) {
                $db->rollBack();
                $booking_error = "Booking failed: " . $e->getMessage();
            }
        }
    }
}

// Handle Cancel Booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_booking'])) {
    $allocation_id = (int)($_POST['allocation_id'] ?? 0);
    
    if ($allocation_id > 0) {
        try {
            $db->beginTransaction();
            
            // Get allocation details
            $stmt = $db->prepare("
                SELECT ra.*, r.id as room_id, r.occupied as current_occupied, r.capacity
                FROM room_allocations ra
                JOIN rooms r ON ra.room_id = r.id
                WHERE ra.id = ? AND ra.student_id = ?
            ");
            $stmt->execute([$allocation_id, $student_id]);
            $allocation = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($allocation) {
                // Update allocation status
                $stmt = $db->prepare("UPDATE room_allocations SET status = 'cancelled' WHERE id = ?");
                $stmt->execute([$allocation_id]);
                
                // Update room occupancy
                $new_occupied = max(0, $allocation['current_occupied'] - 1);
                $new_status = ($new_occupied > 0) ? 'occupied' : 'available';
                
                $stmt = $db->prepare("
                    UPDATE rooms SET occupied = ?, status = ? WHERE id = ?
                ");
                $stmt->execute([$new_occupied, $new_status, $allocation['room_id']]);
                
                // Update student's room assignment
                $stmt = $db->prepare("UPDATE students SET room_id = NULL WHERE id = ?");
                $stmt->execute([$student_id]);
                
                $db->commit();
                
                $booking_message = "Booking cancelled successfully.";
                $has_active_booking = false;
                
                // Refresh data
                $active_bookings = [];
                
                // Refresh available rooms
                $stmt = $db->query("
                    SELECT r.*, 
                           COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0) as occupied_count,
                           (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) as available_spots
                    FROM rooms r 
                    WHERE r.status = 'available' 
                    AND (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) > 0
                    ORDER BY r.rent ASC
                ");
                $available_rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        } catch (Exception $e) {
            $db->rollBack();
            $booking_error = "Failed to cancel booking: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --gradient-2: linear-gradient(135deg, #3B82F6, #8B5CF6);
            --gradient-3: linear-gradient(135deg, #10B981, #34D399);
            --gradient-4: linear-gradient(135deg, #F59E0B, #FBBF24);
            --sidebar-width: 270px;
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) { width: 600px; height: 600px; background: #8B5CF6; top: -200px; left: -200px; animation-delay: 0s; }
        .bg-orbs:nth-child(2) { width: 400px; height: 400px; background: #EC4899; bottom: -150px; right: -100px; animation-delay: -7s; }
        .bg-orbs:nth-child(3) { width: 300px; height: 300px; background: #3B82F6; top: 50%; left: 50%; transform: translate(-50%, -50%); animation-delay: -14s; }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: rgba(18, 18, 26, 0.92);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--glass-border);
            z-index: 1000;
            padding: 1.5rem 0;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 1.5rem;
            text-decoration: none;
        }

        .sidebar-brand .brand-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-1);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
            margin-right: 12px;
            box-shadow: 0 4px 16px rgba(139, 92, 246, 0.3);
            flex-shrink: 0;
        }

        .sidebar-brand .brand-text {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .sidebar-brand .brand-text span { color: #8B5CF6; }
        .sidebar-brand .brand-sub {
            display: block;
            font-size: 0.55rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 0 0.75rem;
        }

        .sidebar-nav::-webkit-scrollbar { width: 4px; }
        .sidebar-nav::-webkit-scrollbar-track { background: transparent; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }

        .nav-section-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--text-muted);
            padding: 0.75rem 1rem 0.5rem;
        }

        .nav-item { margin-bottom: 2px; }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
            font-weight: 500;
            position: relative;
        }

        .nav-link i {
            width: 1.6rem;
            font-size: 1rem;
            color: var(--text-muted);
            transition: all 0.3s ease;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(139, 92, 246, 0.12);
            color: var(--text-primary);
        }

        .nav-link:hover i, .nav-link.active i { color: #8B5CF6; }

        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 24px;
            background: var(--gradient-1);
            border-radius: 0 4px 4px 0;
        }

        .sidebar-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .sidebar-footer .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.6rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .sidebar-footer .user-card:hover { background: rgba(255, 255, 255, 0.06); }

        .sidebar-footer .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            color: white;
            flex-shrink: 0;
        }

        .sidebar-footer .user-info { flex: 1; min-width: 0; }

        .sidebar-footer .user-info .name {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .sidebar-footer .user-info .role {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: capitalize;
        }

        #content-wrapper {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem 2rem;
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1.5rem;
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .btn-toggle-sidebar {
            display: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-toggle-sidebar:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .page-title h1 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .page-title p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .topbar-user:hover { background: rgba(255, 255, 255, 0.08); }

        .topbar-user .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .topbar-user .user-name {
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        .topbar-user .user-role {
            font-size: 0.65rem;
            color: var(--text-muted);
        }

        /* Alert Styles */
        .alert {
            border-radius: 12px;
            border: none;
            padding: 0.8rem 1.2rem;
            font-size: 0.85rem;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.12);
            color: #34D399;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.12);
            color: #F87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .alert-info {
            background: rgba(59, 130, 246, 0.12);
            color: #60A5FA;
            border: 1px solid rgba(59, 130, 246, 0.2);
        }

        /* Active Bookings */
        .booking-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: all 0.3s ease;
        }

        .booking-card:hover {
            border-color: rgba(139, 92, 246, 0.2);
        }

        .booking-card .booking-info {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .booking-card .booking-icon {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }

        .booking-card .booking-icon.pending {
            background: rgba(245, 158, 11, 0.15);
            color: #F59E0B;
        }

        .booking-card .booking-icon.confirmed {
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
        }

        .booking-card .booking-details .booking-room {
            font-size: 1rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .booking-card .booking-details .booking-status {
            font-size: 0.7rem;
            font-weight: 600;
        }

        .booking-card .booking-details .booking-status.pending {
            color: #F59E0B;
        }

        .booking-card .booking-details .booking-status.confirmed {
            color: #10B981;
        }

        .booking-card .booking-details .booking-meta {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        .booking-card .booking-actions {
            display: flex;
            gap: 0.5rem;
        }

        .btn-booking {
            padding: 0.4rem 1.2rem;
            border-radius: 10px;
            font-size: 0.75rem;
            font-weight: 500;
            border: none;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn-booking.primary {
            background: var(--gradient-1);
            color: white;
        }

        .btn-booking.primary:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            color: white;
        }

        .btn-booking.outline {
            background: transparent;
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
        }

        .btn-booking.outline:hover {
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-primary);
        }

        .btn-booking.danger {
            background: rgba(239, 68, 68, 0.12);
            color: #EF4444;
        }

        .btn-booking.danger:hover {
            background: rgba(239, 68, 68, 0.2);
        }

        /* Search Section */
        .search-section {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
        }

        .search-section .search-title {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
        }

        .search-section .search-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .search-section .form-group {
            margin-bottom: 1rem;
        }

        .search-section label {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 0.3rem;
            display: block;
        }

        .search-section .form-control,
        .search-section .form-select {
            background: rgba(255, 255, 255, 0.04) !important;
            border: 1px solid var(--glass-border) !important;
            border-radius: 12px !important;
            padding: 0.7rem 1rem !important;
            color: var(--text-primary) !important;
            font-size: 0.85rem !important;
            transition: all 0.3s ease;
        }

        .search-section .form-control:focus,
        .search-section .form-select:focus {
            border-color: #8B5CF6 !important;
            box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15) !important;
        }

        .search-section .form-control::placeholder {
            color: var(--text-muted);
        }

        .search-section .form-select option {
            background: var(--bg-secondary);
            color: var(--text-primary);
        }

        .btn-search {
            width: 100%;
            padding: 0.7rem;
            border-radius: 12px;
            font-weight: 600;
            background: var(--gradient-1);
            border: none;
            color: white;
            transition: all 0.3s ease;
        }

        .btn-search:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        /* Search Results */
        .search-results {
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .result-count {
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }

        .result-card {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 1.25rem;
            margin-bottom: 0.75rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: all 0.3s ease;
        }

        .result-card:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(139, 92, 246, 0.2);
        }

        .result-card .result-info .result-room {
            font-size: 1rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .result-card .result-info .result-room small {
            font-size: 0.7rem;
            font-weight: 400;
            color: var(--text-muted);
        }

        .result-card .result-info .result-details {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        .result-card .result-price {
            text-align: right;
        }

        .result-card .result-price .price-amount {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .result-card .result-price .price-amount small {
            font-size: 0.65rem;
            font-weight: 400;
            color: var(--text-muted);
        }

        .result-card .result-actions {
            display: flex;
            gap: 0.5rem;
        }

        .btn-book-now {
            padding: 0.4rem 1.2rem;
            border-radius: 10px;
            font-weight: 600;
            font-size: 0.75rem;
            background: var(--gradient-1);
            border: none;
            color: white;
            transition: all 0.3s ease;
        }

        .btn-book-now:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        .btn-view-details {
            padding: 0.4rem 1.2rem;
            border-radius: 10px;
            font-weight: 500;
            font-size: 0.75rem;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn-view-details:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .empty-state {
            text-align: center;
            padding: 2rem;
        }

        .empty-state i {
            font-size: 2.5rem;
            color: var(--text-muted);
            margin-bottom: 1rem;
        }

        .empty-state h5 {
            color: var(--text-primary);
        }

        .empty-state p {
            color: var(--text-secondary);
        }

        /* Booking History */
        .history-table-wrap {
            overflow-x: auto;
        }

        .history-table {
            width: 100%;
            border-collapse: collapse;
        }

        .history-table th {
            font-size: 0.6rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-muted);
            padding: 0.5rem 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--glass-border);
        }

        .history-table td {
            padding: 0.6rem 0.75rem;
            font-size: 0.8rem;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--glass-border);
        }

        .history-table tr:last-child td {
            border-bottom: none;
        }

        .history-table td strong {
            color: var(--text-primary);
        }

        .status-badge {
            font-size: 0.55rem;
            font-weight: 600;
            padding: 0.15rem 0.6rem;
            border-radius: 50px;
            text-transform: uppercase;
        }

        .status-badge.pending {
            background: rgba(245, 158, 11, 0.15);
            color: #F59E0B;
        }

        .status-badge.confirmed {
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
        }

        .status-badge.cancelled {
            background: rgba(239, 68, 68, 0.15);
            color: #EF4444;
        }

        .status-badge.completed {
            background: rgba(59, 130, 246, 0.15);
            color: #60A5FA;
        }

        .footer {
            text-align: center;
            padding: 1.5rem 0 0.5rem;
            border-top: 1px solid var(--glass-border);
            margin-top: 2rem;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        /* Modal */
        .modal-content {
            background: var(--bg-secondary);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
        }

        .modal-header, .modal-footer {
            border-color: var(--glass-border);
        }

        .modal-title {
            color: var(--text-primary);
        }

        .modal-title i {
            color: #8B5CF6;
        }

        .btn-close {
            filter: invert(1) brightness(2);
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
        }

        .btn-primary {
            background: var(--gradient-1);
            border: none;
            color: white;
        }

        .btn-primary:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        .modal-body .form-label {
            color: var(--text-secondary);
            font-size: 0.8rem;
            font-weight: 500;
        }

        .modal-body .form-control,
        .modal-body .form-select {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            color: var(--text-primary);
            border-radius: 12px;
            padding: 0.7rem 1rem;
        }

        .modal-body .form-control:focus,
        .modal-body .form-select:focus {
            border-color: #8B5CF6;
            box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15);
        }

        .modal-body .form-control::placeholder {
            color: var(--text-muted);
        }

        .modal-body .form-select option {
            background: var(--bg-secondary);
            color: var(--text-primary);
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            #content-wrapper {
                margin-left: 0;
                padding: 1rem;
            }

            .btn-toggle-sidebar {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .topbar {
                padding: 0.5rem 1rem;
                border-radius: 16px;
            }

            .page-title h1 { font-size: 1rem; }
            .page-title p { font-size: 0.7rem; }

            .topbar-user .user-name,
            .topbar-user .user-role { display: none; }

            .booking-card {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }

            .booking-card .booking-info {
                flex-direction: column;
                text-align: center;
            }

            .result-card {
                flex-direction: column;
                text-align: center;
                gap: 0.75rem;
            }

            .result-card .result-price {
                text-align: center;
            }

            .search-section {
                padding: 1rem;
            }
        }

        @media (max-width: 480px) {
            .result-card .result-actions {
                flex-direction: column;
                width: 100%;
            }

            .result-card .result-actions .btn-book-now,
            .result-card .result-actions .btn-view-details {
                width: 100%;
                text-align: center;
            }

            .booking-card .booking-actions {
                flex-direction: column;
                width: 100%;
            }

            .booking-card .booking-actions .btn-booking {
                width: 100%;
                text-align: center;
            }
        }

        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: var(--bg-primary); }
        ::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(139, 92, 246, 0.5); }

        .dropdown-menu {
            background: var(--bg-secondary) !important;
            border: 1px solid var(--glass-border) !important;
        }

        .dropdown-item {
            color: var(--text-secondary) !important;
        }

        .dropdown-item:hover {
            background: rgba(139, 92, 246, 0.1) !important;
            color: var(--text-primary) !important;
        }

        .dropdown-divider {
            border-color: var(--glass-border) !important;
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <a href="indexview.php" class="sidebar-brand">
            <div class="brand-icon"><i class="fas fa-home"></i></div>
            <div>
                <div class="brand-text">Graceful<span>Living</span></div>
                <span class="brand-sub">Management System</span>
            </div>
        </a>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Main</div>
            <div class="nav-item">
                <a href="indexview.php" class="nav-link">
                    <i class="fas fa-th-large"></i> Dashboard
                </a>
            </div>

            <div class="nav-section-label">Management</div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i> My Profile
                </a>
            </div>
            <div class="nav-item">
                <a href="viewrooms.php" class="nav-link">
                    <i class="fas fa-bed"></i> Rooms
                </a>
            </div>
            <div class="nav-item">
                <a href="booking.php" class="nav-link active">
                    <i class="fas fa-calendar-check"></i> Booking
                </a>
            </div>
            <div class="nav-item">
                <a href="facilities.php" class="nav-link">
                    <i class="fas fa-concierge-bell"></i> Facilities
                </a>
            </div>
            <div class="nav-item">
                <a href="payments.php" class="nav-link">
                    <i class="fas fa-credit-card"></i> Payments
                </a>
            </div>

            <div class="nav-section-label">Account</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </nav>

        <div class="sidebar-footer">
            <a href="profile.php" class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($user_name); ?></div>
                    <div class="role"><?php echo htmlspecialchars($user_role); ?></div>
                </div>
                <i class="fas fa-ellipsis-v" style="color: var(--text-muted); font-size: 0.7rem;"></i>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div id="content-wrapper">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left">
                <button class="btn-toggle-sidebar" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Booking</h1>
                    <p>Manage your room bookings</p>
                </div>
            </div>
            <div class="topbar-right">
                <a href="profile.php" class="topbar-user">
                    <div class="avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                    <div>
                        <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
                        <div class="user-role"><?php echo htmlspecialchars($user_role); ?></div>
                    </div>
                </a>
            </div>
        </header>

        <!-- Messages -->
        <?php if ($booking_message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i>
                <?php echo $booking_message; ?>
            </div>
        <?php endif; ?>

        <?php if ($booking_error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo $booking_error; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($search_error) && $search_error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo $search_error; ?>
            </div>
        <?php endif; ?>

        <!-- Active Bookings -->
        <?php if ($has_active_booking): ?>
            <div class="mb-4">
                <h5 class="mb-3"><i class="fas fa-clock me-2" style="color:#8B5CF6;"></i>Active Bookings</h5>
                <?php foreach ($active_bookings as $booking): ?>
                    <div class="booking-card">
                        <div class="booking-info">
                            <div class="booking-icon <?php echo $booking['status']; ?>">
                                <i class="fas <?php echo $booking['status'] === 'confirmed' ? 'fa-check' : 'fa-clock'; ?>"></i>
                            </div>
                            <div class="booking-details">
                                <div class="booking-room">
                                    Room <?php echo htmlspecialchars($booking['room_number']); ?>
                                    <span class="booking-status <?php echo $booking['status']; ?>">
                                        • <?php echo ucfirst($booking['status']); ?>
                                    </span>
                                </div>
                                <div class="booking-meta">
                                    Floor <?php echo htmlspecialchars($booking['floor']); ?> • 
                                    <?php echo ucfirst($booking['type']); ?> • 
                                    Move-in: <?php echo date('M j, Y', strtotime($booking['move_in_date'])); ?>
                                </div>
                            </div>
                        </div>
                        <div class="booking-actions">
                            <a href="room_details.php?id=<?php echo $booking['room_id']; ?>" class="btn-booking primary">
                                <i class="fas fa-eye me-1"></i>View Room
                            </a>
                            <a href="payments.php" class="btn-booking outline">
                                <i class="fas fa-credit-card me-1"></i>Payments
                            </a>
                            <?php if ($booking['status'] === 'pending'): ?>
                                <form method="POST" action="" style="display:inline;">
                                    <input type="hidden" name="allocation_id" value="<?php echo $booking['id']; ?>">
                                    <button type="submit" name="cancel_booking" class="btn-booking danger" 
                                            onclick="return confirm('Are you sure you want to cancel this booking?')">
                                        <i class="fas fa-times me-1"></i>Cancel
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Search Section -->
        <div class="search-section" id="search">
            <div class="search-title">
                <i class="fas fa-search"></i> Find Available Rooms
            </div>
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label><i class="fas fa-calendar-check me-1"></i> Check-in</label>
                            <input type="date" class="form-control" name="check_in" 
                                   min="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label><i class="fas fa-calendar-times me-1"></i> Check-out</label>
                            <input type="date" class="form-control" name="check_out" 
                                   min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" required>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label><i class="fas fa-users me-1"></i> Guests</label>
                            <select class="form-select" name="guests" required>
                                <?php for ($i = 1; $i <= 4; $i++): ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label><i class="fas fa-bed me-1"></i> Room Type</label>
                            <select class="form-select" name="room_type">
                                <option value="">All Types</option>
                                <?php foreach ($room_types as $type): ?>
                                    <option value="<?php echo htmlspecialchars($type); ?>">
                                        <?php echo ucfirst(htmlspecialchars($type)); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="submit" name="search_rooms" class="btn-search">
                                <i class="fas fa-search me-2"></i>Search
                            </button>
                        </div>
                    </div>
                </div>
            </form>

            <!-- Search Results -->
            <?php if ($search_performed): ?>
                <div class="search-results">
                    <?php if ($has_results): ?>
                        <div class="result-count">
                            <i class="fas fa-bed me-1"></i>
                            Found <?php echo count($search_results); ?> room(s) matching your criteria
                        </div>
                        <?php foreach ($search_results as $room): ?>
                            <?php 
                            $available_spots = ($room['available_spots'] ?? 0);
                            $status = $room['status'] ?? 'available';
                            ?>
                            <div class="result-card">
                                <div class="result-info">
                                    <div class="result-room">
                                        Room <?php echo htmlspecialchars($room['room_number']); ?>
                                        <small>• Floor <?php echo htmlspecialchars($room['floor']); ?></small>
                                    </div>
                                    <div class="result-details">
                                        <span class="badge" style="background:rgba(139,92,246,0.12);color:#8B5CF6;">
                                            <?php echo ucfirst($room['type'] ?? 'Standard'); ?>
                                        </span>
                                        <span class="badge" style="background:rgba(16,185,129,0.12);color:#10B981;margin-left:0.5rem;">
                                            <?php echo $available_spots; ?> spots left
                                        </span>
                                    </div>
                                </div>
                                <div class="result-price">
                                    <div class="price-amount">
                                        ₹<?php echo number_format($room['rent'] ?? 0); ?>
                                        <small>/month</small>
                                    </div>
                                    <div class="price-label" style="font-size:0.7rem;color:var(--text-muted);">
                                        Deposit: ₹<?php echo number_format(($room['rent'] ?? 0) * 2); ?>
                                    </div>
                                </div>
                                <div class="result-actions">
                                    <?php if (!$has_active_booking && $available_spots > 0 && $status === 'available'): ?>
                                        <button class="btn-book-now" onclick="openBookingModal(<?php echo $room['id']; ?>, '<?php echo $room['room_number']; ?>', <?php echo $room['rent']; ?>)">
                                            <i class="fas fa-calendar-plus me-1"></i>Book Now
                                        </button>
                                    <?php elseif ($has_active_booking): ?>
                                        <button class="btn-book-now" style="background:rgba(16,185,129,0.12);color:#10B981;cursor:not-allowed;" disabled>
                                            <i class="fas fa-check me-1"></i>Already Booked
                                        </button>
                                    <?php endif; ?>
                                    <a href="room_details.php?id=<?php echo $room['id']; ?>" class="btn-view-details">
                                        <i class="fas fa-eye me-1"></i>Details
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-door-closed"></i>
                            <h5>No Rooms Available</h5>
                            <p>No rooms match your search criteria. Try adjusting your filters.</p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Booking History -->
        <?php if (!empty($booking_history)): ?>
            <div class="mt-4">
                <h5 class="mb-3"><i class="fas fa-history me-2" style="color:#8B5CF6;"></i>Booking History</h5>
                <div class="history-table-wrap">
                    <table class="history-table">
                        <thead>
                            <tr>
                                <th>Room</th>
                                <th>Type</th>
                                <th>Move-in Date</th>
                                <th>Status</th>
                                <th>Booked On</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($booking_history as $booking): ?>
                                <tr>
                                    <td><strong>Room <?php echo htmlspecialchars($booking['room_number']); ?></strong></td>
                                    <td><?php echo ucfirst($booking['type']); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($booking['move_in_date'])); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $booking['status']; ?>">
                                            <?php echo ucfirst($booking['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M j, Y', strtotime($booking['created_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <!-- No Bookings Message -->
        <?php if (!$has_active_booking && empty($booking_history) && !$search_performed): ?>
            <div class="empty-state" style="background:rgba(18,18,26,0.6);border-radius:20px;border:1px solid var(--glass-border);padding:3rem;">
                <i class="fas fa-calendar-plus" style="font-size:3rem;color:var(--text-muted);"></i>
                <h5>No Bookings Yet</h5>
                <p style="color:var(--text-secondary);">Start by searching for available rooms above.</p>
                <a href="#search" class="btn-booking primary" style="display:inline-block;padding:0.6rem 2rem;margin-top:1rem;">
                    <i class="fas fa-search me-2"></i>Search Rooms
                </a>
            </div>
        <?php endif; ?>

        <!-- Footer -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Graceful Living — All rights reserved.</p>
        </footer>
    </div>

    <!-- Booking Modal -->
    <div class="modal fade" id="bookingModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">
                        <i class="fas fa-calendar-plus me-2"></i>Confirm Booking
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <div class="text-center mb-4">
                            <div style="width:64px;height:64px;background:rgba(139,92,246,0.1);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1rem;">
                                <i class="fas fa-bed" style="font-size:1.8rem;color:#8B5CF6;"></i>
                            </div>
                            <h5>Room Booking Confirmation</h5>
                            <p style="color:var(--text-secondary);font-size:0.85rem;">
                                You are about to book <strong id="modalRoomNumber">Room #</strong>
                            </p>
                        </div>

                        <input type="hidden" name="room_id" id="modalRoomId" value="">

                        <div class="row g-3">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label">Move-in Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" name="move_in_date" 
                                           min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label">Duration (Months)</label>
                                    <select class="form-select" name="duration">
                                        <?php for ($i = 1; $i <= 12; $i++): ?>
                                            <option value="<?php echo $i; ?>"><?php echo $i; ?> month<?php echo $i > 1 ? 's' : ''; ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label">Special Requirements</label>
                                    <textarea class="form-control" name="special_requirements" rows="3" 
                                              placeholder="Any special requests or requirements..."></textarea>
                                </div>
                            </div>
                        </div>

                        <div style="background:rgba(255,255,255,0.03);border-radius:12px;padding:1rem;border:1px solid var(--glass-border);margin-top:1rem;">
                            <div class="d-flex justify-content-between" style="padding:0.3rem 0;border-bottom:1px solid var(--glass-border);">
                                <span style="color:var(--text-muted);font-size:0.8rem;">Room Number</span>
                                <span style="font-weight:600;" id="modalRoomNumberDisplay">-</span>
                            </div>
                            <div class="d-flex justify-content-between" style="padding:0.3rem 0;border-bottom:1px solid var(--glass-border);">
                                <span style="color:var(--text-muted);font-size:0.8rem;">Monthly Rent</span>
                                <span style="font-weight:600;color:#10B981;" id="modalRoomPrice">₹0</span>
                            </div>
                            <div class="d-flex justify-content-between" style="padding:0.3rem 0;">
                                <span style="color:var(--text-muted);font-size:0.8rem;">Security Deposit</span>
                                <span style="font-weight:600;color:#F59E0B;" id="modalRoomDeposit">₹0</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-0">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="book_room" class="btn btn-primary">
                            <i class="fas fa-check me-2"></i>Confirm Booking
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Ready to Leave?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-secondary" style="color: var(--text-secondary) !important;">
                    Select "Logout" below if you are ready to end your current session.
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Sidebar Toggle
        $('#sidebarToggle').on('click', function() {
            $('#sidebar').toggleClass('open');
        });

        $(document).on('click', function(e) {
            if ($(window).width() <= 768) {
                if (!$(e.target).closest('#sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
                    $('#sidebar').removeClass('open');
                }
            }
        });

        // Booking Modal Functions
        function openBookingModal(roomId, roomNumber, rent) {
            document.getElementById('modalRoomId').value = roomId;
            document.getElementById('modalRoomNumber').textContent = 'Room ' + roomNumber;
            document.getElementById('modalRoomNumberDisplay').textContent = 'Room ' + roomNumber;
            document.getElementById('modalRoomPrice').textContent = '₹' + Number(rent).toLocaleString();
            document.getElementById('modalRoomDeposit').textContent = '₹' + (rent * 2).toLocaleString();
            
            // Set default move-in date to tomorrow
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            const dateInput = document.querySelector('input[name="move_in_date"]');
            if (dateInput) {
                dateInput.value = tomorrow.toISOString().split('T')[0];
            }
            
            $('#bookingModal').modal('show');
        }

        // Auto-close alerts after 5 seconds
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>