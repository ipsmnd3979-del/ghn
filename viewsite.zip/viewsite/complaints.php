<?php
// complaints.php - Complaint Submission and Tracking
session_start();
include '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'student';

// Get user's student details
$student = null;
try {
    $stmt = $db->prepare("SELECT * FROM students WHERE user_id = ? OR id = ?");
    $stmt->execute([$user_id, $user_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

$student_id = $student['id'] ?? 0;

// Get staff list for assignment
$staff_list = [];
try {
    $stmt = $db->query("SELECT id, name, position FROM staff WHERE status = 'active' ORDER BY name");
    $staff_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Handle complaint submission
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_complaint'])) {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = $_POST['category'] ?? 'other';
    $priority = $_POST['priority'] ?? 'medium';
    
    if (empty($title) || empty($description)) {
        $error = "Please fill in all required fields.";
    } else {
        try {
            $stmt = $db->prepare("
                INSERT INTO complaints 
                (student_id, title, description, category, priority, status) 
                VALUES (?, ?, ?, ?, ?, 'pending')
            ");
            $stmt->execute([$student_id, $title, $description, $category, $priority]);
            
            $message = "Complaint submitted successfully! We will address it shortly.";
        } catch (PDOException $e) {
            $error = "Failed to submit complaint: " . $e->getMessage();
        }
    }
}

// Fetch user's complaints
$complaints = [];
try {
    $stmt = $db->prepare("
        SELECT c.*, s.name as staff_name, s.position as staff_position
        FROM complaints c
        LEFT JOIN staff s ON c.assigned_to = s.id
        WHERE c.student_id = ?
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$student_id]);
    $complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Get complaint statistics
$stats = [
    'total' => 0,
    'pending' => 0,
    'in_progress' => 0,
    'resolved' => 0
];

foreach ($complaints as $c) {
    $stats['total']++;
    if ($c['status'] === 'pending') $stats['pending']++;
    elseif ($c['status'] === 'in_progress') $stats['in_progress']++;
    elseif ($c['status'] === 'resolved') $stats['resolved']++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaints - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --sidebar-width: 270px;
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) { width: 600px; height: 600px; background: #8B5CF6; top: -200px; left: -200px; animation-delay: 0s; }
        .bg-orbs:nth-child(2) { width: 400px; height: 400px; background: #EC4899; bottom: -150px; right: -100px; animation-delay: -7s; }
        .bg-orbs:nth-child(3) { width: 300px; height: 300px; background: #F59E0B; top: 50%; left: 50%; transform: translate(-50%, -50%); animation-delay: -14s; }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: rgba(18, 18, 26, 0.92);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--glass-border);
            z-index: 1000;
            padding: 1.5rem 0;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 1.5rem;
            text-decoration: none;
        }

        .sidebar-brand .brand-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-1);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
            margin-right: 12px;
            box-shadow: 0 4px 16px rgba(139, 92, 246, 0.3);
            flex-shrink: 0;
        }

        .sidebar-brand .brand-text {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .sidebar-brand .brand-text span { color: #8B5CF6; }
        .sidebar-brand .brand-sub {
            display: block;
            font-size: 0.55rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 0 0.75rem;
        }

        .sidebar-nav::-webkit-scrollbar { width: 4px; }
        .sidebar-nav::-webkit-scrollbar-track { background: transparent; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }

        .nav-section-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--text-muted);
            padding: 0.75rem 1rem 0.5rem;
        }

        .nav-item { margin-bottom: 2px; }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
            font-weight: 500;
            position: relative;
        }

        .nav-link i {
            width: 1.6rem;
            font-size: 1rem;
            color: var(--text-muted);
            transition: all 0.3s ease;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(139, 92, 246, 0.12);
            color: var(--text-primary);
        }

        .nav-link:hover i, .nav-link.active i { color: #8B5CF6; }

        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 24px;
            background: var(--gradient-1);
            border-radius: 0 4px 4px 0;
        }

        .sidebar-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .sidebar-footer .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.6rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .sidebar-footer .user-card:hover { background: rgba(255, 255, 255, 0.06); }

        .sidebar-footer .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            color: white;
            flex-shrink: 0;
        }

        .sidebar-footer .user-info { flex: 1; min-width: 0; }

        .sidebar-footer .user-info .name {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .sidebar-footer .user-info .role {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: capitalize;
        }

        #content-wrapper {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem 2rem;
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1.5rem;
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .btn-toggle-sidebar {
            display: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-toggle-sidebar:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .page-title h1 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .page-title p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .topbar-user:hover { background: rgba(255, 255, 255, 0.08); }

        .topbar-user .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .topbar-user .user-name {
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        .topbar-user .user-role {
            font-size: 0.65rem;
            color: var(--text-muted);
        }

        .alert {
            border-radius: 12px;
            border: none;
            padding: 0.8rem 1.2rem;
            font-size: 0.85rem;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.12);
            color: #34D399;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.12);
            color: #F87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        /* Stats Cards */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 1.25rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            border-color: rgba(139, 92, 246, 0.2);
            transform: translateY(-4px);
        }

        .stat-card .stat-number {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--text-primary);
        }

        .stat-card .stat-label {
            font-size: 0.7rem;
            color: var(--text-muted);
        }

        .stat-card .stat-icon {
            font-size: 1.5rem;
            margin-bottom: 0.3rem;
        }

        .stat-card:nth-child(1) .stat-icon { color: #8B5CF6; }
        .stat-card:nth-child(2) .stat-icon { color: #F59E0B; }
        .stat-card:nth-child(3) .stat-icon { color: #3B82F6; }
        .stat-card:nth-child(4) .stat-icon { color: #10B981; }

        /* Form Card */
        .form-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .form-card .card-title {
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 1.25rem;
        }

        .form-card .card-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        .form-group label {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 0.3rem;
            display: block;
        }

        .form-group label .required {
            color: #EF4444;
        }

        .form-control,
        .form-select {
            background: rgba(255, 255, 255, 0.04) !important;
            border: 1px solid var(--glass-border) !important;
            border-radius: 12px !important;
            padding: 0.7rem 1rem !important;
            color: var(--text-primary) !important;
            font-size: 0.85rem !important;
            transition: all 0.3s ease;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #8B5CF6 !important;
            box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15) !important;
        }

        .form-control::placeholder {
            color: var(--text-muted);
        }

        .form-select option {
            background: var(--bg-secondary);
            color: var(--text-primary);
        }

        textarea.form-control {
            resize: vertical;
            min-height: 100px;
        }

        .btn-submit {
            padding: 0.6rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            background: var(--gradient-1);
            border: none;
            color: white;
            transition: all 0.3s ease;
        }

        .btn-submit:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        /* Complaints List */
        .complaint-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 1.25rem;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
            border-left: 4px solid #8B5CF6;
        }

        .complaint-card:hover {
            border-color: rgba(139, 92, 246, 0.2);
        }

        .complaint-card.status-pending {
            border-left-color: #F59E0B;
        }

        .complaint-card.status-in_progress {
            border-left-color: #3B82F6;
        }

        .complaint-card.status-resolved {
            border-left-color: #10B981;
        }

        .complaint-card .complaint-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 0.5rem;
        }

        .complaint-card .complaint-title {
            font-weight: 600;
            font-size: 1rem;
        }

        .complaint-card .complaint-title .category-badge {
            font-size: 0.55rem;
            font-weight: 600;
            padding: 0.1rem 0.6rem;
            border-radius: 50px;
            text-transform: uppercase;
            margin-left: 0.5rem;
        }

        .category-badge.electrical { background: rgba(59, 130, 246, 0.15); color: #60A5FA; }
        .category-badge.plumbing { background: rgba(16, 185, 129, 0.15); color: #34D399; }
        .category-badge.cleaning { background: rgba(139, 92, 246, 0.15); color: #8B5CF6; }
        .category-badge.furniture { background: rgba(245, 158, 11, 0.15); color: #F59E0B; }
        .category-badge.security { background: rgba(239, 68, 68, 0.15); color: #F87171; }
        .category-badge.other { background: rgba(255, 255, 255, 0.04); color: var(--text-secondary); }

        .complaint-card .complaint-status {
            font-size: 0.6rem;
            font-weight: 600;
            padding: 0.15rem 0.7rem;
            border-radius: 50px;
            text-transform: uppercase;
        }

        .complaint-status.pending {
            background: rgba(245, 158, 11, 0.15);
            color: #F59E0B;
        }

        .complaint-status.in_progress {
            background: rgba(59, 130, 246, 0.15);
            color: #60A5FA;
        }

        .complaint-status.resolved {
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
        }

        .complaint-card .complaint-desc {
            color: var(--text-secondary);
            font-size: 0.85rem;
            margin-bottom: 0.5rem;
        }

        .complaint-card .complaint-meta {
            display: flex;
            gap: 1.5rem;
            font-size: 0.7rem;
            color: var(--text-muted);
        }

        .complaint-card .complaint-meta i {
            margin-right: 0.3rem;
        }

        .priority-badge {
            font-size: 0.5rem;
            font-weight: 600;
            padding: 0.1rem 0.5rem;
            border-radius: 50px;
            text-transform: uppercase;
        }

        .priority-badge.low { background: rgba(16, 185, 129, 0.15); color: #10B981; }
        .priority-badge.medium { background: rgba(245, 158, 11, 0.15); color: #F59E0B; }
        .priority-badge.high { background: rgba(239, 68, 68, 0.15); color: #EF4444; }

        .empty-state {
            text-align: center;
            padding: 3rem;
        }

        .empty-state i {
            font-size: 3rem;
            color: var(--text-muted);
            margin-bottom: 1rem;
        }

        .empty-state h5 {
            color: var(--text-primary);
        }

        .empty-state p {
            color: var(--text-secondary);
        }

        .footer {
            text-align: center;
            padding: 1.5rem 0 0.5rem;
            border-top: 1px solid var(--glass-border);
            margin-top: 2rem;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            #content-wrapper {
                margin-left: 0;
                padding: 1rem;
            }

            .btn-toggle-sidebar {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .topbar {
                padding: 0.5rem 1rem;
                border-radius: 16px;
            }

            .page-title h1 { font-size: 1rem; }
            .page-title p { font-size: 0.7rem; }

            .topbar-user .user-name,
            .topbar-user .user-role { display: none; }

            .stats-row {
                grid-template-columns: 1fr 1fr;
            }

            .complaint-card .complaint-header {
                flex-direction: column;
                gap: 0.5rem;
            }
        }

        @media (max-width: 480px) {
            .stats-row {
                grid-template-columns: 1fr;
            }
        }

        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: var(--bg-primary); }
        ::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(139, 92, 246, 0.5); }

        .dropdown-menu {
            background: var(--bg-secondary) !important;
            border: 1px solid var(--glass-border) !important;
        }

        .dropdown-item {
            color: var(--text-secondary) !important;
        }

        .dropdown-item:hover {
            background: rgba(139, 92, 246, 0.1) !important;
            color: var(--text-primary) !important;
        }

        .dropdown-divider {
            border-color: var(--glass-border) !important;
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <a href="indexview.php" class="sidebar-brand">
            <div class="brand-icon"><i class="fas fa-home"></i></div>
            <div>
                <div class="brand-text">Graceful<span>Living</span></div>
                <span class="brand-sub">Management System</span>
            </div>
        </a>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Main</div>
            <div class="nav-item">
                <a href="indexview.php" class="nav-link">
                    <i class="fas fa-th-large"></i> Dashboard
                </a>
            </div>

            <div class="nav-section-label">Management</div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i> My Profile
                </a>
            </div>
            <div class="nav-item">
                <a href="viewrooms.php" class="nav-link">
                    <i class="fas fa-bed"></i> Rooms
                </a>
            </div>
            <div class="nav-item">
                <a href="booking.php" class="nav-link">
                    <i class="fas fa-calendar-check"></i> Booking
                </a>
            </div>
            <div class="nav-item">
                <a href="complaints.php" class="nav-link active">
                    <i class="fas fa-exclamation-circle"></i> Complaints
                </a>
            </div>
            <div class="nav-item">
                <a href="payments.php" class="nav-link">
                    <i class="fas fa-credit-card"></i> Payments
                </a>
            </div>

            <div class="nav-section-label">Account</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </nav>

        <div class="sidebar-footer">
            <a href="profile.php" class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($user_name); ?></div>
                    <div class="role"><?php echo htmlspecialchars($user_role); ?></div>
                </div>
                <i class="fas fa-ellipsis-v" style="color: var(--text-muted); font-size: 0.7rem;"></i>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div id="content-wrapper">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left">
                <button class="btn-toggle-sidebar" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Complaints</h1>
                    <p>Submit and track your complaints</p>
                </div>
            </div>
            <div class="topbar-right">
                <a href="profile.php" class="topbar-user">
                    <div class="avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                    <div>
                        <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
                        <div class="user-role"><?php echo htmlspecialchars($user_role); ?></div>
                    </div>
                </a>
            </div>
        </header>

        <!-- Messages -->
        <?php if ($message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <!-- Statistics -->
        <?php if ($stats['total'] > 0): ?>
            <div class="stats-row">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-list"></i></div>
                    <div class="stat-number"><?php echo $stats['total']; ?></div>
                    <div class="stat-label">Total Complaints</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-number"><?php echo $stats['pending']; ?></div>
                    <div class="stat-label">Pending</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-spinner"></i></div>
                    <div class="stat-number"><?php echo $stats['in_progress']; ?></div>
                    <div class="stat-label">In Progress</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-number"><?php echo $stats['resolved']; ?></div>
                    <div class="stat-label">Resolved</div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Submit Complaint Form -->
        <div class="form-card">
            <div class="card-title">
                <i class="fas fa-plus-circle"></i> Submit a Complaint
            </div>
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Title <span class="required">*</span></label>
                            <input type="text" class="form-control" name="title" placeholder="Brief title of the issue" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Category <span class="required">*</span></label>
                            <select class="form-select" name="category" required>
                                <option value="electrical">Electrical</option>
                                <option value="plumbing">Plumbing</option>
                                <option value="cleaning">Cleaning</option>
                                <option value="furniture">Furniture</option>
                                <option value="security">Security</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Description <span class="required">*</span></label>
                            <textarea class="form-control" name="description" placeholder="Describe your issue in detail..." required></textarea>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Priority</label>
                            <select class="form-select" name="priority">
                                <option value="low">Low</option>
                                <option value="medium" selected>Medium</option>
                                <option value="high">High</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-items-end">
                        <button type="submit" name="submit_complaint" class="btn-submit w-100">
                            <i class="fas fa-paper-plane me-2"></i>Submit Complaint
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Complaints List -->
        <h5 class="mb-3"><i class="fas fa-list me-2" style="color:#8B5CF6;"></i>My Complaints</h5>
        
        <?php if (!empty($complaints)): ?>
            <?php foreach ($complaints as $complaint): ?>
                <div class="complaint-card status-<?php echo $complaint['status']; ?>">
                    <div class="complaint-header">
                        <div class="complaint-title">
                            <?php echo htmlspecialchars($complaint['title']); ?>
                            <span class="category-badge <?php echo $complaint['category']; ?>">
                                <?php echo ucfirst($complaint['category']); ?>
                            </span>
                            <span class="priority-badge <?php echo $complaint['priority']; ?>">
                                <i class="fas fa-flag me-1"></i><?php echo ucfirst($complaint['priority']); ?>
                            </span>
                        </div>
                        <span class="complaint-status <?php echo $complaint['status']; ?>">
                            <?php if ($complaint['status'] === 'pending'): ?>
                                <i class="fas fa-clock me-1"></i>
                            <?php elseif ($complaint['status'] === 'in_progress'): ?>
                                <i class="fas fa-spinner me-1"></i>
                            <?php else: ?>
                                <i class="fas fa-check me-1"></i>
                            <?php endif; ?>
                            <?php echo ucfirst(str_replace('_', ' ', $complaint['status'])); ?>
                        </span>
                    </div>
                    <div class="complaint-desc">
                        <?php echo htmlspecialchars($complaint['description']); ?>
                    </div>
                    <div class="complaint-meta">
                        <span><i class="far fa-calendar-alt"></i> <?php echo date('M j, Y g:i A', strtotime($complaint['created_at'])); ?></span>
                        <?php if ($complaint['staff_name']): ?>
                            <span><i class="fas fa-user-tie"></i> Assigned to: <?php echo htmlspecialchars($complaint['staff_name']); ?></span>
                        <?php endif; ?>
                        <?php if ($complaint['resolved_at']): ?>
                            <span><i class="fas fa-check-circle" style="color:#10B981;"></i> Resolved: <?php echo date('M j, Y', strtotime($complaint['resolved_at'])); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state" style="background:rgba(18,18,26,0.6);border-radius:20px;border:1px solid var(--glass-border);">
                <i class="fas fa-check-circle" style="color:#10B981;"></i>
                <h5>No Complaints</h5>
                <p>You haven't submitted any complaints yet. If you have an issue, feel free to submit one above.</p>
            </div>
        <?php endif; ?>

        <!-- Footer -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Graceful Living — All rights reserved.</p>
        </footer>
    </div>

    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Ready to Leave?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-secondary" style="color: var(--text-secondary) !important;">
                    Select "Logout" below if you are ready to end your current session.
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $('#sidebarToggle').on('click', function() {
            $('#sidebar').toggleClass('open');
        });

        $(document).on('click', function(e) {
            if ($(window).width() <= 768) {
                if (!$(e.target).closest('#sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
                    $('#sidebar').removeClass('open');
                }
            }
        });

        // Auto-close alerts
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>