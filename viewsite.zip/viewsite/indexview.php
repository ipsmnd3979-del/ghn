<?php
// indexview.php - Updated with Booking, Facilities, and Search Room Section
session_start();
include '../config/database.php';

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Get user data
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'guest';
$user_email = $_SESSION['user_email'] ?? '';
$user_id = $_SESSION['user_id'] ?? 0;

// Fetch statistics for dashboard
$stats = [];
try {
    // Total students
    $stmt = $db->query("SELECT COUNT(*) as total_students FROM students WHERE status = 'active'");
    $stats['total_students'] = $stmt->fetchColumn();

    // Total rooms
    $stmt = $db->query("SELECT COUNT(*) as total_rooms FROM rooms");
    $stats['total_rooms'] = $stmt->fetchColumn();

    // Available rooms
    $stmt = $db->query("SELECT COUNT(*) as available_rooms FROM rooms WHERE status = 'available'");
    $stats['available_rooms'] = $stmt->fetchColumn();

    // Pending complaints
    $stmt = $db->query("SELECT COUNT(*) as pending_complaints FROM complaints WHERE status = 'pending'");
    $stats['pending_complaints'] = $stmt->fetchColumn();

    // Total staff
    $stmt = $db->query("SELECT COUNT(*) as total_staff FROM staff WHERE status = 'active'");
    $stats['total_staff'] = $stmt->fetchColumn();

    // Payment statistics
    $stmt = $db->query("SELECT 
        COUNT(*) as total_payments,
        SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) as total_collected,
        SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) as total_pending
        FROM payments");
    $payment_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats = array_merge($stats, $payment_stats);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch recent announcements
$announcements = [];
try {
    $stmt = $db->query("SELECT * FROM announcements WHERE is_active = 1 ORDER BY created_at DESC LIMIT 5");
    $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch available rooms with proper capacity calculation
$available_rooms = [];
try {
    $stmt = $db->query("SELECT r.*, 
                       COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0) as occupied_count
                       FROM rooms r 
                       WHERE r.status = 'available' 
                       ORDER BY r.rent ASC 
                       LIMIT 6");
    $available_rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch room types for search filter
$room_types = [];
try {
    $stmt = $db->query("SELECT DISTINCT type FROM rooms");
    $room_types = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $room_types = [];
}

// Handle room search
$search_results = [];
$search_performed = false;
$has_results = false;
$search_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search_rooms'])) {
    $search_performed = true;
    $check_in = $_POST['check_in'] ?? '';
    $check_out = $_POST['check_out'] ?? '';
    $guests = (int)($_POST['guests'] ?? 1);
    $room_type = $_POST['room_type'] ?? '';
    
    if (empty($check_in) || empty($check_out)) {
        $search_error = "Please select both check-in and check-out dates.";
    } elseif ($check_in >= $check_out) {
        $search_error = "Check-out date must be after check-in date.";
    } else {
        $sql = "
            SELECT r.*, 
                   COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0) as occupied_count,
                   (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) as available_spots
            FROM rooms r 
            WHERE r.status = 'available' 
            AND (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) >= ?
        ";
        
        $params = [$guests];
        
        if (!empty($room_type)) {
            $sql .= " AND r.type = ?";
            $params[] = $room_type;
        }
        
        $sql .= " ORDER BY r.rent ASC LIMIT 10";
        
        try {
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $search_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $has_results = !empty($search_results);
        } catch (PDOException $e) {
            $search_error = "Search failed: " . $e->getMessage();
        }
    }
}

// Fetch today's mess menu
$today_menu = [];
try {
    $day = strtolower(date('l'));
    $stmt = $db->prepare("SELECT * FROM mess_menu WHERE day = ? AND is_current = 1");
    $stmt->execute([$day]);
    $today_menu = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch recent payments (if user is logged in)
$recent_payments = [];
if (isset($_SESSION['user_id'])) {
    try {
        if ($_SESSION['user_role'] === 'student') {
            $stmt = $db->prepare("SELECT p.*, s.name as student_name 
                                FROM payments p 
                                JOIN students s ON p.student_id = s.id 
                                WHERE p.student_id = ? 
                                ORDER BY p.created_at DESC 
                                LIMIT 5");
            $stmt->execute([$_SESSION['user_id']]);
        } else {
            $stmt = $db->query("SELECT p.*, s.name as student_name 
                              FROM payments p 
                              JOIN students s ON p.student_id = s.id 
                              ORDER BY p.created_at DESC 
                              LIMIT 5");
        }
        $recent_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
    }
}

// Fetch user's booking status
$user_booking = null;
$has_booking = false;
if (isset($_SESSION['user_id']) && $_SESSION['user_role'] === 'student') {
    try {
        $stmt = $db->prepare("
            SELECT ra.*, r.room_number 
            FROM room_allocations ra
            JOIN rooms r ON ra.room_id = r.id
            WHERE ra.student_id = ? AND ra.status IN ('pending', 'confirmed')
            LIMIT 1
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $user_booking = $stmt->fetch(PDO::FETCH_ASSOC);
        $has_booking = !empty($user_booking);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Graceful Living - Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="https://i.im.ge/2025/11/21/42uJYF.50340aa0cf39ee714ff31e1c53d403ba-removebg-preview.png" type="image/x-icon">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --gradient-2: linear-gradient(135deg, #3B82F6, #8B5CF6);
            --gradient-3: linear-gradient(135deg, #10B981, #34D399);
            --gradient-4: linear-gradient(135deg, #F59E0B, #FBBF24);
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Animated Background */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) {
            width: 600px;
            height: 600px;
            background: #8B5CF6;
            top: -200px;
            left: -200px;
            animation-delay: 0s;
        }

        .bg-orbs:nth-child(2) {
            width: 400px;
            height: 400px;
            background: #EC4899;
            bottom: -150px;
            right: -100px;
            animation-delay: -7s;
        }

        .bg-orbs:nth-child(3) {
            width: 300px;
            height: 300px;
            background: #3B82F6;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation-delay: -14s;
        }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        /* Top Navigation */
        .top-nav {
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(10, 10, 15, 0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--glass-border);
            padding: 0.75rem 2rem;
        }

        .top-nav .nav-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
        }

        .top-nav .brand-icon {
            width: 40px;
            height: 40px;
            background: var(--gradient-1);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            color: white;
        }

        .top-nav .brand-text {
            font-size: 1rem;
            font-weight: 800;
            color: var(--text-primary);
        }

        .top-nav .brand-text span {
            color: #8B5CF6;
        }

        .top-nav .brand-sub {
            display: block;
            font-size: 0.5rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .top-nav .nav-links {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .top-nav .nav-link {
            color: var(--text-secondary);
            padding: 0.4rem 1rem;
            border-radius: 10px;
            font-size: 0.8rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .top-nav .nav-link:hover,
        .top-nav .nav-link.active {
            background: rgba(139, 92, 246, 0.1);
            color: var(--text-primary);
        }

        .top-nav .nav-link.active {
            color: #8B5CF6;
        }

        .top-nav .auth-btn {
            padding: 0.4rem 1.2rem;
            border-radius: 10px;
            font-size: 0.8rem;
            font-weight: 600;
            border: none;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .top-nav .auth-btn.login {
            background: transparent;
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
        }

        .top-nav .auth-btn.login:hover {
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-primary);
        }

        .top-nav .auth-btn.register {
            background: var(--gradient-1);
            color: white;
        }

        .top-nav .auth-btn.register:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        .top-nav .user-dropdown {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: var(--text-primary);
        }

        .top-nav .user-dropdown:hover {
            background: rgba(255, 255, 255, 0.08);
        }

        .top-nav .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .top-nav .user-name {
            font-size: 0.8rem;
            font-weight: 500;
        }

        /* Hero Section */
        .hero-section {
            position: relative;
            z-index: 1;
            padding: 4rem 2rem 3rem;
            text-align: center;
        }

        .hero-section .hero-badge {
            display: inline-block;
            padding: 0.2rem 1rem;
            background: rgba(139, 92, 246, 0.12);
            border: 1px solid rgba(139, 92, 246, 0.2);
            border-radius: 50px;
            font-size: 0.7rem;
            font-weight: 600;
            color: #8B5CF6;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            margin-bottom: 1rem;
        }

        .hero-section h1 {
            font-size: 3rem;
            font-weight: 900;
            margin-bottom: 0.5rem;
            letter-spacing: -1px;
        }

        .hero-section h1 .highlight {
            background: var(--gradient-1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero-section p {
            color: var(--text-secondary);
            font-size: 1.1rem;
            max-width: 600px;
            margin: 0 auto 2rem;
        }

        .hero-section .hero-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .hero-section .btn-primary {
            background: var(--gradient-1);
            border: none;
            color: white;
            padding: 0.6rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .hero-section .btn-primary:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        .hero-section .btn-secondary {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            padding: 0.6rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .hero-section .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        /* Booking Status Alert */
        .booking-alert {
            position: relative;
            z-index: 1;
            max-width: 1100px;
            margin: -1rem auto 1.5rem;
            padding: 0 1rem;
        }

        .booking-alert .alert {
            border-radius: 16px;
            border: 1px solid var(--glass-border);
            padding: 0.8rem 1.5rem;
            background: rgba(18, 18, 26, 0.8);
            backdrop-filter: blur(20px);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .booking-alert .alert .alert-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .booking-alert .alert .alert-icon.pending {
            background: rgba(245, 158, 11, 0.15);
            color: #F59E0B;
        }

        .booking-alert .alert .alert-icon.confirmed {
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
        }

        .booking-alert .alert .alert-content {
            flex: 1;
            padding: 0 1rem;
        }

        .booking-alert .alert .alert-content .alert-title {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .booking-alert .alert .alert-content .alert-text {
            font-size: 0.75rem;
            color: var(--text-secondary);
        }

        .booking-alert .alert .alert-actions {
            display: flex;
            gap: 0.5rem;
        }

        .booking-alert .alert .btn-alert {
            padding: 0.3rem 1rem;
            border-radius: 8px;
            font-size: 0.7rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-alert.primary {
            background: var(--gradient-1);
            color: white;
            border: none;
        }

        .btn-alert.primary:hover {
            opacity: 0.9;
            color: white;
        }

        .btn-alert.outline {
            background: transparent;
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
        }

        .btn-alert.outline:hover {
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-primary);
        }

        /* Search Section */
        .search-section {
            position: relative;
            z-index: 1;
            max-width: 1100px;
            margin: 0 auto 2.5rem;
            padding: 0 1rem;
        }

        .search-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 24px;
            padding: 2rem;
            box-shadow: var(--shadow-glow);
        }

        .search-card .search-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .search-card .search-header .search-icon {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            background: rgba(139, 92, 246, 0.12);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: #8B5CF6;
        }

        .search-card .search-header .search-title {
            font-size: 1.1rem;
            font-weight: 700;
        }

        .search-card .search-header .search-subtitle {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        .search-card .form-group {
            margin-bottom: 1rem;
        }

        .search-card label {
            font-size: 0.7rem;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.3rem;
            display: block;
        }

        .search-card .form-control,
        .search-card .form-select {
            background: rgba(255, 255, 255, 0.04) !important;
            border: 1px solid var(--glass-border) !important;
            border-radius: 12px !important;
            padding: 0.7rem 1rem !important;
            color: var(--text-primary) !important;
            font-size: 0.85rem !important;
            transition: all 0.3s ease;
        }

        .search-card .form-control:focus,
        .search-card .form-select:focus {
            border-color: #8B5CF6 !important;
            box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15) !important;
            background: rgba(255, 255, 255, 0.06) !important;
        }

        .search-card .form-control::placeholder {
            color: var(--text-muted);
        }

        .search-card .form-select option {
            background: var(--bg-secondary);
            color: var(--text-primary);
        }

        .btn-search {
            width: 100%;
            padding: 0.75rem;
            border-radius: 12px;
            font-weight: 600;
            background: var(--gradient-1);
            border: none;
            color: white;
            transition: all 0.3s ease;
        }

        .btn-search:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        /* Search Results */
        .search-results {
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .search-results .result-count {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }

        .result-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1rem;
            background: rgba(255, 255, 255, 0.02);
            border-radius: 12px;
            border: 1px solid var(--glass-border);
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
        }

        .result-item:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(139, 92, 246, 0.2);
        }

        .result-item .result-info .result-room {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .result-item .result-info .result-room small {
            font-size: 0.65rem;
            font-weight: 400;
            color: var(--text-muted);
        }

        .result-item .result-info .result-type {
            font-size: 0.65rem;
            color: var(--text-secondary);
        }

        .result-item .result-price {
            font-size: 0.9rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .result-item .result-price small {
            font-size: 0.6rem;
            font-weight: 400;
            color: var(--text-muted);
        }

        .result-item .btn-result {
            padding: 0.3rem 1rem;
            border-radius: 8px;
            font-size: 0.7rem;
            font-weight: 500;
            background: var(--gradient-1);
            border: none;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .result-item .btn-result:hover {
            opacity: 0.9;
            transform: translateY(-1px);
            color: white;
        }

        .result-item .btn-result-outline {
            padding: 0.3rem 1rem;
            border-radius: 8px;
            font-size: 0.7rem;
            font-weight: 500;
            background: transparent;
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .result-item .btn-result-outline:hover {
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-primary);
        }

        .search-empty {
            text-align: center;
            padding: 1.5rem;
            color: var(--text-muted);
        }

        .search-empty i {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            display: block;
        }

        /* Stats Section */
        .stats-section {
            position: relative;
            z-index: 1;
            max-width: 1100px;
            margin: 0 auto 3rem;
            padding: 0 1rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 1rem;
        }

        .stat-item {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 1.25rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .stat-item:hover {
            transform: translateY(-4px);
            border-color: rgba(139, 92, 246, 0.2);
            box-shadow: var(--shadow-glow);
        }

        .stat-item .stat-number {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .stat-item .stat-number .currency {
            font-size: 1rem;
            color: var(--text-muted);
        }

        .stat-item .stat-label {
            font-size: 0.65rem;
            color: var(--text-muted);
            font-weight: 500;
            margin-top: 0.1rem;
        }

        .stat-item .stat-icon {
            font-size: 1.2rem;
            margin-bottom: 0.3rem;
        }

        .stat-item:nth-child(1) .stat-icon { color: #8B5CF6; }
        .stat-item:nth-child(2) .stat-icon { color: #10B981; }
        .stat-item:nth-child(3) .stat-icon { color: #3B82F6; }
        .stat-item:nth-child(4) .stat-icon { color: #F59E0B; }
        .stat-item:nth-child(5) .stat-icon { color: #EC4899; }
        .stat-item:nth-child(6) .stat-icon { color: #34D399; }

        /* Main Content */
        .main-content {
            position: relative;
            z-index: 1;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem 2rem;
        }

        /* Section Title */
        .section-title {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.5rem;
        }

        .section-title h2 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
        }

        .section-title h2 i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .section-title .view-all {
            font-size: 0.7rem;
            color: #8B5CF6;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .section-title .view-all:hover {
            color: #EC4899;
        }

        /* Room Cards */
        .rooms-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 1.25rem;
            margin-bottom: 2.5rem;
        }

        .room-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.25rem;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        .room-card:hover {
            transform: translateY(-6px);
            border-color: rgba(139, 92, 246, 0.2);
            box-shadow: var(--shadow-glow);
        }

        .room-card .card-glow {
            position: absolute;
            top: -50%;
            right: -30%;
            width: 150px;
            height: 150px;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.05;
            pointer-events: none;
        }

        .room-card .room-top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }

        .room-card .room-number {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .room-card .room-number small {
            font-size: 0.6rem;
            font-weight: 400;
            color: var(--text-muted);
        }

        .room-card .room-type-badge {
            font-size: 0.55rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.15rem 0.7rem;
            border-radius: 50px;
            background: rgba(139, 92, 246, 0.15);
            color: #8B5CF6;
        }

        .room-card .room-price {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--text-primary);
            margin: 0.25rem 0;
        }

        .room-card .room-price small {
            font-size: 0.65rem;
            font-weight: 400;
            color: var(--text-muted);
        }

        .room-card .room-capacity {
            font-size: 0.7rem;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }

        .room-card .room-capacity .progress {
            height: 3px;
            background: rgba(255, 255, 255, 0.06);
            border-radius: 2px;
            margin-top: 4px;
        }

        .room-card .room-capacity .progress-bar {
            background: var(--gradient-3);
            border-radius: 2px;
        }

        .room-card .room-facilities {
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
            margin-bottom: 0.75rem;
        }

        .room-card .facility-tag {
            font-size: 0.5rem;
            padding: 0.1rem 0.5rem;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            border-radius: 50px;
            color: var(--text-secondary);
        }

        .room-card .btn-details {
            width: 100%;
            padding: 0.4rem;
            border-radius: 10px;
            font-size: 0.7rem;
            font-weight: 600;
            background: var(--gradient-1);
            border: none;
            color: white;
            transition: all 0.3s ease;
            text-decoration: none;
            display: block;
            text-align: center;
        }

        .room-card .btn-details:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        /* Payment Table */
        .payment-table-wrap {
            overflow-x: auto;
            margin-bottom: 2.5rem;
        }

        .payment-table {
            width: 100%;
            border-collapse: collapse;
        }

        .payment-table th {
            font-size: 0.6rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-muted);
            padding: 0.5rem 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--glass-border);
        }

        .payment-table td {
            padding: 0.6rem 0.75rem;
            font-size: 0.8rem;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--glass-border);
        }

        .payment-table tr:last-child td {
            border-bottom: none;
        }

        .payment-table td strong {
            color: var(--text-primary);
        }

        .payment-table .status-badge {
            font-size: 0.55rem;
            font-weight: 600;
            padding: 0.15rem 0.6rem;
            border-radius: 50px;
            text-transform: uppercase;
        }

        .status-badge.paid {
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
        }

        .status-badge.pending {
            background: rgba(245, 158, 11, 0.15);
            color: #F59E0B;
        }

        .status-badge.overdue {
            background: rgba(239, 68, 68, 0.15);
            color: #EF4444;
        }

        /* Right Sidebar */
        .sidebar-right {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .sidebar-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.25rem;
        }

        .sidebar-card .card-title {
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .sidebar-card .card-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        /* Quick Actions */
        .quick-actions-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.5rem;
        }

        .quick-action {
            padding: 0.75rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--glass-border);
            text-align: center;
            text-decoration: none;
            color: var(--text-secondary);
            transition: all 0.3s ease;
        }

        .quick-action:hover {
            background: rgba(255, 255, 255, 0.06);
            transform: translateY(-2px);
            color: var(--text-primary);
        }

        .quick-action i {
            font-size: 1.3rem;
            margin-bottom: 0.25rem;
            display: block;
        }

        .quick-action .action-label {
            font-size: 0.6rem;
            font-weight: 500;
        }

        .quick-action:nth-child(1) i { color: #8B5CF6; }
        .quick-action:nth-child(2) i { color: #10B981; }
        .quick-action:nth-child(3) i { color: #F59E0B; }
        .quick-action:nth-child(4) i { color: #3B82F6; }

        /* Mess Menu */
        .mess-menu-item {
            padding: 0.4rem 0;
            border-bottom: 1px solid var(--glass-border);
        }

        .mess-menu-item:last-child {
            border-bottom: none;
        }

        .mess-menu-item .menu-label {
            font-size: 0.6rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
            letter-spacing: 0.5px;
        }

        .mess-menu-item .menu-value {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        .mess-menu-item .menu-value .highlight-text {
            color: #10B981;
        }

        .mess-menu .btn-menu {
            width: 100%;
            padding: 0.4rem;
            border-radius: 10px;
            font-size: 0.7rem;
            font-weight: 500;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            transition: all 0.3s ease;
            text-decoration: none;
            display: block;
            text-align: center;
            margin-top: 0.5rem;
        }

        .mess-menu .btn-menu:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        /* Announcements */
        .announcement-item {
            padding: 0.75rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.02);
            border-left: 3px solid #8B5CF6;
            margin-bottom: 0.5rem;
        }

        .announcement-item:last-child {
            margin-bottom: 0;
        }

        .announcement-item .announce-title {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .announcement-item .announce-text {
            font-size: 0.7rem;
            color: var(--text-secondary);
            margin: 0.1rem 0 0.2rem;
        }

        .announcement-item .announce-time {
            font-size: 0.55rem;
            color: var(--text-muted);
        }

        .announcement-item.priority-high {
            border-left-color: #EF4444;
        }

        .announcement-item.priority-medium {
            border-left-color: #F59E0B;
        }

        .announcement-item.priority-low {
            border-left-color: #8B5CF6;
        }

        /* Layout */
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 1.5rem;
        }

        /* Footer */
        .footer {
            position: relative;
            z-index: 1;
            text-align: center;
            padding: 2rem 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
            max-width: 1200px;
            margin: 0 auto;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        .footer .footer-links {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            margin-top: 0.5rem;
            flex-wrap: wrap;
        }

        .footer .footer-links a {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.7rem;
            transition: color 0.3s ease;
        }

        .footer .footer-links a:hover {
            color: var(--text-secondary);
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .stats-grid {
                grid-template-columns: repeat(3, 1fr);
            }

            .content-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .top-nav {
                padding: 0.5rem 1rem;
            }

            .top-nav .nav-links .nav-link {
                display: none;
            }

            .top-nav .nav-links .mobile-show {
                display: inline-block;
            }

            .hero-section h1 {
                font-size: 2rem;
            }

            .hero-section p {
                font-size: 0.9rem;
            }

            .stats-grid {
                grid-template-columns: repeat(3, 1fr);
                gap: 0.5rem;
            }

            .stat-item {
                padding: 0.75rem;
            }

            .stat-item .stat-number {
                font-size: 1.2rem;
            }

            .stat-item .stat-label {
                font-size: 0.55rem;
            }

            .rooms-grid {
                grid-template-columns: 1fr 1fr;
            }

            .quick-actions-grid {
                grid-template-columns: 1fr 1fr;
            }

            .search-card {
                padding: 1.25rem;
            }

            .booking-alert .alert {
                flex-direction: column;
                text-align: center;
                gap: 0.5rem;
            }

            .booking-alert .alert .alert-actions {
                flex-wrap: wrap;
                justify-content: center;
            }

            .result-item {
                flex-direction: column;
                text-align: center;
                gap: 0.5rem;
            }
        }

        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .rooms-grid {
                grid-template-columns: 1fr;
            }

            .hero-section h1 {
                font-size: 1.6rem;
            }

            .hero-section .hero-buttons {
                flex-direction: column;
                align-items: center;
            }

            .hero-section .btn-primary,
            .hero-section .btn-secondary {
                width: 100%;
                text-align: center;
            }
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg-primary);
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(139, 92, 246, 0.3);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: rgba(139, 92, 246, 0.5);
        }

        .dropdown-menu {
            background: var(--bg-secondary) !important;
            border: 1px solid var(--glass-border) !important;
        }

        .dropdown-item {
            color: var(--text-secondary) !important;
        }

        .dropdown-item:hover {
            background: rgba(139, 92, 246, 0.1) !important;
            color: var(--text-primary) !important;
        }

        .dropdown-divider {
            border-color: var(--glass-border) !important;
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Top Navigation -->
    <nav class="top-nav">
        <div class="d-flex align-items-center justify-content-between">
            <a href="indexview.php" class="nav-brand">
                <div class="brand-icon">
                    <i class="fas fa-home"></i>
                </div>
                <div>
                    <div class="brand-text">Graceful<span>Living</span></div>
                    <span class="brand-sub">Girls Hostel</span>
                </div>
            </a>
            <div class="nav-links">
                <a href="indexview.php" class="nav-link active">Home</a>
                <a href="viewrooms.php" class="nav-link">Rooms</a>
                <a href="booking.php" class="nav-link">Booking</a>
                <a href="facilities.php" class="nav-link">Facilities</a>
                <a href="gallery.php" class="nav-link">Gallery</a>
                <a href="payments.php" class="nav-link">Payments</a>
                <a href="contact.php" class="nav-link">Contact</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="indexview.php" class="user-dropdown" data-bs-toggle="dropdown">
                        <div class="user-avatar"><?php echo substr($_SESSION['user_name'] ?? 'U', 0, 1); ?></div>
                        <span class="user-name"><?php echo $_SESSION['user_name'] ?? 'User'; ?></span>
                        <i class="fas fa-chevron-down" style="font-size:0.6rem; color: var(--text-muted);"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end">
                        <a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a>
                        <a class="dropdown-item" href="booking.php"><i class="fas fa-calendar-check me-2"></i>My Bookings</a>
                        <a class="dropdown-item" href="payments.php"><i class="fas fa-credit-card me-2"></i>Payments</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="auth-btn login">Login</a>
                    <a href="register.php" class="auth-btn register">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Booking Status Alert -->
    <?php if ($has_booking && $user_booking): ?>
    <div class="booking-alert">
        <div class="alert">
            <div class="d-flex align-items-center" style="flex:1;">
                <div class="alert-icon <?php echo $user_booking['status']; ?>">
                    <i class="fas <?php echo $user_booking['status'] === 'confirmed' ? 'fa-check' : 'fa-clock'; ?>"></i>
                </div>
                <div class="alert-content">
                    <div class="alert-title">Booking <?php echo ucfirst($user_booking['status']); ?></div>
                    <div class="alert-text">
                        Room <?php echo htmlspecialchars($user_booking['room_number']); ?> • 
                        Move-in: <?php echo date('M j, Y', strtotime($user_booking['move_in_date'])); ?>
                    </div>
                </div>
            </div>
            <div class="alert-actions">
                <a href="booking.php" class="btn-alert primary">
                    <i class="fas fa-eye me-1"></i>View
                </a>
                <a href="room_details.php?id=<?php echo $user_booking['room_id']; ?>" class="btn-alert outline">
                    <i class="fas fa-bed me-1"></i>Room
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="hero-badge">
            <i class="fas fa-star me-1"></i> Premium Girls Hostel
        </div>
        <h1>Welcome to <span class="highlight">Graceful Living</span></h1>
        <p>A safe, comfortable and vibrant home away from home for female students</p>
        <div class="hero-buttons">
            <a href="viewrooms.php" class="btn-primary">
                <i class="fas fa-search me-2"></i>View Available Rooms
            </a>
            <a href="booking.php" class="btn-secondary">
                <i class="fas fa-calendar-alt me-2"></i>Book a Room
            </a>
            <a href="facilities.php" class="btn-secondary">
                <i class="fas fa-concierge-bell me-2"></i>Our Facilities
            </a>
        </div>
    </section>

    <!-- Search Room Section -->
    <section class="search-section">
        <div class="search-card">
            <div class="search-header">
                <div class="search-icon">
                    <i class="fas fa-search"></i>
                </div>
                <div>
                    <div class="search-title">Find Your Room</div>
                    <div class="search-subtitle">Search available rooms based on your preferences</div>
                </div>
            </div>
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label><i class="fas fa-calendar-check me-1"></i> Check-in</label>
                            <input type="date" class="form-control" name="check_in" 
                                   min="<?php echo date('Y-m-d'); ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label><i class="fas fa-calendar-times me-1"></i> Check-out</label>
                            <input type="date" class="form-control" name="check_out" 
                                   min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label><i class="fas fa-users me-1"></i> Guests</label>
                            <select class="form-select" name="guests">
                                <?php for ($i = 1; $i <= 4; $i++): ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?> <?php echo $i > 1 ? 'Guests' : 'Guest'; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label><i class="fas fa-bed me-1"></i> Room Type</label>
                            <select class="form-select" name="room_type">
                                <option value="">All Types</option>
                                <?php foreach ($room_types as $type): ?>
                                    <option value="<?php echo htmlspecialchars($type); ?>">
                                        <?php echo ucfirst(htmlspecialchars($type)); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="submit" name="search_rooms" class="btn-search">
                                <i class="fas fa-search me-2"></i>Search
                            </button>
                        </div>
                    </div>
                </div>
            </form>

            <!-- Search Results -->
            <?php if ($search_performed): ?>
                <div class="search-results">
                    <?php if ($search_error): ?>
                        <div class="alert alert-danger" style="background:rgba(239,68,68,0.12);color:#F87171;border:1px solid rgba(239,68,68,0.2);border-radius:12px;padding:0.8rem 1.2rem;font-size:0.85rem;">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo $search_error; ?>
                        </div>
                    <?php elseif ($has_results): ?>
                        <div class="result-count">
                            <i class="fas fa-bed me-1"></i>
                            Found <?php echo count($search_results); ?> room(s) matching your criteria
                        </div>
                        <?php foreach ($search_results as $room): ?>
                            <div class="result-item">
                                <div class="result-info">
                                    <div class="result-room">
                                        Room <?php echo htmlspecialchars($room['room_number']); ?>
                                        <small>• Floor <?php echo htmlspecialchars($room['floor']); ?></small>
                                    </div>
                                    <div class="result-type">
                                        <span class="badge" style="background:rgba(139,92,246,0.12);color:#8B5CF6;font-size:0.6rem;">
                                            <?php echo ucfirst($room['type'] ?? 'Standard'); ?>
                                        </span>
                                        <span class="badge" style="background:rgba(16,185,129,0.12);color:#10B981;font-size:0.6rem;margin-left:0.3rem;">
                                            <?php echo ($room['available_spots'] ?? 0); ?> spots left
                                        </span>
                                    </div>
                                </div>
                                <div class="result-price">
                                    ₹<?php echo number_format($room['rent'] ?? 0); ?>
                                    <small>/month</small>
                                </div>
                                <div>
                                    <a href="room_details.php?id=<?php echo $room['id']; ?>" class="btn-result-outline me-1">
                                        <i class="fas fa-eye me-1"></i>View
                                    </a>
                                    <a href="booking.php#search" class="btn-result" onclick="return confirm('Book this room?')">
                                        <i class="fas fa-calendar-plus me-1"></i>Book
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <div style="text-align:center;margin-top:1rem;">
                            <a href="booking.php" class="btn-result" style="display:inline-block;padding:0.5rem 2rem;border-radius:10px;background:rgba(139,92,246,0.12);color:#8B5CF6;text-decoration:none;font-size:0.8rem;font-weight:500;border:1px solid rgba(139,92,246,0.2);">
                                <i class="fas fa-arrow-right me-2"></i>View All Results
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="search-empty">
                            <i class="fas fa-door-closed"></i>
                            <h6 style="color:var(--text-secondary);">No rooms available</h6>
                            <p style="font-size:0.8rem;">Try adjusting your search criteria</p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Statistics Section -->
    <section class="stats-section">
        <div class="stats-grid">
            <div class="stat-item">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-number"><?php echo $stats['total_students'] ?? 0; ?></div>
                <div class="stat-label">Happy Residents</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon"><i class="fas fa-bed"></i></div>
                <div class="stat-number"><?php echo $stats['available_rooms'] ?? 0; ?></div>
                <div class="stat-label">Rooms Available</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon"><i class="fas fa-user-tie"></i></div>
                <div class="stat-number"><?php echo $stats['total_staff'] ?? 0; ?></div>
                <div class="stat-label">Staff Members</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon"><i class="fas fa-exclamation-circle"></i></div>
                <div class="stat-number"><?php echo $stats['pending_complaints'] ?? 0; ?></div>
                <div class="stat-label">Active Issues</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon"><i class="fas fa-rupee-sign"></i></div>
                <div class="stat-number"><span class="currency">₹</span><?php echo number_format(($stats['total_collected'] ?? 0) / 100000, 1); ?>L</div>
                <div class="stat-label">Revenue</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon"><i class="fas fa-calendar-check"></i></div>
                <div class="stat-number">8</div>
                <div class="stat-label">Years Experience</div>
            </div>
        </div>
    </section>

    <!-- Main Content -->
    <div class="main-content">
        <div class="content-grid">
            <!-- Left Column -->
            <div>
                <!-- Available Rooms -->
                <div class="section-title">
                    <h2><i class="fas fa-door-open"></i>Available Rooms</h2>
                    <a href="viewrooms.php" class="view-all">View All <i class="fas fa-arrow-right ms-1"></i></a>
                </div>
                <div class="rooms-grid">
                    <?php if (!empty($available_rooms)): ?>
                        <?php foreach ($available_rooms as $room): ?>
                            <div class="room-card">
                                <div class="card-glow"></div>
                                <div class="room-top">
                                    <div class="room-number">
                                        Room <?php echo htmlspecialchars($room['room_number'] ?? 'N/A'); ?>
                                        <small>• Floor <?php echo $room['floor'] ?? 'N/A'; ?></small>
                                    </div>
                                    <span class="room-type-badge"><?php echo ucfirst($room['type'] ?? 'Standard'); ?></span>
                                </div>
                                <div class="room-price">
                                    ₹<?php echo number_format($room['rent'] ?? 0); ?>
                                    <small>/month</small>
                                </div>
                                <div class="room-capacity">
                                    <?php
                                    $occupied = $room['occupied_count'] ?? 0;
                                    $capacity = $room['capacity'] ?? 1;
                                    ?>
                                    <i class="fas fa-users me-1"></i>
                                    <?php echo $occupied; ?>/<?php echo $capacity; ?> beds
                                    <div class="progress">
                                        <div class="progress-bar" style="width: <?php echo ($occupied / max($capacity, 1)) * 100; ?>%;"></div>
                                    </div>
                                </div>
                                <?php if (!empty($room['facilities'])):
                                    $facilities = is_array($room['facilities']) ? $room['facilities'] : explode(',', $room['facilities'] ?? '');
                                ?>
                                    <div class="room-facilities">
                                        <?php foreach (array_slice($facilities, 0, 3) as $facility): ?>
                                            <span class="facility-tag"><?php echo htmlspecialchars(trim($facility)); ?></span>
                                        <?php endforeach; ?>
                                        <?php if (count($facilities) > 3): ?>
                                            <span class="facility-tag">+<?php echo count($facilities) - 3; ?> more</span>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <a href="room_details.php?id=<?php echo $room['id']; ?>" class="btn-details">
                                    <i class="fas fa-eye me-1"></i>View Details
                                </a>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center py-4" style="grid-column: 1 / -1;">
                            <i class="fas fa-door-closed fa-3x" style="color: var(--text-muted); margin-bottom: 1rem;"></i>
                            <p style="color: var(--text-muted);">No rooms available at the moment.</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Recent Payments -->
                <?php if (!empty($recent_payments)): ?>
                    <div class="section-title">
                        <h2><i class="fas fa-receipt"></i>Recent Payments</h2>
                        <a href="payments.php" class="view-all">View All <i class="fas fa-arrow-right ms-1"></i></a>
                    </div>
                    <div class="payment-table-wrap">
                        <table class="payment-table">
                            <thead>
                                <tr>
                                    <th>Receipt</th>
                                    <th>Student</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_payments as $payment): ?>
                                    <tr>
                                        <td><strong><?php echo $payment['receipt_number'] ?? 'N/A'; ?></strong></td>
                                        <td><?php echo htmlspecialchars($payment['student_name']); ?></td>
                                        <td>₹<?php echo number_format($payment['amount'], 2); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($payment['payment_date'] ?? $payment['created_at'])); ?></td>
                                        <td>
                                            <span class="status-badge <?php echo $payment['status']; ?>">
                                                <?php echo ucfirst($payment['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Right Sidebar -->
            <div class="sidebar-right">
                <!-- Quick Actions -->
                <div class="sidebar-card">
                    <div class="card-title"><i class="fas fa-bolt"></i>Quick Actions</div>
                    <div class="quick-actions-grid">
                        <a href="booking.php" class="quick-action">
                            <i class="fas fa-calendar-check"></i>
                            <span class="action-label">Book Room</span>
                        </a>
                        <a href="payments.php" class="quick-action">
                            <i class="fas fa-file-invoice-dollar"></i>
                            <span class="action-label">Pay Fees</span>
                        </a>
                        <a href="facilities.php" class="quick-action">
                            <i class="fas fa-concierge-bell"></i>
                            <span class="action-label">Facilities</span>
                        </a>
                        <a href="contact.php" class="quick-action">
                            <i class="fas fa-headset"></i>
                            <span class="action-label">Support</span>
                        </a>
                    </div>
                </div>

                <!-- Today's Mess Menu -->
                <?php if (!empty($today_menu)): ?>
                    <div class="sidebar-card mess-menu">
                        <div class="card-title"><i class="fas fa-utensils"></i>Today's Mess Menu</div>
                        <div class="mess-menu-item">
                            <div class="menu-label"><i class="fas fa-sun me-1"></i>Breakfast</div>
                            <div class="menu-value"><?php echo htmlspecialchars($today_menu['breakfast']); ?></div>
                        </div>
                        <div class="mess-menu-item">
                            <div class="menu-label"><i class="fas fa-sun me-1"></i>Lunch</div>
                            <div class="menu-value"><?php echo htmlspecialchars($today_menu['lunch']); ?></div>
                        </div>
                        <div class="mess-menu-item">
                            <div class="menu-label"><i class="fas fa-moon me-1"></i>Dinner</div>
                            <div class="menu-value"><?php echo htmlspecialchars($today_menu['dinner']); ?></div>
                        </div>
                        <?php if (!empty($today_menu['special_notes'])): ?>
                            <div style="margin-top:0.5rem; padding:0.5rem; background:rgba(139,92,246,0.08); border-radius:8px; font-size:0.7rem; color: var(--text-secondary);">
                                <i class="fas fa-info-circle me-1" style="color:#8B5CF6;"></i>
                                <?php echo htmlspecialchars($today_menu['special_notes']); ?>
                            </div>
                        <?php endif; ?>
                        <a href="mess_menu.php" class="btn-menu">
                            <i class="fas fa-calendar-alt me-1"></i>View Weekly Menu
                        </a>
                    </div>
                <?php endif; ?>

                <!-- Announcements -->
                <div class="sidebar-card">
                    <div class="card-title"><i class="fas fa-bullhorn"></i>Announcements</div>
                    <?php if (!empty($announcements)): ?>
                        <?php foreach ($announcements as $announcement): ?>
                            <div class="announcement-item priority-<?php echo $announcement['priority'] ?? 'low'; ?>">
                                <div class="announce-title"><?php echo htmlspecialchars($announcement['title']); ?></div>
                                <div class="announce-text"><?php echo htmlspecialchars(substr($announcement['description'] ?? '', 0, 80)); ?>...</div>
                                <div class="announce-time">
                                    <i class="far fa-clock me-1"></i>
                                    <?php echo date('M j, Y', strtotime($announcement['created_at'])); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center py-3">
                            <i class="fas fa-bullhorn fa-2x" style="color: var(--text-muted); margin-bottom: 0.5rem;"></i>
                            <p style="color: var(--text-muted); font-size:0.8rem;">No announcements</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; <?php echo date('Y'); ?> Graceful Living Girls Hostel. All rights reserved.</p>
        <div class="footer-links">
            <a href="about.php">About</a>
            <a href="facilities.php">Facilities</a>
            <a href="booking.php">Booking</a>
            <a href="contact.php">Contact</a>
            <a href="terms.php">Terms</a>
            <a href="privacy.php">Privacy</a>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Animate stats counting
        document.addEventListener('DOMContentLoaded', function() {
            const statNumbers = document.querySelectorAll('.stat-number');
            statNumbers.forEach(stat => {
                const text = stat.textContent;
                const isCurrency = text.includes('L');
                const cleanText = text.replace(/[₹L,]/g, '').trim();
                const target = parseFloat(cleanText);
                
                if (!isNaN(target) && target > 0) {
                    let current = 0;
                    const increment = target / 50;
                    const timer = setInterval(() => {
                        current += increment;
                        if (current >= target) {
                            if (isCurrency) {
                                stat.innerHTML = '<span class="currency">₹</span>' + (target % 1 === 0 ? target : target.toFixed(1)) + 'L';
                            } else {
                                stat.textContent = Math.floor(target);
                            }
                            clearInterval(timer);
                        } else {
                            if (isCurrency) {
                                stat.innerHTML = '<span class="currency">₹</span>' + (current % 1 === 0 ? Math.floor(current) : current.toFixed(1)) + 'L';
                            } else {
                                stat.textContent = Math.floor(current);
                            }
                        }
                    }, 50);
                }
            });
        });
    </script>
</body>
</html>