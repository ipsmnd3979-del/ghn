<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Graceful Living – Premium Girls Hostel</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* ===== CSS VARIABLES ===== */
        :root {
            --primary: #6C63FF;
            --secondary: #A855F7;
            --accent: #EC4899;
            --bg: #F8FAFC;
            --card: #ffffff;
            --text: #1E1B4B;
            --text-muted: #64748B;
            --success: #22C55E;
            --warning: #F59E0B;
            --danger: #EF4444;
            --lavender: #EDE9FE;
            --pink-light: #FCE7F3;
            --sky: #E0F2FE;
            --border: rgba(108,99,255,0.15);
            --shadow: 0 8px 32px rgba(108,99,255,0.12);
            --shadow-hover: 0 16px 48px rgba(108,99,255,0.22);
            --glass: rgba(255,255,255,0.7);
            --glass-border: rgba(255,255,255,0.5);
            --radius: 18px;
            --radius-sm: 10px;
            --nav-h: 72px;
            --transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
        }
        [data-theme="dark"] {
            --bg: #0F0E1A;
            --card: #1A1830;
            --text: #F1F0FF;
            --text-muted: #A3A3C2;
            --lavender: #2D2B4E;
            --pink-light: #2D1B2E;
            --sky: #0C1F33;
            --border: rgba(168,85,247,0.2);
            --shadow: 0 8px 32px rgba(0,0,0,0.4);
            --glass: rgba(26,24,48,0.8);
            --glass-border: rgba(108,99,255,0.2);
        }

        /* ===== RESET & BASE ===== */
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        html{scroll-behavior:smooth;font-size:16px}
        body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);transition:var(--transition);overflow-x:hidden}
        a{text-decoration:none;color:inherit}
        img{max-width:100%;height:auto}
        ul{list-style:none}
        button{cursor:pointer;border:none;outline:none;font-family:inherit}
        input,select,textarea{font-family:inherit;outline:none}

        /* ===== SCROLLBAR ===== */
        ::-webkit-scrollbar{width:6px}
        ::-webkit-scrollbar-track{background:var(--bg)}
        ::-webkit-scrollbar-thumb{background:var(--primary);border-radius:3px}

        /* ===== LOADING SCREEN ===== */
        #loader{position:fixed;inset:0;background:linear-gradient(135deg,#6C63FF,#EC4899);z-index:9999;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px;transition:opacity 0.5s}
        #loader.hidden{opacity:0;pointer-events:none}
        .loader-logo{font-family:'Poppins',sans-serif;font-size:2rem;font-weight:800;color:#fff;letter-spacing:-1px}
        .loader-logo span{color:#FFD6EC}
        .loader-bar{width:200px;height:4px;background:rgba(255,255,255,0.3);border-radius:2px;overflow:hidden}
        .loader-fill{height:100%;background:#fff;border-radius:2px;animation:loadFill 1.2s ease forwards}
        @keyframes loadFill{from{width:0}to{width:100%}}

        /* ===== NAVIGATION ===== */
        nav{position:fixed;top:0;left:0;right:0;height:var(--nav-h);background:var(--glass);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-bottom:1px solid var(--glass-border);z-index:1000;transition:var(--transition)}
        .nav-inner{max-width:1280px;margin:0 auto;height:100%;display:flex;align-items:center;justify-content:space-between;padding:0 24px}
        .nav-logo{font-family:'Poppins',sans-serif;font-size:1.4rem;font-weight:800;background:linear-gradient(135deg,var(--primary),var(--accent));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
        .nav-logo span{font-weight:300}
        .nav-links{display:flex;align-items:center;gap:8px}
        .nav-links a{padding:8px 16px;border-radius:8px;font-size:.9rem;font-weight:500;color:var(--text-muted);transition:var(--transition);cursor:pointer}
        .nav-links a:hover,.nav-links a.active{color:var(--primary);background:var(--lavender)}
        .nav-actions{display:flex;align-items:center;gap:12px}
        .btn-ghost{padding:8px 20px;border-radius:10px;font-size:.9rem;font-weight:600;color:var(--primary);border:2px solid var(--primary);background:transparent;transition:var(--transition)}
        .btn-ghost:hover{background:var(--primary);color:#fff}
        .btn-primary{padding:10px 24px;border-radius:10px;font-size:.9rem;font-weight:600;background:linear-gradient(135deg,var(--primary),var(--secondary));color:#fff;border:none;transition:var(--transition);box-shadow:0 4px 16px rgba(108,99,255,0.3)}
        .btn-primary:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(108,99,255,0.4)}
        .btn-accent{padding:10px 24px;border-radius:10px;font-size:.9rem;font-weight:600;background:linear-gradient(135deg,var(--accent),var(--secondary));color:#fff;border:none;transition:var(--transition);box-shadow:0 4px 16px rgba(236,72,153,0.3)}
        .btn-accent:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(236,72,153,0.4)}
        .theme-btn{width:40px;height:40px;border-radius:50%;background:var(--lavender);border:none;display:flex;align-items:center;justify-content:center;color:var(--primary);font-size:1rem;transition:var(--transition)}
        .theme-btn:hover{background:var(--primary);color:#fff}
        .hamburger{display:none;flex-direction:column;gap:5px;background:none;border:none;cursor:pointer;padding:8px}
        .hamburger span{display:block;width:24px;height:2px;background:var(--text);border-radius:2px;transition:var(--transition)}

        /* ===== PAGES ===== */
        .page{display:none;padding-top:var(--nav-h);min-height:100vh}
        .page.active{display:block}

        /* ===== HERO ===== */
        .hero{position:relative;height:calc(100vh - var(--nav-h));min-height:600px;display:flex;align-items:center;overflow:hidden}
        .hero-bg{position:absolute;inset:0;background:linear-gradient(135deg,#1E1B4B 0%,#4C1D95 40%,#831843 100%);z-index:0}
        .hero-bg::before{content:'';position:absolute;inset:0;background:url('https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=1600&q=80') center/cover;opacity:.25}
        .hero-shapes{position:absolute;inset:0;overflow:hidden;z-index:1}
        .hero-shapes .shape{position:absolute;border-radius:50%;filter:blur(60px);opacity:.3;animation:float 8s ease-in-out infinite}
        .shape-1{width:400px;height:400px;background:#6C63FF;top:-100px;right:-100px;animation-delay:0s}
        .shape-2{width:300px;height:300px;background:#EC4899;bottom:-50px;left:10%;animation-delay:3s}
        .shape-3{width:200px;height:200px;background:#A855F7;top:40%;left:30%;animation-delay:5s}
        @keyframes float{0%,100%{transform:translateY(0) scale(1)}50%{transform:translateY(-30px) scale(1.05)}}
        .hero-content{position:relative;z-index:2;max-width:1280px;margin:0 auto;padding:0 24px;width:100%}
        .hero-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,0.1);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,0.2);padding:8px 18px;border-radius:50px;color:#fff;font-size:.85rem;font-weight:500;margin-bottom:24px}
        .hero-badge i{color:#FFD700}
        .hero h1{font-family:'Poppins',sans-serif;font-size:clamp(2.2rem,5vw,4rem);font-weight:800;color:#fff;line-height:1.15;margin-bottom:20px}
        .hero h1 .gradient-text{background:linear-gradient(135deg,#FFB3D1,#C4B5FD);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
        .hero p{font-size:1.1rem;color:rgba(255,255,255,0.8);max-width:540px;line-height:1.7;margin-bottom:36px}
        .hero-btns{display:flex;gap:16px;flex-wrap:wrap}
        .hero-stats{display:flex;gap:40px;margin-top:48px;padding-top:48px;border-top:1px solid rgba(255,255,255,0.15)}
        .hero-stat-num{font-family:'Poppins',sans-serif;font-size:1.8rem;font-weight:800;color:#fff}
        .hero-stat-label{font-size:.85rem;color:rgba(255,255,255,0.6);margin-top:4px}

        /* ===== SEARCH SECTION ===== */
        .search-section{padding:0 24px;margin-top:-50px;position:relative;z-index:10}
        .search-card{max-width:1100px;margin:0 auto;background:var(--card);border-radius:var(--radius);box-shadow:var(--shadow);padding:32px;border:1px solid var(--border)}
        .search-card h3{font-family:'Poppins',sans-serif;font-size:1.1rem;font-weight:700;color:var(--text);margin-bottom:24px;display:flex;align-items:center;gap:10px}
        .search-card h3 i{color:var(--primary)}
        .search-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;align-items:end}
        .search-field label{display:block;font-size:.8rem;font-weight:600;color:var(--text-muted);margin-bottom:8px;text-transform:uppercase;letter-spacing:.5px}
        .search-field input,.search-field select{width:100%;padding:14px 16px;background:var(--lavender);border:2px solid transparent;border-radius:12px;font-size:.95rem;color:var(--text);transition:var(--transition)}
        .search-field input:focus,.search-field select:focus{border-color:var(--primary);background:var(--card)}
        .search-field select{appearance:none;-webkit-appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%236C63FF' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center;background-color:var(--lavender)}
        .search-btn-wrap{display:flex;align-items:flex-end}
        .search-btn-wrap .btn-primary{width:100%;padding:14px;font-size:1rem;border-radius:12px}

        /* ===== SECTIONS ===== */
        section{padding:80px 24px}
        .section-inner{max-width:1280px;margin:0 auto}
        .section-tag{display:inline-block;background:var(--lavender);color:var(--primary);font-size:.8rem;font-weight:700;padding:6px 16px;border-radius:50px;margin-bottom:12px;text-transform:uppercase;letter-spacing:1px}
        .section-title{font-family:'Poppins',sans-serif;font-size:clamp(1.8rem,3vw,2.6rem);font-weight:800;color:var(--text);line-height:1.2;margin-bottom:12px}
        .section-subtitle{color:var(--text-muted);font-size:1rem;max-width:520px;line-height:1.7}
        .section-header{display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:16px;margin-bottom:48px}

        /* ===== CARDS GRID ===== */
        .cards-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:28px}
        .room-card{background:var(--card);border-radius:var(--radius);overflow:hidden;box-shadow:var(--shadow);border:1px solid var(--border);transition:var(--transition);position:relative}
        .room-card:hover{transform:translateY(-8px);box-shadow:var(--shadow-hover)}
        .room-card-img{position:relative;height:220px;overflow:hidden}
        .room-card-img img{width:100%;height:100%;object-fit:cover;transition:transform 0.5s ease}
        .room-card:hover .room-card-img img{transform:scale(1.08)}
        .room-card-badge{position:absolute;top:14px;left:14px;padding:6px 14px;border-radius:50px;font-size:.78rem;font-weight:700;backdrop-filter:blur(10px)}
        .badge-available{background:rgba(34,197,94,0.9);color:#fff}
        .badge-few{background:rgba(245,158,11,0.9);color:#fff}
        .badge-full{background:rgba(239,68,68,0.9);color:#fff}
        .room-card-fav{position:absolute;top:14px;right:14px;width:36px;height:36px;background:rgba(255,255,255,0.9);border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--accent);font-size:.9rem;cursor:pointer;transition:var(--transition)}
        .room-card-fav:hover,.room-card-fav.active{background:var(--accent);color:#fff}
        .room-card-body{padding:20px}
        .room-type-tag{display:inline-block;background:var(--lavender);color:var(--primary);font-size:.75rem;font-weight:600;padding:4px 12px;border-radius:50px;margin-bottom:10px}
        .room-card-body h3{font-family:'Poppins',sans-serif;font-size:1.1rem;font-weight:700;color:var(--text);margin-bottom:8px}
        .room-rating{display:flex;align-items:center;gap:6px;margin-bottom:14px}
        .stars{color:#F59E0B;font-size:.85rem}
        .room-rating span{font-size:.85rem;color:var(--text-muted)}
        .room-features{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px}
        .feat-tag{display:flex;align-items:center;gap:5px;background:var(--bg);padding:5px 10px;border-radius:8px;font-size:.75rem;color:var(--text-muted)}
        .feat-tag i{color:var(--primary);font-size:.75rem}
        .room-price-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}
        .room-price{font-family:'Poppins',sans-serif;font-size:1.4rem;font-weight:800;color:var(--primary)}
        .room-price span{font-size:.8rem;font-weight:400;color:var(--text-muted)}
        .beds-info{font-size:.82rem;color:var(--text-muted)}
        .beds-info i{color:var(--accent)}
        .room-card-btns{display:grid;grid-template-columns:1fr 1fr;gap:10px}
        .btn-outline{padding:10px;border-radius:10px;font-size:.85rem;font-weight:600;border:2px solid var(--primary);color:var(--primary);background:transparent;transition:var(--transition)}
        .btn-outline:hover{background:var(--primary);color:#fff}

        /* ===== FACILITIES ===== */
        .facilities-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:20px}
        .facility-card{background:var(--card);border-radius:var(--radius);padding:28px 20px;text-align:center;border:1px solid var(--border);box-shadow:var(--shadow);transition:var(--transition);cursor:default}
        .facility-card:hover{transform:translateY(-6px);box-shadow:var(--shadow-hover);border-color:var(--primary)}
        .facility-icon{width:60px;height:60px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;margin:0 auto 14px;transition:var(--transition)}
        .facility-card:hover .facility-icon{transform:scale(1.1)}
        .facility-card h4{font-family:'Poppins',sans-serif;font-size:.95rem;font-weight:700;color:var(--text);margin-bottom:6px}
        .facility-card p{font-size:.8rem;color:var(--text-muted);line-height:1.5}

        /* ===== TESTIMONIALS ===== */
        .testimonials-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:24px}
        .testimonial-card{background:var(--card);border-radius:var(--radius);padding:28px;border:1px solid var(--border);box-shadow:var(--shadow);position:relative;transition:var(--transition)}
        .testimonial-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-hover)}
        .testimonial-card::before{content:'\201C';font-size:4rem;color:var(--primary);opacity:.15;position:absolute;top:12px;left:20px;font-family:serif;line-height:1}
        .testimonial-text{font-size:.95rem;line-height:1.7;color:var(--text-muted);margin-bottom:20px;padding-top:16px}
        .testimonial-author{display:flex;align-items:center;gap:14px}
        .testimonial-avatar{width:48px;height:48px;border-radius:50%;object-fit:cover;border:3px solid var(--lavender)}
        .testimonial-name{font-weight:700;color:var(--text);font-size:.95rem}
        .testimonial-role{font-size:.8rem;color:var(--text-muted)}

        /* ===== FAQ ===== */
        .faq-list{max-width:780px;margin:0 auto;display:flex;flex-direction:column;gap:12px}
        .faq-item{background:var(--card);border-radius:var(--radius-sm);border:1px solid var(--border);overflow:hidden;transition:var(--transition)}
        .faq-question{display:flex;align-items:center;justify-content:space-between;padding:20px 24px;cursor:pointer;font-weight:600;color:var(--text);font-size:.95rem}
        .faq-question i{transition:var(--transition);color:var(--primary)}
        .faq-item.open .faq-question i{transform:rotate(180deg)}
        .faq-answer{max-height:0;overflow:hidden;transition:max-height 0.3s ease,padding 0.3s}
        .faq-answer p{padding:0 24px 20px;color:var(--text-muted);line-height:1.7;font-size:.92rem}
        .faq-item.open .faq-answer{max-height:200px}

        /* ===== BOOKING FORM ===== */
        .booking-form-wrap{max-width:860px;margin:0 auto;padding:40px 24px}
        .form-card{background:var(--card);border-radius:var(--radius);box-shadow:var(--shadow);padding:40px;border:1px solid var(--border)}
        .form-section-title{font-family:'Poppins',sans-serif;font-size:1.1rem;font-weight:700;color:var(--text);margin-bottom:20px;display:flex;align-items:center;gap:10px;padding-bottom:12px;border-bottom:2px solid var(--lavender)}
        .form-section-title i{color:var(--primary)}
        .form-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:28px}
        .form-group{display:flex;flex-direction:column;gap:8px}
        .form-group.full{grid-column:1/-1}
        .form-group label{font-size:.85rem;font-weight:600;color:var(--text-muted);text-transform:uppercase;letter-spacing:.5px}
        .form-group input,.form-group select,.form-group textarea{padding:14px 16px;background:var(--bg);border:2px solid var(--border);border-radius:12px;font-size:.95rem;color:var(--text);transition:var(--transition)}
        .form-group input:focus,.form-group select:focus,.form-group textarea:focus{border-color:var(--primary);background:var(--card)}
        .form-group textarea{resize:vertical;min-height:100px}
        .checkbox-row{display:flex;align-items:center;gap:12px;margin:20px 0;padding:16px;background:var(--lavender);border-radius:12px}
        .checkbox-row input[type=checkbox]{width:20px;height:20px;accent-color:var(--primary)}
        .checkbox-row label{font-size:.9rem;color:var(--text);cursor:pointer;font-weight:500}
        .form-submit{width:100%;padding:16px;font-size:1.05rem;border-radius:12px;display:flex;align-items:center;justify-content:center;gap:10px}

        /* ===== PAYMENT ===== */
        .payment-layout{max-width:1100px;margin:0 auto;padding:40px 24px;display:grid;grid-template-columns:1fr 420px;gap:32px}
        .payment-summary{background:var(--card);border-radius:var(--radius);box-shadow:var(--shadow);padding:32px;border:1px solid var(--border)}
        .summary-row{display:flex;justify-content:space-between;align-items:center;padding:14px 0;border-bottom:1px solid var(--border);font-size:.95rem}
        .summary-row:last-child{border-bottom:none;font-family:'Poppins',sans-serif;font-size:1.1rem;font-weight:800;color:var(--primary)}
        .summary-label{color:var(--text-muted)}
        .summary-value{font-weight:600;color:var(--text)}
        .payment-methods{background:var(--card);border-radius:var(--radius);box-shadow:var(--shadow);padding:32px;border:1px solid var(--border)}
        .payment-tabs{display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap}
        .pay-tab{padding:8px 18px;border-radius:50px;font-size:.85rem;font-weight:600;background:var(--lavender);color:var(--primary);border:2px solid transparent;transition:var(--transition)}
        .pay-tab.active{background:var(--primary);color:#fff}
        .upi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px}
        .upi-btn{padding:14px;border-radius:12px;background:var(--bg);border:2px solid var(--border);display:flex;flex-direction:column;align-items:center;gap:8px;cursor:pointer;transition:var(--transition)}
        .upi-btn:hover,.upi-btn.selected{border-color:var(--primary);background:var(--lavender)}
        .upi-btn span{font-size:.78rem;font-weight:600;color:var(--text-muted)}
        .upi-input{width:100%;padding:14px;border:2px solid var(--border);border-radius:12px;font-size:.95rem;color:var(--text);background:var(--bg);margin-bottom:16px}
        .upi-input:focus{border-color:var(--primary);background:var(--card)}
        .secure-badge{display:flex;align-items:center;justify-content:center;gap:8px;background:rgba(34,197,94,0.1);color:var(--success);padding:12px;border-radius:10px;font-size:.88rem;font-weight:600;margin-top:16px;border:1px solid rgba(34,197,94,0.2)}
        .pay-btn{width:100%;padding:16px;font-size:1.05rem;border-radius:12px;margin-top:16px}

        /* ===== CONTACT ===== */
        .contact-layout{display:grid;grid-template-columns:1fr 1fr;gap:40px;max-width:1100px;margin:0 auto;padding:40px 24px}
        .contact-item{display:flex;align-items:flex-start;gap:16px;margin-bottom:24px;padding:20px;background:var(--card);border-radius:12px;border:1px solid var(--border);transition:var(--transition)}
        .contact-item:hover{transform:translateX(6px);border-color:var(--primary)}
        .contact-icon{width:48px;height:48px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0}
        .contact-item-text strong{display:block;font-weight:700;color:var(--text);margin-bottom:4px}
        .contact-item-text span{font-size:.9rem;color:var(--text-muted)}
        .contact-social{display:flex;gap:12px;margin-top:24px}

        /* ===== DASHBOARD ===== */
        .dashboard-layout{display:grid;grid-template-columns:260px 1fr;min-height:calc(100vh - var(--nav-h));max-width:100%}
        .sidebar{background:var(--card);border-right:1px solid var(--border);padding:28px 0}
        .sidebar-logo{font-family:'Poppins',sans-serif;font-size:1.1rem;font-weight:800;padding:0 24px 24px;border-bottom:1px solid var(--border);margin-bottom:16px;background:linear-gradient(135deg,var(--primary),var(--accent));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
        .sidebar-nav{padding:0 12px}
        .sidebar-nav a{display:flex;align-items:center;gap:12px;padding:12px 16px;border-radius:10px;font-size:.9rem;font-weight:500;color:var(--text-muted);transition:var(--transition);margin-bottom:4px;cursor:pointer}
        .sidebar-nav a:hover,.sidebar-nav a.active{background:var(--lavender);color:var(--primary)}
        .sidebar-nav a.active{font-weight:700}
        .sidebar-nav a i{width:20px;text-align:center}
        .dash-main{background:var(--bg);padding:32px}
        .dash-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:32px}
        .dash-title{font-family:'Poppins',sans-serif;font-size:1.6rem;font-weight:800;color:var(--text)}
        .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:20px;margin-bottom:32px}
        .stat-card{background:var(--card);border-radius:var(--radius-sm);padding:24px;border:1px solid var(--border);box-shadow:var(--shadow);display:flex;align-items:center;gap:16px;transition:var(--transition)}
        .stat-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-hover)}
        .stat-icon{width:52px;height:52px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.3rem}
        .stat-num{font-family:'Poppins',sans-serif;font-size:1.6rem;font-weight:800;color:var(--text)}
        .stat-label{font-size:.82rem;color:var(--text-muted);margin-top:2px}
        .dash-card{background:var(--card);border-radius:var(--radius-sm);border:1px solid var(--border);box-shadow:var(--shadow);margin-bottom:24px}
        .dash-card-header{padding:20px 24px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center}
        .dash-card-title{font-family:'Poppins',sans-serif;font-size:1rem;font-weight:700;color:var(--text)}
        .dash-table{width:100%;border-collapse:collapse}
        .dash-table th{background:var(--bg);padding:12px 20px;text-align:left;font-size:.8rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:.5px}
        .dash-table td{padding:16px 20px;border-top:1px solid var(--border);font-size:.9rem;color:var(--text)}
        .dash-table tr:hover td{background:var(--lavender)}
        .status-pill{display:inline-block;padding:4px 12px;border-radius:50px;font-size:.78rem;font-weight:700}
        .pill-paid{background:rgba(34,197,94,0.1);color:var(--success)}
        .pill-pending{background:rgba(245,158,11,0.1);color:var(--warning)}
        .pill-overdue{background:rgba(239,68,68,0.1);color:var(--danger)}
        .profile-card-s{background:linear-gradient(135deg,var(--primary),var(--accent));border-radius:var(--radius);padding:28px;color:#fff;margin-bottom:24px;display:flex;align-items:center;gap:24px;flex-wrap:wrap}
        .profile-avatar-s{width:80px;height:80px;border-radius:50%;border:4px solid rgba(255,255,255,0.3);object-fit:cover}
        .profile-info h2{font-family:'Poppins',sans-serif;font-size:1.3rem;font-weight:800}
        .profile-info p{opacity:.8;font-size:.9rem;margin-top:4px}
        .profile-info .room-tag{display:inline-block;background:rgba(255,255,255,0.2);padding:4px 14px;border-radius:50px;font-size:.82rem;margin-top:8px}

        /* ===== FOOTER ===== */
        footer{background:linear-gradient(135deg,#1E1B4B,#2D1B69);color:#fff;padding:60px 24px 24px}
        .footer-inner{max-width:1280px;margin:0 auto}
        .footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:40px;margin-bottom:48px}
        .footer-brand-logo{font-family:'Poppins',sans-serif;font-size:1.5rem;font-weight:800;margin-bottom:16px}
        .footer-brand-logo span{opacity:.6;font-weight:300}
        .footer-desc{font-size:.9rem;color:rgba(255,255,255,0.6);line-height:1.7;margin-bottom:20px}
        .footer-social{display:flex;gap:12px}
        .social-btn{width:38px;height:38px;border-radius:10px;background:rgba(255,255,255,0.1);display:flex;align-items:center;justify-content:center;color:#fff;font-size:.9rem;transition:var(--transition)}
        .social-btn:hover{background:var(--accent);transform:translateY(-3px)}
        .footer-col h5{font-family:'Poppins',sans-serif;font-size:1rem;font-weight:700;margin-bottom:18px;color:rgba(255,255,255,0.9)}
        .footer-col ul li{margin-bottom:10px}
        .footer-col ul li a{font-size:.88rem;color:rgba(255,255,255,0.55);transition:var(--transition)}
        .footer-col ul li a:hover{color:#fff;padding-left:4px}
        .footer-bottom{border-top:1px solid rgba(255,255,255,0.1);padding-top:24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px}
        .footer-bottom p{font-size:.85rem;color:rgba(255,255,255,0.4)}

        /* ===== RESPONSIVE ===== */
        @media(max-width:1024px){
            .footer-grid{grid-template-columns:1fr 1fr}
            .payment-layout{grid-template-columns:1fr}
            .dashboard-layout{grid-template-columns:1fr}
            .sidebar{display:none}
        }
        @media(max-width:768px){
            .nav-links{display:none;position:fixed;inset:0;background:var(--card);flex-direction:column;align-items:center;justify-content:center;gap:16px;z-index:999;padding:20px}
            .nav-links.mobile-open{display:flex}
            .nav-links a{font-size:1.1rem;padding:14px 32px}
            .hamburger{display:flex}
            .hero h1{font-size:2rem}
            .hero-stats{gap:24px}
            .contact-layout{grid-template-columns:1fr}
            .form-grid{grid-template-columns:1fr}
            .upi-grid{grid-template-columns:repeat(2,1fr)}
            .footer-grid{grid-template-columns:1fr}
        }
        @media(max-width:480px){
            .search-grid{grid-template-columns:1fr}
            .room-card-btns{grid-template-columns:1fr}
            .cards-grid{grid-template-columns:1fr}
            section{padding:56px 16px}
            .form-card{padding:24px 16px}
        }

        /* ===== ANIMATIONS ===== */
        .animate-in{opacity:0;transform:translateY(24px);transition:opacity 0.5s ease,transform 0.5s ease}
        .animate-in.visible{opacity:1;transform:translateY(0)}

        /* ===== TOAST ===== */
        #toast{position:fixed;bottom:30px;right:30px;background:var(--primary);color:#fff;padding:14px 24px;border-radius:12px;font-weight:600;font-size:.9rem;z-index:9999;transform:translateY(100px);opacity:0;transition:all 0.3s ease;display:flex;align-items:center;gap:10px;box-shadow:0 8px 32px rgba(108,99,255,0.4)}
        #toast.show{transform:translateY(0);opacity:1}

        /* ===== MISC ===== */
        .page-hero{background:linear-gradient(135deg,#1E1B4B,#4C1D95);padding:60px 24px;text-align:center;color:#fff}
        .page-hero h1{font-family:'Poppins',sans-serif;font-size:clamp(1.8rem,4vw,3rem);font-weight:800;margin-bottom:12px}
        .page-hero p{font-size:1rem;opacity:.75;max-width:500px;margin:0 auto}
        .breadcrumb{display:flex;justify-content:center;gap:8px;margin-top:16px;font-size:.85rem;opacity:.6}
        .breadcrumb span{opacity:1;color:#FFB3D1}
        .gallery-filters{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:32px}
        .filter-btn{padding:8px 20px;border-radius:50px;font-size:.88rem;font-weight:600;background:var(--lavender);color:var(--primary);border:2px solid transparent;transition:var(--transition);cursor:pointer}
        .filter-btn.active,.filter-btn:hover{background:var(--primary);color:#fff}
        .gallery-masonry{columns:3 200px;gap:16px}
        .gallery-item{break-inside:avoid;margin-bottom:16px;position:relative;border-radius:12px;overflow:hidden;cursor:pointer}
        .gallery-item img{width:100%;display:block;transition:transform 0.4s ease}
        .gallery-item:hover img{transform:scale(1.05)}
        .gallery-overlay{position:absolute;inset:0;background:linear-gradient(to top,rgba(108,99,255,0.7),transparent);opacity:0;transition:var(--transition);display:flex;align-items:flex-end;padding:16px}
        .gallery-item:hover .gallery-overlay{opacity:1}
        .gallery-overlay span{color:#fff;font-weight:600;font-size:.9rem}
        .upload-zone{border:2px dashed var(--primary);border-radius:12px;padding:30px;text-align:center;cursor:pointer;transition:var(--transition);background:var(--lavender);grid-column:1/-1}
        .upload-zone:hover{background:rgba(108,99,255,0.08)}
        .upload-zone i{font-size:2rem;color:var(--primary);margin-bottom:10px;display:block}
        .upload-zone p{color:var(--text-muted);font-size:.9rem}
        .upload-zone strong{color:var(--primary)}
        .map-placeholder{width:100%;height:220px;background:var(--lavender);border-radius:12px;display:flex;align-items:center;justify-content:center;color:var(--primary);font-size:1rem;font-weight:600;gap:10px;margin-top:16px;border:2px dashed var(--border)}
        .slider-wrap{position:relative;border-radius:var(--radius);overflow:hidden;margin-bottom:32px;height:420px}
        .slider-track{display:flex;height:100%;transition:transform 0.5s cubic-bezier(0.4,0,0.2,1)}
        .slider-slide{min-width:100%;height:100%}
        .slider-slide img{width:100%;height:100%;object-fit:cover}
        .slider-btn{position:absolute;top:50%;transform:translateY(-50%);width:48px;height:48px;background:rgba(255,255,255,0.9);backdrop-filter:blur(10px);border:none;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.1rem;color:var(--primary);cursor:pointer;transition:var(--transition);z-index:5}
        .slider-btn:hover{background:var(--primary);color:#fff}
        .slider-btn.prev{left:16px}
        .slider-btn.next{right:16px}
        .slider-dots{position:absolute;bottom:16px;left:50%;transform:translateX(-50%);display:flex;gap:8px}
        .slider-dot{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,0.5);cursor:pointer;transition:var(--transition)}
        .slider-dot.active{background:#fff;width:24px;border-radius:4px}
        .hostel-layout{display:grid;grid-template-columns:1fr 360px;gap:32px;max-width:1280px;margin:0 auto;padding:40px 24px}
        .hostel-title{font-family:'Poppins',sans-serif;font-size:1.8rem;font-weight:800;color:var(--text);margin-bottom:8px}
        .hostel-meta{display:flex;align-items:center;flex-wrap:wrap;gap:16px;margin-bottom:20px;padding-bottom:20px;border-bottom:1px solid var(--border)}
        .hostel-rating-badge{display:flex;align-items:center;gap:6px;background:var(--warning);color:#fff;padding:6px 14px;border-radius:50px;font-weight:700;font-size:.9rem}
        .hostel-address{display:flex;align-items:center;gap:6px;color:var(--text-muted);font-size:.9rem}
        .hostel-desc{color:var(--text-muted);line-height:1.8;margin-bottom:28px}
        .info-grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:28px}
        .info-box{background:var(--lavender);border-radius:12px;padding:16px;display:flex;align-items:center;gap:12px}
        .info-box i{font-size:1.2rem;color:var(--primary);min-width:24px}
        .info-box-text small{display:block;font-size:.75rem;color:var(--text-muted)}
        .info-box-text strong{font-size:.95rem;color:var(--text)}
        .sticky-card{background:var(--card);border-radius:var(--radius);box-shadow:var(--shadow);padding:28px;border:1px solid var(--border);position:sticky;top:calc(var(--nav-h) + 20px)}
        .sticky-card .price-big{font-family:'Poppins',sans-serif;font-size:2.2rem;font-weight:800;color:var(--primary)}
        .sticky-card .price-big span{font-size:1rem;font-weight:400;color:var(--text-muted)}
        .sticky-card .book-btn{width:100%;padding:16px;font-size:1rem;margin-top:20px;border-radius:12px}
        .amenities-chips{display:flex;flex-wrap:wrap;gap:10px;margin:20px 0}
        .chip{display:flex;align-items:center;gap:6px;background:var(--bg);border:1px solid var(--border);padding:8px 14px;border-radius:50px;font-size:.83rem;color:var(--text-muted)}
        .chip i{color:var(--primary);font-size:.85rem}
        .room-detail{display:grid;grid-template-columns:1fr 1fr;gap:40px;max-width:1280px;margin:0 auto;padding:40px 24px}
        @media(max-width:768px){.hostel-layout{grid-template-columns:1fr}.room-detail{grid-template-columns:1fr}.info-grid-2{grid-template-columns:1fr}}
    </style>
</head>
<body>

<!-- LOADER -->
<div id="loader">
    <div class="loader-logo">Graceful<span>Living</span></div>
    <div class="loader-bar"><div class="loader-fill"></div></div>
</div>

<!-- TOAST -->
<div id="toast"><i class="fas fa-check-circle"></i><span id="toast-msg">Success!</span></div>

<!-- NAVIGATION -->
<nav>
    <div class="nav-inner">
        <div class="nav-logo">Graceful<span>Living</span></div>
        <div class="nav-links" id="navLinks">
            <a class="<?php echo $page === 'home' ? 'active' : ''; ?>" onclick="showPage('home')">Home</a>
            <a class="<?php echo $page === 'hostel' ? 'active' : ''; ?>" onclick="showPage('hostel')">Hostel</a>
            <a class="<?php echo $page === 'rooms' ? 'active' : ''; ?>" onclick="showPage('rooms')">Rooms</a>
            <a class="<?php echo $page === 'gallery' ? 'active' : ''; ?>" onclick="showPage('gallery')">Gallery</a>
            <a class="<?php echo $page === 'contact' ? 'active' : ''; ?>" onclick="showPage('contact')">Contact</a>
        </div>
        <div class="nav-actions">
            <button class="theme-btn" onclick="toggleTheme()" title="Toggle theme"><i class="fas fa-moon" id="themeIcon"></i></button>
            <?php if ($is_logged_in): ?>
                <button class="btn-ghost" onclick="showPage('student')"><i class="fas fa-user"></i> <?php echo htmlspecialchars($user_name); ?></button>
                <button class="btn-primary" onclick="window.location.href='logout.php'"><i class="fas fa-sign-out-alt"></i> Logout</button>
            <?php else: ?>
                <button class="btn-ghost" onclick="showPage('login')">Login</button>
                <button class="btn-primary" onclick="showPage('booking')">Book Now</button>
            <?php endif; ?>
            <button class="hamburger" onclick="toggleMobile()" aria-label="Menu">
                <span></span><span></span><span></span>
            </button>
        </div>
    </div>
</nav>

<!-- ============================= PAGE: HOME ============================= -->
<div class="page <?php echo $page === 'home' ? 'active' : ''; ?>" id="page-home">
    <!-- HERO -->
    <section class="hero" style="padding:0">
        <div class="hero-bg"></div>
        <div class="hero-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="shape shape-3"></div>
        </div>
        <div class="hero-content">
            <div class="hero-badge"><i class="fas fa-star"></i>Rated #1 Girls Hostel in the City</div>
            <h1>Your <span class="gradient-text">Safe & Luxurious</span><br>Home Away from Home</h1>
            <p>Premium girls hostel with modern amenities, 24/7 security, and a welcoming community designed for today's young women.</p>
            <div class="hero-btns">
                <button class="btn-primary" onclick="showPage('rooms')" style="padding:14px 32px;font-size:1rem"><i class="fas fa-bed"></i> Explore Rooms</button>
                <button class="btn-ghost" onclick="showPage('hostel')" style="padding:14px 32px;font-size:1rem;color:#fff;border-color:rgba(255,255,255,0.5)"><i class="fas fa-play-circle"></i> View Hostel</button>
            </div>
            <div class="hero-stats">
                <div><div class="hero-stat-num"><?php echo $stats['total_students'] ?? 0; ?>+</div><div class="hero-stat-label">Happy Residents</div></div>
                <div><div class="hero-stat-num"><?php echo $stats['total_rooms'] ?? 0; ?></div><div class="hero-stat-label">Total Rooms</div></div>
                <div><div class="hero-stat-num"><?php echo $stats['available_rooms'] ?? 0; ?></div><div class="hero-stat-label">Available Now</div></div>
                <div><div class="hero-stat-num">5+</div><div class="hero-stat-label">Years of Trust</div></div>
            </div>
        </div>
    </section>

    <!-- SEARCH -->
    <div class="search-section">
        <div class="search-card">
            <h3><i class="fas fa-search"></i>Find Your Perfect Room</h3>
            <form action="index.php?page=rooms" method="GET">
                <input type="hidden" name="page" value="rooms">
                <div class="search-grid">
                    <div class="search-field">
                        <label>Check-in Date</label>
                        <input type="date" name="checkin" id="checkin">
                    </div>
                    <div class="search-field">
                        <label>Check-out Date</label>
                        <input type="date" name="checkout" id="checkout">
                    </div>
                    <div class="search-field">
                        <label>Guests</label>
                        <select name="guests">
                            <option value="1">1 Guest</option>
                            <option value="2">2 Guests</option>
                            <option value="3">3 Guests</option>
                            <option value="4">4 Guests</option>
                        </select>
                    </div>
                    <div class="search-field">
                        <label>Room Type</label>
                        <select name="type">
                            <option value="">Any Type</option>
                            <?php foreach ($room_types as $type): ?>
                                <option value="<?php echo htmlspecialchars($type); ?>"><?php echo ucfirst(htmlspecialchars($type)); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="search-btn-wrap">
                        <button type="submit" class="btn-primary"><i class="fas fa-search"></i> Search</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- FEATURED ROOMS -->
    <section>
        <div class="section-inner">
            <div class="section-header">
                <div>
                    <div class="section-tag">Our Rooms</div>
                    <h2 class="section-title">Featured Rooms</h2>
                    <p class="section-subtitle">Thoughtfully designed spaces where comfort meets elegance.</p>
                </div>
                <button class="btn-outline" onclick="showPage('rooms')">View All Rooms <i class="fas fa-arrow-right"></i></button>
            </div>
            <div class="cards-grid" id="featured-rooms">
                <?php foreach ($featured_rooms as $room): 
                    $occupied = $room['occupied_count'] ?? 0;
                    $capacity = $room['capacity'] ?? 1;
                    $available_spots = $room['available_spots'] ?? 0;
                    $status = $room['status'] ?? 'available';
                    
                    if ($available_spots == 0) $status = 'full';
                    elseif ($available_spots <= 2) $status = 'few';
                    else $status = 'available';
                    
                    $status_labels = ['available' => 'Available', 'few' => 'Few Left', 'full' => 'Fully Booked'];
                    $badge_classes = ['available' => 'badge-available', 'few' => 'badge-few', 'full' => 'badge-full'];
                    
                    $facilities = [];
                    if (!empty($room['facilities'])) {
                        $facilities = is_array($room['facilities']) ? $room['facilities'] : json_decode($room['facilities'], true);
                        if (!is_array($facilities)) {
                            $facilities = explode(',', $room['facilities'] ?? '');
                        }
                        $facilities = array_filter(array_map('trim', $facilities));
                    }
                ?>
                <div class="room-card animate-in">
                    <div class="room-card-img">
                        <img src="https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=600&q=80" alt="Room <?php echo htmlspecialchars($room['room_number']); ?>" loading="lazy">
                        <span class="room-card-badge <?php echo $badge_classes[$status]; ?>"><?php echo $status_labels[$status]; ?></span>
                        <div class="room-card-fav" onclick="toggleFav(this)"><i class="far fa-heart"></i></div>
                    </div>
                    <div class="room-card-body">
                        <span class="room-type-tag"><?php echo ucfirst($room['type'] ?? 'Standard'); ?></span>
                        <h3>Room <?php echo htmlspecialchars($room['room_number']); ?></h3>
                        <div class="room-rating">
                            <div class="stars">★★★★★</div>
                            <span>4.8 (25 reviews)</span>
                        </div>
                        <div class="room-features">
                            <?php if (!empty($facilities)): ?>
                                <?php foreach (array_slice($facilities, 0, 4) as $facility): ?>
                                    <?php if (!empty($facility) && $facility !== 'null'): ?>
                                        <span class="feat-tag"><i class="fas fa-check"></i><?php echo htmlspecialchars($facility); ?></span>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                                <?php if (count($facilities) > 4): ?>
                                    <span class="feat-tag">+<?php echo count($facilities) - 4; ?> more</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="room-price-row">
                            <div>
                                <div class="room-price">₹<?php echo number_format($room['rent'] ?? 0); ?><span>/mo</span></div>
                                <div style="font-size:.75rem;color:var(--text-muted)">Deposit: ₹<?php echo number_format(($room['rent'] ?? 0) * 2); ?></div>
                            </div>
                            <div class="beds-info"><i class="fas fa-bed"></i> <?php echo $available_spots; ?> spots left</div>
                        </div>
                        <div class="room-card-btns">
                            <button class="btn-outline" onclick="showPage('rooms')">View Details</button>
                            <?php if ($status !== 'full' && $is_logged_in): ?>
                                <button class="btn-primary" onclick="showPage('booking')">Book Now</button>
                            <?php elseif ($status !== 'full' && !$is_logged_in): ?>
                                <button class="btn-primary" onclick="showPage('login')">Login to Book</button>
                            <?php else: ?>
                                <button class="btn-primary" style="background:#ccc;cursor:not-allowed;box-shadow:none;">Fully Booked</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- FACILITIES -->
    <section style="background:var(--lavender)">
        <div class="section-inner">
            <div class="section-header">
                <div>
                    <div class="section-tag">Amenities</div>
                    <h2 class="section-title">Premium Facilities</h2>
                    <p class="section-subtitle">Everything you need for a comfortable, safe, and productive stay.</p>
                </div>
            </div>
            <div class="facilities-grid">
                <?php foreach ($facilities as $facility): ?>
                <div class="facility-card animate-in">
                    <div class="facility-icon" style="background:var(--lavender);color:<?php echo $facility['color']; ?>">
                        <i class="fas <?php echo $facility['icon']; ?>"></i>
                    </div>
                    <h4><?php echo $facility['title']; ?></h4>
                    <p><?php echo $facility['desc']; ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- TESTIMONIALS -->
    <section>
        <div class="section-inner">
            <div class="section-header">
                <div>
                    <div class="section-tag">Reviews</div>
                    <h2 class="section-title">What Our Residents Say</h2>
                </div>
            </div>
            <div class="testimonials-grid">
                <div class="testimonial-card animate-in">
                    <p class="testimonial-text">Graceful Living has been my home for 2 years. The security, the staff, the amenities — everything is top-notch. I feel so safe and comfortable here!</p>
                    <div class="testimonial-author">
                        <img src="https://i.pravatar.cc/100?img=47" alt="" class="testimonial-avatar">
                        <div>
                            <div class="testimonial-name">Priya Sharma</div>
                            <div class="testimonial-role">MBA Student</div>
                        </div>
                        <div style="margin-left:auto"><div class="stars">★★★★★</div></div>
                    </div>
                </div>
                <div class="testimonial-card animate-in">
                    <p class="testimonial-text">The study rooms and WiFi are amazing. I cleared my CA exams while staying here. The peaceful environment makes all the difference!</p>
                    <div class="testimonial-author">
                        <img src="https://i.pravatar.cc/100?img=23" alt="" class="testimonial-avatar">
                        <div>
                            <div class="testimonial-name">Sneha Reddy</div>
                            <div class="testimonial-role">CA Student</div>
                        </div>
                        <div style="margin-left:auto"><div class="stars">★★★★★</div></div>
                    </div>
                </div>
                <div class="testimonial-card animate-in">
                    <p class="testimonial-text">Coming from another city, I was nervous about staying in a hostel. But Graceful Living feels exactly like home. The community of girls here is wonderful!</p>
                    <div class="testimonial-author">
                        <img src="https://i.pravatar.cc/100?img=32" alt="" class="testimonial-avatar">
                        <div>
                            <div class="testimonial-name">Aisha Khan</div>
                            <div class="testimonial-role">Software Engineer</div>
                        </div>
                        <div style="margin-left:auto"><div class="stars">★★★★★</div></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ -->
    <section style="background:var(--lavender)">
        <div class="section-inner">
            <div class="section-header" style="justify-content:center;text-align:center">
                <div>
                    <div class="section-tag">FAQ</div>
                    <h2 class="section-title">Frequently Asked Questions</h2>
                </div>
            </div>
            <div class="faq-list">
                <?php foreach ($faqs as $index => $faq): ?>
                <div class="faq-item <?php echo $index === 0 ? 'open' : ''; ?>">
                    <div class="faq-question" onclick="toggleFAQ(this.parentElement)">
                        <span><?php echo $faq['q']; ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer"><p><?php echo $faq['a']; ?></p></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- FOOTER -->
    <footer>
        <div class="footer-inner">
            <div class="footer-grid">
                <div>
                    <div class="footer-brand-logo">Graceful<span>Living</span></div>
                    <p class="footer-desc">Premium girls hostel offering safe, comfortable, and affordable accommodation for students and working women.</p>
                    <div class="footer-social">
                        <a href="#" class="social-btn"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-btn"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="social-btn"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-btn"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div class="footer-col">
                    <h5>Quick Links</h5>
                    <ul>
                        <li><a href="#" onclick="showPage('home')">Home</a></li>
                        <li><a href="#" onclick="showPage('hostel')">About Hostel</a></li>
                        <li><a href="#" onclick="showPage('rooms')">Rooms</a></li>
                        <li><a href="#" onclick="showPage('gallery')">Gallery</a></li>
                        <li><a href="#" onclick="showPage('contact')">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h5>Services</h5>
                    <ul>
                        <li><a href="#">24/7 Security</a></li>
                        <li><a href="#">High-Speed WiFi</a></li>
                        <li><a href="#">Meals & Dining</a></li>
                        <li><a href="#">Laundry</a></li>
                        <li><a href="#">Study Room</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h5>Contact</h5>
                    <ul>
                        <li><a href="tel:+919876543210">+91 98765 43210</a></li>
                        <li><a href="mailto:hello@gracefulliving.in">hello@gracefulliving.in</a></li>
                        <li><a href="#">123, Rose Lane, Hyderabad</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>© <?php echo date('Y'); ?> Graceful Living. All rights reserved.</p>
                <p>Designed with <i class="fas fa-heart" style="color:#EC4899"></i> for women's safety & comfort</p>
            </div>
        </div>
    </footer>
</div>

<!-- ============================= PAGE: HOSTEL ============================= -->
<div class="page <?php echo $page === 'hostel' ? 'active' : ''; ?>" id="page-hostel">
    <div class="page-hero">
        <h1>Hostel Overview</h1>
        <p>Take a virtual tour of our premium facilities</p>
        <div class="breadcrumb">Home <i class="fas fa-chevron-right" style="font-size:.7rem"></i> <span>Hostel</span></div>
    </div>
    <div class="hostel-layout">
        <div class="hostel-main">
            <div class="slider-wrap">
                <div class="slider-track" id="sliderTrack">
                    <div class="slider-slide"><img src="https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=900&q=80" alt="Exterior"></div>
                    <div class="slider-slide"><img src="https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=900&q=80" alt="Room Interior"></div>
                    <div class="slider-slide"><img src="https://images.unsplash.com/photo-1567767292278-a4f21aa2d36e?w=900&q=80" alt="Common Area"></div>
                    <div class="slider-slide"><img src="https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=900&q=80" alt="Study Room"></div>
                    <div class="slider-slide"><img src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=900&q=80" alt="Dining Hall"></div>
                </div>
                <button class="slider-btn prev" onclick="slideMove(-1)"><i class="fas fa-chevron-left"></i></button>
                <button class="slider-btn next" onclick="slideMove(1)"><i class="fas fa-chevron-right"></i></button>
                <div class="slider-dots" id="sliderDots"></div>
            </div>
            <h2 class="hostel-title">Graceful Living Premium Girls Hostel</h2>
            <div class="hostel-meta">
                <div class="hostel-rating-badge"><i class="fas fa-star"></i> 4.9 (248 reviews)</div>
                <div class="hostel-address"><i class="fas fa-map-marker-alt" style="color:var(--accent)"></i> 123, Rose Lane, Banjara Hills, Hyderabad, Telangana 500032</div>
            </div>
            <p class="hostel-desc">Graceful Living is a premium girls hostel designed for students and working women who want a safe, comfortable, and vibrant living experience. Our state-of-the-art facility features modern rooms, high-speed WiFi, CCTV surveillance, biometric entry, and a warm community atmosphere. We believe every woman deserves a place that feels like home — secure, nurturing, and inspiring.</p>
            <div class="info-grid-2">
                <div class="info-box"><i class="fas fa-phone"></i><div class="info-box-text"><small>Call Us</small><strong>+91 98765 43210</strong></div></div>
                <div class="info-box"><i class="fas fa-envelope"></i><div class="info-box-text"><small>Email</small><strong>hello@gracefulliving.in</strong></div></div>
                <div class="info-box"><i class="fas fa-clock"></i><div class="info-box-text"><small>Check-in Time</small><strong>10:00 AM – 6:00 PM</strong></div></div>
                <div class="info-box"><i class="fas fa-shield-alt"></i><div class="info-box-text"><small>Security</small><strong>24/7 CCTV + Guard</strong></div></div>
            </div>
            <h3 style="font-family:'Poppins',sans-serif;font-weight:700;margin-bottom:14px;color:var(--text)">All Amenities</h3>
            <div class="amenities-chips">
                <?php 
                $all_amenities = ['24/7 CCTV','Biometric Entry','High-Speed WiFi','3 Meals/Day','Laundry','Study Room','AC Rooms','Hot Water','Power Backup','Parking','First Aid','Fire Safety','Housekeeping'];
                foreach ($all_amenities as $amenity): 
                ?>
                <span class="chip"><i class="fas fa-check-circle"></i><?php echo $amenity; ?></span>
                <?php endforeach; ?>
            </div>
            <div class="map-placeholder"><i class="fas fa-map-marked-alt"></i> Interactive Google Map – Banjara Hills, Hyderabad</div>
        </div>
        <div>
            <div class="sticky-card">
                <div style="font-size:.85rem;color:var(--text-muted);margin-bottom:4px">Starting from</div>
                <div class="price-big">₹6,500<span>/month</span></div>
                <div style="display:flex;gap:8px;margin-top:12px">
                    <div class="stars" style="font-size:1rem">★★★★★</div>
                    <span style="font-size:.85rem;color:var(--text-muted)">4.9 (248 reviews)</span>
                </div>
                <div style="margin-top:20px;display:flex;flex-direction:column;gap:10px">
                    <div class="summary-row"><span class="summary-label">Security Deposit</span><span class="summary-value">₹10,000</span></div>
                    <div class="summary-row"><span class="summary-label">Meals Included</span><span class="summary-value">✓ Yes</span></div>
                    <div class="summary-row"><span class="summary-label">WiFi</span><span class="summary-value">✓ Free</span></div>
                    <div class="summary-row"><span class="summary-label">Laundry</span><span class="summary-value">✓ Included</span></div>
                </div>
                <button class="btn-primary book-btn" onclick="showPage('booking')"><i class="fas fa-calendar-check"></i> Book Your Room</button>
                <button class="btn-outline" style="width:100%;margin-top:10px;padding:12px" onclick="showPage('contact')"><i class="fas fa-phone"></i> Contact Us</button>
            </div>
        </div>
    </div>
</div>

<!-- ============================= PAGE: ROOMS ============================= -->
<div class="page <?php echo $page === 'rooms' ? 'active' : ''; ?>" id="page-rooms">
    <div class="page-hero">
        <h1>Our Rooms</h1>
        <p>Choose from our range of comfortable, well-appointed rooms</p>
        <div class="breadcrumb">Home <i class="fas fa-chevron-right" style="font-size:.7rem"></i> <span>Rooms</span></div>
    </div>
    <section>
        <div class="section-inner">
            <div class="gallery-filters">
                <button class="filter-btn active" onclick="filterRooms('all',this)">All Rooms</button>
                <?php foreach ($room_types as $type): ?>
                    <button class="filter-btn" onclick="filterRooms('<?php echo $type; ?>',this)"><?php echo ucfirst($type); ?></button>
                <?php endforeach; ?>
            </div>
            <div class="cards-grid" id="all-rooms">
                <?php foreach ($all_rooms as $room): 
                    $occupied = $room['occupied_count'] ?? 0;
                    $capacity = $room['capacity'] ?? 1;
                    $available_spots = $room['available_spots'] ?? 0;
                    $status = $room['status'] ?? 'available';
                    
                    if ($available_spots == 0) $status = 'full';
                    elseif ($available_spots <= 2) $status = 'few';
                    else $status = 'available';
                    
                    $status_labels = ['available' => 'Available', 'few' => 'Few Left', 'full' => 'Fully Booked'];
                    $badge_classes = ['available' => 'badge-available', 'few' => 'badge-few', 'full' => 'badge-full'];
                    
                    $facilities = [];
                    if (!empty($room['facilities'])) {
                        $facilities = is_array($room['facilities']) ? $room['facilities'] : json_decode($room['facilities'], true);
                        if (!is_array($facilities)) {
                            $facilities = explode(',', $room['facilities'] ?? '');
                        }
                        $facilities = array_filter(array_map('trim', $facilities));
                    }
                ?>
                <div class="room-card animate-in" data-type="<?php echo $room['type'] ?? ''; ?>">
                    <div class="room-card-img">
                        <img src="https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=600&q=80" alt="Room <?php echo htmlspecialchars($room['room_number']); ?>" loading="lazy">
                        <span class="room-card-badge <?php echo $badge_classes[$status]; ?>"><?php echo $status_labels[$status]; ?></span>
                        <div class="room-card-fav" onclick="toggleFav(this)"><i class="far fa-heart"></i></div>
                    </div>
                    <div class="room-card-body">
                        <span class="room-type-tag"><?php echo ucfirst($room['type'] ?? 'Standard'); ?></span>
                        <h3>Room <?php echo htmlspecialchars($room['room_number']); ?> • Floor <?php echo $room['floor'] ?? '1'; ?></h3>
                        <div class="room-rating">
                            <div class="stars">★★★★★</div>
                            <span>4.8 (25 reviews)</span>
                        </div>
                        <div class="room-features">
                            <?php if (!empty($facilities)): ?>
                                <?php foreach (array_slice($facilities, 0, 4) as $facility): ?>
                                    <?php if (!empty($facility) && $facility !== 'null'): ?>
                                        <span class="feat-tag"><i class="fas fa-check"></i><?php echo htmlspecialchars($facility); ?></span>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                                <?php if (count($facilities) > 4): ?>
                                    <span class="feat-tag">+<?php echo count($facilities) - 4; ?> more</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="room-price-row">
                            <div>
                                <div class="room-price">₹<?php echo number_format($room['rent'] ?? 0); ?><span>/mo</span></div>
                                <div style="font-size:.75rem;color:var(--text-muted)">Deposit: ₹<?php echo number_format(($room['rent'] ?? 0) * 2); ?></div>
                            </div>
                            <div class="beds-info"><i class="fas fa-bed"></i> <?php echo $available_spots; ?> spots left</div>
                        </div>
                        <div class="room-card-btns">
                            <a href="room_details.php?id=<?php echo $room['id']; ?>" class="btn-outline" style="text-align:center;text-decoration:none;">View Details</a>
                            <?php if ($status !== 'full' && $is_logged_in): ?>
                                <a href="booking.php?room=<?php echo $room['id']; ?>" class="btn-primary" style="text-align:center;text-decoration:none;">Book Now</a>
                            <?php elseif ($status !== 'full' && !$is_logged_in): ?>
                                <button class="btn-primary" onclick="showPage('login')">Login to Book</button>
                            <?php else: ?>
                                <button class="btn-primary" style="background:#ccc;cursor:not-allowed;box-shadow:none;">Fully Booked</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
</div>

<!-- ============================= PAGE: GALLERY ============================= -->
<div class="page <?php echo $page === 'gallery' ? 'active' : ''; ?>" id="page-gallery">
    <div class="page-hero">
        <h1>Photo Gallery</h1>
        <p>A visual tour of our beautiful hostel spaces</p>
        <div class="breadcrumb">Home <i class="fas fa-chevron-right" style="font-size:.7rem"></i> <span>Gallery</span></div>
    </div>
    <section>
        <div class="section-inner">
            <div class="gallery-filters">
                <button class="filter-btn active" onclick="filterGallery('all',this)">All</button>
                <button class="filter-btn" onclick="filterGallery('rooms',this)">Rooms</button>
                <button class="filter-btn" onclick="filterGallery('common',this)">Common Areas</button>
                <button class="filter-btn" onclick="filterGallery('facilities',this)">Facilities</button>
                <button class="filter-btn" onclick="filterGallery('outdoor',this)">Outdoor</button>
            </div>
            <div class="gallery-masonry" id="gallery-grid">
                <?php foreach ($gallery_items as $item): ?>
                <div class="gallery-item" data-cat="<?php echo $item['cat']; ?>" onclick="openLightbox('<?php echo $item['src']; ?>')">
                    <img src="<?php echo $item['src']; ?>" alt="<?php echo $item['label']; ?>" loading="lazy">
                    <div class="gallery-overlay"><span><i class="fas fa-search-plus"></i> <?php echo $item['label']; ?></span></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
</div>

<!-- ============================= PAGE: BOOKING ============================= -->
<div class="page <?php echo $page === 'booking' ? 'active' : ''; ?>" id="page-booking">
    <div class="page-hero">
        <h1>Book Your Room</h1>
        <p>Fill in your details and secure your spot</p>
        <div class="breadcrumb">Home <i class="fas fa-chevron-right" style="font-size:.7rem"></i> <span>Booking</span></div>
    </div>
    <div class="booking-form-wrap">
        <div class="form-card">
            <form action="process_booking.php" method="POST">
                <div class="form-section-title"><i class="fas fa-user"></i>Personal Details</div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="full_name" placeholder="e.g. Priya Sharma" value="<?php echo htmlspecialchars($user_name); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" name="email" placeholder="priya@email.com" value="<?php echo htmlspecialchars($user_email); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" name="phone" placeholder="+91 98765 43210" required>
                    </div>
                    <div class="form-group">
                        <label>Emergency Contact</label>
                        <input type="tel" name="emergency_contact" placeholder="Parent / Guardian Number" required>
                    </div>
                    <div class="form-group full">
                        <label>Address</label>
                        <input type="text" name="address" placeholder="City, State, PIN">
                    </div>
                </div>
                
                <div class="form-section-title"><i class="fas fa-calendar-alt"></i>Booking Details</div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Room Type</label>
                        <select name="room_type" required>
                            <option value="">Select Room Type</option>
                            <?php foreach ($room_types as $type): ?>
                                <option value="<?php echo htmlspecialchars($type); ?>"><?php echo ucfirst(htmlspecialchars($type)); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Check-in Date</label>
                        <input type="date" name="check_in" required>
                    </div>
                    <div class="form-group">
                        <label>Duration (Months)</label>
                        <select name="duration">
                            <?php for ($i = 1; $i <= 12; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?> Month<?php echo $i > 1 ? 's' : ''; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Number of Guests</label>
                        <select name="guests">
                            <?php for ($i = 1; $i <= 4; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-section-title"><i class="fas fa-upload"></i>Documents</div>
                <div class="form-grid">
                    <div class="upload-zone" onclick="document.getElementById('aadhaar').click()">
                        <i class="fas fa-id-card"></i>
                        <p>Upload <strong>Aadhaar Card</strong></p>
                        <p style="font-size:.78rem;margin-top:6px;opacity:.6">JPG, PNG or PDF – Max 5MB</p>
                        <input type="file" id="aadhaar" accept=".jpg,.jpeg,.png,.pdf" style="display:none" onchange="showToast('File uploaded: ' + this.files[0].name)">
                    </div>
                    <div class="upload-zone" onclick="document.getElementById('photo').click()">
                        <i class="fas fa-camera"></i>
                        <p>Upload <strong>Passport Photo</strong></p>
                        <p style="font-size:.78rem;margin-top:6px;opacity:.6">JPG or PNG – Max 2MB</p>
                        <input type="file" id="photo" accept=".jpg,.jpeg,.png" style="display:none" onchange="showToast('File uploaded: ' + this.files[0].name)">
                    </div>
                </div>
                
                <div class="checkbox-row">
                    <input type="checkbox" id="rules" name="rules" required>
                    <label for="rules">I agree to the <strong style="color:var(--primary)">Hostel Rules & Regulations</strong> and confirm all information provided is accurate.</label>
                </div>
                <button type="submit" class="btn-primary form-submit"><i class="fas fa-check-circle"></i>Confirm Booking</button>
            </form>
        </div>
    </div>
</div>

<!-- ============================= PAGE: PAYMENT ============================= -->
<div class="page <?php echo $page === 'payment' ? 'active' : ''; ?>" id="page-payment">
    <div class="page-hero">
        <h1>Secure Payment</h1>
        <p>Complete your booking with a secure payment</p>
        <div class="breadcrumb">Home <i class="fas fa-chevron-right" style="font-size:.7rem"></i> <span>Payment</span></div>
    </div>
    <div class="payment-layout">
        <div>
            <div class="payment-summary">
                <h3 style="font-family:'Poppins',sans-serif;font-weight:800;margin-bottom:20px;color:var(--text)"><i class="fas fa-receipt" style="color:var(--primary)"></i> Booking Summary</h3>
                <div class="summary-row"><span class="summary-label">Hostel</span><span class="summary-value">Graceful Living, Hyderabad</span></div>
                <div class="summary-row"><span class="summary-label">Room Number</span><span class="summary-value">Room 204 – 2nd Floor</span></div>
                <div class="summary-row"><span class="summary-label">Room Type</span><span class="summary-value">Double Sharing (A/C)</span></div>
                <div class="summary-row"><span class="summary-label">Duration</span><span class="summary-value">3 Months (Jun – Aug 2025)</span></div>
                <div class="summary-row"><span class="summary-label">Monthly Rent</span><span class="summary-value">₹8,500 × 3</span></div>
                <div class="summary-row"><span class="summary-label">Security Deposit</span><span class="summary-value">₹10,000</span></div>
                <div class="summary-row"><span class="summary-label">Meals (3 months)</span><span class="summary-value">₹4,500</span></div>
                <div class="summary-row"><span class="summary-label">GST (18%)</span><span class="summary-value">₹6,570</span></div>
                <div class="summary-row" style="border-top:2px solid var(--primary);padding-top:16px;margin-top:8px">
                    <span>Total Amount</span>
                    <span style="color:var(--primary);font-size:1.3rem">₹46,570</span>
                </div>
            </div>
            <div class="secure-badge"><i class="fas fa-lock"></i>256-bit SSL Encrypted · PCI DSS Compliant</div>
        </div>
        <div class="payment-methods">
            <h3 style="font-family:'Poppins',sans-serif;font-weight:800;margin-bottom:16px;color:var(--text)">Choose Payment Method</h3>
            <div class="payment-tabs">
                <button class="pay-tab active" onclick="setPayTab('upi',this)">UPI</button>
                <button class="pay-tab" onclick="setPayTab('card',this)">Card</button>
                <button class="pay-tab" onclick="setPayTab('netbank',this)">Net Banking</button>
                <button class="pay-tab" onclick="setPayTab('qr',this)">QR Code</button>
            </div>
            <div id="pay-upi">
                <p style="font-size:.85rem;color:var(--text-muted);margin-bottom:14px">Select UPI App</p>
                <div class="upi-grid">
                    <div class="upi-btn" onclick="selectUPI(this)"><div style="font-size:2rem">G</div><span>Google Pay</span></div>
                    <div class="upi-btn" onclick="selectUPI(this)"><div style="font-size:2rem;color:#5f259f">P</div><span>PhonePe</span></div>
                    <div class="upi-btn" onclick="selectUPI(this)"><div style="font-size:2rem;color:#00BAF2">₿</div><span>Paytm</span></div>
                    <div class="upi-btn" onclick="selectUPI(this)"><div style="font-size:2rem;color:#FF6B00">₹</div><span>BHIM</span></div>
                    <div class="upi-btn" onclick="selectUPI(this)"><div style="font-size:1.4rem"><i class="fas fa-university"></i></div><span>Any UPI</span></div>
                </div>
                <input class="upi-input" placeholder="Enter UPI ID (e.g. name@paytm)">
                <button class="btn-primary pay-btn" onclick="processPayment()"><i class="fas fa-lock"></i> Pay ₹46,570 Securely</button>
            </div>
            <div id="pay-card" style="display:none">
                <div class="form-group" style="margin-bottom:14px">
                    <label>Card Number</label>
                    <input type="text" placeholder="1234 5678 9012 3456" style="padding:14px;background:var(--bg);border:2px solid var(--border);border-radius:12px;width:100%;color:var(--text)">
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
                    <div class="form-group"><label>Expiry</label><input type="text" placeholder="MM / YY" style="padding:14px;background:var(--bg);border:2px solid var(--border);border-radius:12px;width:100%;color:var(--text)"></div>
                    <div class="form-group"><label>CVV</label><input type="text" placeholder="•••" maxlength="3" style="padding:14px;background:var(--bg);border:2px solid var(--border);border-radius:12px;width:100%;color:var(--text)"></div>
                </div>
                <button class="btn-primary pay-btn" onclick="processPayment()"><i class="fas fa-lock"></i> Pay ₹46,570 Securely</button>
            </div>
            <div id="pay-netbank" style="display:none">
                <select style="width:100%;padding:14px;background:var(--bg);border:2px solid var(--border);border-radius:12px;color:var(--text);margin-bottom:16px">
                    <option>Select Your Bank</option>
                    <option>SBI</option><option>HDFC Bank</option><option>ICICI Bank</option>
                    <option>Axis Bank</option><option>PNB</option><option>Kotak Bank</option>
                </select>
                <button class="btn-primary pay-btn" onclick="processPayment()"><i class="fas fa-lock"></i> Pay ₹46,570 Securely</button>
            </div>
            <div id="pay-qr" style="display:none">
                <div style="text-align:center;padding:24px;background:var(--lavender);border-radius:12px">
                    <div style="width:160px;height:160px;background:#fff;border-radius:12px;margin:0 auto 14px;display:flex;align-items:center;justify-content:center;font-size:3rem;color:var(--primary)"><i class="fas fa-qrcode"></i></div>
                    <p style="font-size:.9rem;color:var(--text-muted);margin-bottom:8px">Scan with any UPI App</p>
                    <strong style="font-size:.95rem;color:var(--text)">₹46,570</strong>
                    <p style="font-size:.8rem;color:var(--text-muted);margin-top:8px">UPI ID: graceful@paytm</p>
                </div>
                <button class="btn-primary pay-btn" onclick="processPayment()"><i class="fas fa-check"></i> I've Made the Payment</button>
            </div>
        </div>
    </div>
</div>

<!-- ============================= PAGE: STUDENT DASHBOARD ============================= -->
<div class="page <?php echo $page === 'student' ? 'active' : ''; ?>" id="page-student">
    <?php if (!$is_logged_in): ?>
        <div style="display:flex;align-items:center;justify-content:center;min-height:60vh;padding:40px">
            <div style="text-align:center">
                <i class="fas fa-lock" style="font-size:3rem;color:var(--text-muted);margin-bottom:16px"></i>
                <h3 style="color:var(--text)">Please Login First</h3>
                <p style="color:var(--text-muted);margin-bottom:20px">You need to be logged in to view your dashboard.</p>
                <button class="btn-primary" onclick="showPage('login')">Login Now</button>
            </div>
        </div>
    <?php else: ?>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <div class="sidebar-logo">Graceful<span style="-webkit-text-fill-color:var(--text-muted);font-weight:300">Living</span></div>
            <nav class="sidebar-nav">
                <a href="#" class="active"><i class="fas fa-home"></i>Dashboard</a>
                <a href="#"><i class="fas fa-user"></i>My Profile</a>
                <a href="#"><i class="fas fa-bed"></i>My Room</a>
                <a href="#" onclick="showPage('payment')"><i class="fas fa-credit-card"></i>Payments</a>
                <a href="#"><i class="fas fa-history"></i>Booking History</a>
                <a href="#"><i class="fas fa-file-invoice"></i>Receipts</a>
                <a href="#"><i class="fas fa-exclamation-circle"></i>Complaints</a>
                <a href="#" style="margin-top:auto;color:var(--danger)" onclick="window.location.href='logout.php'"><i class="fas fa-sign-out-alt"></i>Logout</a>
            </nav>
        </aside>
        <main class="dash-main">
            <div class="profile-card-s">
                <img src="https://i.pravatar.cc/200?img=47" alt="" class="profile-avatar-s">
                <div class="profile-info">
                    <h2><?php echo htmlspecialchars($user_name); ?></h2>
                    <p><?php echo htmlspecialchars($user_email); ?></p>
                    <?php if ($user_booking): ?>
                        <div class="room-tag">Room <?php echo htmlspecialchars($user_booking['room_number']); ?> · <?php echo ucfirst($user_booking['type']); ?> · Floor <?php echo $user_booking['floor']; ?></div>
                    <?php else: ?>
                        <div class="room-tag">No room assigned yet</div>
                    <?php endif; ?>
                </div>
                <?php if ($user_booking): ?>
                <div style="margin-left:auto;text-align:right">
                    <div style="font-size:1.8rem;font-weight:800">₹<?php echo number_format($user_booking['rent'] ?? 0); ?></div>
                    <div style="opacity:.7;font-size:.85rem">Due: <?php echo date('jS F Y', strtotime('first day of next month')); ?></div>
                    <button class="btn-accent" style="margin-top:10px;padding:8px 20px;font-size:.85rem" onclick="showPage('payment')">Pay Now</button>
                </div>
                <?php endif; ?>
            </div>
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-icon" style="background:var(--lavender)"><i class="fas fa-calendar-check" style="color:var(--primary)"></i></div><div><div class="stat-num">8</div><div class="stat-label">Months Stayed</div></div></div>
                <div class="stat-card"><div class="stat-icon" style="background:rgba(34,197,94,0.1)"><i class="fas fa-check-circle" style="color:var(--success)"></i></div><div><div class="stat-num">7</div><div class="stat-label">Payments Done</div></div></div>
                <div class="stat-card"><div class="stat-icon" style="background:rgba(245,158,11,0.1)"><i class="fas fa-exclamation" style="color:var(--warning)"></i></div><div><div class="stat-num">1</div><div class="stat-label">Due Payment</div></div></div>
                <div class="stat-card"><div class="stat-icon" style="background:var(--pink-light)"><i class="fas fa-star" style="color:var(--accent)"></i></div><div><div class="stat-num">4.9</div><div class="stat-label">Your Rating</div></div></div>
            </div>
            <div class="dash-card">
                <div class="dash-card-header"><span class="dash-card-title">Payment History</span><button class="btn-outline" style="padding:8px 16px;font-size:.82rem" onclick="showToast('Invoice downloaded!')"><i class="fas fa-download"></i> Download All</button></div>
                <table class="dash-table">
                    <thead><tr><th>Month</th><th>Amount</th><th>Date Paid</th><th>Method</th><th>Status</th></tr></thead>
                    <tbody>
                        <tr><td>June 2025</td><td>₹8,500</td><td>1 Jun 2025</td><td>UPI – GPay</td><td><span class="status-pill pill-paid">Paid</span></td></tr>
                        <tr><td>May 2025</td><td>₹8,500</td><td>1 May 2025</td><td>UPI – PhonePe</td><td><span class="status-pill pill-paid">Paid</span></td></tr>
                        <tr><td>July 2025</td><td>₹8,500</td><td>–</td><td>–</td><td><span class="status-pill pill-pending">Pending</span></td></tr>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <?php endif; ?>
</div>

<!-- ============================= PAGE: CONTACT ============================= -->
<div class="page <?php echo $page === 'contact' ? 'active' : ''; ?>" id="page-contact">
    <div class="page-hero">
        <h1>Get in Touch</h1>
        <p>We're here to help — reach out anytime</p>
        <div class="breadcrumb">Home <i class="fas fa-chevron-right" style="font-size:.7rem"></i> <span>Contact</span></div>
    </div>
    <div class="contact-layout">
        <div>
            <h2 style="font-family:'Poppins',sans-serif;font-size:1.8rem;font-weight:800;color:var(--text);margin-bottom:16px">Let's Talk</h2>
            <p style="color:var(--text-muted);line-height:1.7;margin-bottom:32px">Have questions about our rooms, pricing, or facilities? Our team is ready to assist you with everything you need.</p>
            <div class="contact-item">
                <div class="contact-icon" style="background:var(--lavender)"><i class="fas fa-phone" style="color:var(--primary)"></i></div>
                <div class="contact-item-text"><strong>Call Us</strong><span>+91 98765 43210 (9 AM – 9 PM)</span></div>
            </div>
            <div class="contact-item">
                <div class="contact-icon" style="background:var(--pink-light)"><i class="fas fa-envelope" style="color:var(--accent)"></i></div>
                <div class="contact-item-text"><strong>Email</strong><span>hello@gracefulliving.in</span></div>
            </div>
            <div class="contact-item">
                <div class="contact-icon" style="background:rgba(37,211,102,0.1)"><i class="fab fa-whatsapp" style="color:#25D366"></i></div>
                <div class="contact-item-text"><strong>WhatsApp</strong><span>Chat with us instantly</span></div>
            </div>
            <div class="contact-item">
                <div class="contact-icon" style="background:var(--sky)"><i class="fas fa-map-marker-alt" style="color:#0EA5E9"></i></div>
                <div class="contact-item-text"><strong>Visit Us</strong><span>123, Rose Lane, Banjara Hills, Hyderabad – 500032</span></div>
            </div>
            <div class="contact-social">
                <a href="#" class="social-contact-btn" style="display:inline-flex;width:44px;height:44px;border-radius:12px;align-items:center;justify-content:center;font-size:1rem;color:#fff;transition:var(--transition);background:#E1306C"><i class="fab fa-instagram"></i></a>
                <a href="#" class="social-contact-btn" style="display:inline-flex;width:44px;height:44px;border-radius:12px;align-items:center;justify-content:center;font-size:1rem;color:#fff;transition:var(--transition);background:#1877F2"><i class="fab fa-facebook"></i></a>
                <a href="#" class="social-contact-btn" style="display:inline-flex;width:44px;height:44px;border-radius:12px;align-items:center;justify-content:center;font-size:1rem;color:#fff;transition:var(--transition);background:#1DA1F2"><i class="fab fa-twitter"></i></a>
                <a href="#" class="social-contact-btn" style="display:inline-flex;width:44px;height:44px;border-radius:12px;align-items:center;justify-content:center;font-size:1rem;color:#fff;transition:var(--transition);background:#25D366"><i class="fab fa-whatsapp"></i></a>
            </div>
        </div>
        <div>
            <div class="form-card">
                <div class="form-section-title"><i class="fas fa-paper-plane"></i>Send a Message</div>
                <form action="process_contact.php" method="POST">
                    <div class="form-grid">
                        <div class="form-group"><label>Your Name</label><input type="text" name="name" placeholder="Priya Sharma" value="<?php echo htmlspecialchars($user_name); ?>" required></div>
                        <div class="form-group"><label>Email</label><input type="email" name="email" placeholder="priya@email.com" value="<?php echo htmlspecialchars($user_email); ?>" required></div>
                        <div class="form-group"><label>Phone</label><input type="tel" name="phone" placeholder="+91 98765 43210"></div>
                        <div class="form-group"><label>Subject</label>
                            <select name="subject">
                                <option>Room Inquiry</option><option>Pricing</option><option>Facilities</option><option>Complaint</option><option>Other</option>
                            </select>
                        </div>
                        <div class="form-group full"><label>Message</label><textarea name="message" placeholder="Tell us how we can help you…" required></textarea></div>
                    </div>
                    <button type="submit" class="btn-primary form-submit"><i class="fas fa-paper-plane"></i> Send Message</button>
                </form>
                <div class="map-placeholder" style="margin-top:20px"><i class="fas fa-map-marked-alt"></i> Google Map – Banjara Hills, Hyderabad</div>
            </div>
        </div>
    </div>
</div>

<!-- ============================= PAGE: LOGIN ============================= -->
<div class="page <?php echo $page === 'login' ? 'active' : ''; ?>" id="page-login">
    <div style="min-height:calc(100vh - var(--nav-h));display:flex;align-items:center;justify-content:center;padding:40px 24px;background:linear-gradient(135deg,var(--lavender),var(--pink-light))">
        <div style="background:var(--card);border-radius:var(--radius);box-shadow:var(--shadow);padding:40px;width:100%;max-width:440px;border:1px solid var(--border)">
            <div style="text-align:center;margin-bottom:32px">
                <div style="font-family:'Poppins',sans-serif;font-size:1.8rem;font-weight:800;background:linear-gradient(135deg,var(--primary),var(--accent));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text">Graceful Living</div>
                <p style="color:var(--text-muted);margin-top:8px;font-size:.95rem">Welcome back! Sign in to continue.</p>
            </div>
            <div style="display:flex;gap:8px;margin-bottom:28px;background:var(--bg);padding:6px;border-radius:10px">
                <button id="login-tab" onclick="switchLoginTab('login')" style="flex:1;padding:10px;border-radius:8px;font-weight:700;font-size:.9rem;background:var(--primary);color:#fff;border:none">Sign In</button>
                <button id="register-tab" onclick="switchLoginTab('register')" style="flex:1;padding:10px;border-radius:8px;font-weight:700;font-size:.9rem;background:transparent;color:var(--text-muted);border:none">Register</button>
            </div>
            <form id="login-form" action="process_login.php" method="POST">
                <div class="form-group" style="margin-bottom:16px">
                    <label>Email Address</label>
                    <input type="email" name="email" placeholder="you@email.com" style="width:100%;padding:14px;background:var(--bg);border:2px solid var(--border);border-radius:12px;color:var(--text)" required>
                </div>
                <div class="form-group" style="margin-bottom:16px">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Enter your password" style="width:100%;padding:14px;background:var(--bg);border:2px solid var(--border);border-radius:12px;color:var(--text)" required>
                </div>
                <div style="display:flex;justify-content:space-between;margin-bottom:24px">
                    <label style="display:flex;align-items:center;gap:8px;font-size:.88rem;color:var(--text-muted);cursor:pointer">
                        <input type="checkbox" name="remember" style="accent-color:var(--primary)"> Remember me
                    </label>
                    <a href="#" style="color:var(--primary);font-size:.88rem;font-weight:600">Forgot password?</a>
                </div>
                <button type="submit" class="btn-primary" style="width:100%;padding:14px;font-size:1rem"><i class="fas fa-sign-in-alt"></i> Sign In</button>
                <div style="text-align:center;margin-top:20px;font-size:.88rem;color:var(--text-muted)">
                    Don't have an account? <a href="#" style="color:var(--primary);font-weight:700" onclick="switchLoginTab('register')">Register now</a>
                </div>
            </form>
            <form id="register-form" action="process_register.php" method="POST" style="display:none">
                <div class="form-group" style="margin-bottom:14px">
                    <label>Full Name</label>
                    <input type="text" name="name" placeholder="Priya Sharma" style="width:100%;padding:14px;background:var(--bg);border:2px solid var(--border);border-radius:12px;color:var(--text)" required>
                </div>
                <div class="form-group" style="margin-bottom:14px">
                    <label>Email</label>
                    <input type="email" name="email" placeholder="you@email.com" style="width:100%;padding:14px;background:var(--bg);border:2px solid var(--border);border-radius:12px;color:var(--text)" required>
                </div>
                <div class="form-group" style="margin-bottom:14px">
                    <label>Phone</label>
                    <input type="tel" name="phone" placeholder="+91 98765 43210" style="width:100%;padding:14px;background:var(--bg);border:2px solid var(--border);border-radius:12px;color:var(--text)" required>
                </div>
                <div class="form-group" style="margin-bottom:14px">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Create a strong password" style="width:100%;padding:14px;background:var(--bg);border:2px solid var(--border);border-radius:12px;color:var(--text)" required>
                </div>
                <div style="margin-bottom:20px">
                    <label style="display:flex;align-items:center;gap:8px;font-size:.88rem;color:var(--text-muted);cursor:pointer">
                        <input type="checkbox" name="terms" style="accent-color:var(--primary)" required> I agree to <a href="#" style="color:var(--primary)">Terms & Conditions</a>
                    </label>
                </div>
                <button type="submit" class="btn-accent" style="width:100%;padding:14px;font-size:1rem"><i class="fas fa-user-plus"></i> Create Account</button>
            </form>
        </div>
    </div>
</div>

<script>
// ===== PAGE NAVIGATION =====
function showPage(id) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const target = document.getElementById('page-' + id);
    if (target) target.classList.add('active');
    
    document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
    const map = {home:0, hostel:1, rooms:2, gallery:3, contact:4};
    const links = document.querySelectorAll('.nav-links a');
    if (map[id] !== undefined && links[map[id]]) links[map[id]].classList.add('active');
    
    window.scrollTo({top: 0, behavior: 'smooth'});
    document.getElementById('navLinks').classList.remove('mobile-open');
}

// ===== TOGGLE MOBILE NAV =====
function toggleMobile() {
    document.getElementById('navLinks').classList.toggle('mobile-open');
}

// ===== TOAST =====
function showToast(msg) {
    const t = document.getElementById('toast');
    document.getElementById('toast-msg').textContent = msg;
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.remove('show'), 3000);
}

// ===== THEME =====
function toggleTheme() {
    const html = document.documentElement;
    const dark = html.getAttribute('data-theme') === 'dark';
    html.setAttribute('data-theme', dark ? 'light' : 'dark');
    const icon = document.getElementById('themeIcon');
    icon.className = dark ? 'fas fa-moon' : 'fas fa-sun';
}

// ===== FAQ =====
function toggleFAQ(el) {
    el.classList.toggle('open');
}

// ===== FAV =====
function toggleFav(el) {
    el.classList.toggle('active');
    el.innerHTML = el.classList.contains('active') ? '<i class="fas fa-heart"></i>' : '<i class="far fa-heart"></i>';
    showToast(el.classList.contains('active') ? 'Added to wishlist!' : 'Removed from wishlist');
}

// ===== SLIDER =====
let slideIndex = 0;
const totalSlides = 5;

function initSlider() {
    const dots = document.getElementById('sliderDots');
    if (!dots) return;
    dots.innerHTML = Array.from({length: totalSlides}, (_, i) => 
        `<div class="slider-dot ${i === 0 ? 'active' : ''}" onclick="goToSlide(${i})"></div>`
    ).join('');
}

function slideMove(dir) {
    slideIndex = (slideIndex + dir + totalSlides) % totalSlides;
    updateSlider();
}

function goToSlide(i) {
    slideIndex = i;
    updateSlider();
}

function updateSlider() {
    const t = document.getElementById('sliderTrack');
    if (t) t.style.transform = `translateX(-${slideIndex * 100}%)`;
    document.querySelectorAll('.slider-dot').forEach((d, i) => 
        d.classList.toggle('active', i === slideIndex)
    );
}

// ===== GALLERY FILTER =====
function filterGallery(cat, btn) {
    document.querySelectorAll('#page-gallery .filter-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    
    document.querySelectorAll('#page-gallery .gallery-item').forEach(item => {
        const show = cat === 'all' || item.dataset.cat === cat;
        item.style.display = show ? 'block' : 'none';
    });
}

// ===== ROOM FILTER =====
function filterRooms(type, btn) {
    document.querySelectorAll('#page-rooms .filter-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    
    document.querySelectorAll('#page-rooms .room-card').forEach(card => {
        const show = type === 'all' || card.dataset.type === type;
        card.style.display = show ? 'block' : 'none';
    });
}

// ===== LIGHTBOX =====
function openLightbox(src) {
    const lb = document.getElementById('lightbox') || createLightbox();
    const img = lb.querySelector('img');
    if (img) img.src = src;
    lb.classList.add('open');
}

function createLightbox() {
    const div = document.createElement('div');
    div.id = 'lightbox';
    div.className = 'lightbox';
    div.innerHTML = `
        <button class="lightbox-close" onclick="this.parentElement.classList.remove('open')"><i class="fas fa-times"></i></button>
        <img id="lightbox-img" src="" alt="Gallery">
    `;
    div.addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('open');
    });
    document.body.appendChild(div);
    return div;
}

// ===== PAYMENT TABS =====
function setPayTab(tab, btn) {
    document.querySelectorAll('.pay-tab').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    ['upi', 'card', 'netbank', 'qr'].forEach(t => {
        const el = document.getElementById('pay-' + t);
        if (el) el.style.display = t === tab ? 'block' : 'none';
    });
}

function selectUPI(el) {
    document.querySelectorAll('.upi-btn').forEach(b => b.classList.remove('selected'));
    el.classList.add('selected');
}

function processPayment() {
    showToast('Processing payment… Please wait.');
    setTimeout(() => showToast('✓ Payment Successful! Booking confirmed.'), 2000);
}

// ===== LOGIN TABS =====
function switchLoginTab(tab) {
    const lf = document.getElementById('login-form');
    const rf = document.getElementById('register-form');
    const lt = document.getElementById('login-tab');
    const rt = document.getElementById('register-tab');
    
    if (tab === 'login') {
        lf.style.display = 'block';
        rf.style.display = 'none';
        lt.style.background = 'var(--primary)';
        lt.style.color = '#fff';
        rt.style.background = 'transparent';
        rt.style.color = 'var(--text-muted)';
    } else {
        lf.style.display = 'none';
        rf.style.display = 'block';
        rt.style.background = 'var(--primary)';
        rt.style.color = '#fff';
        lt.style.background = 'transparent';
        lt.style.color = 'var(--text-muted)';
    }
}

// ===== INIT =====
window.addEventListener('load', function() {
    setTimeout(() => {
        const loader = document.getElementById('loader');
        if (loader) loader.classList.add('hidden');
    }, 1000);
    
    initSlider();
    setInterval(() => slideMove(1), 4000);
    
    // Set today's dates
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    document.querySelectorAll('input[type=date]').forEach((el, i) => {
        el.value = i % 2 === 0 ? today : tomorrow;
    });
    
    // Check if we're on a page that needs to show the login form
    <?php if ($page === 'login'): ?>
    // If we're on login page and user is already logged in, redirect to dashboard
    <?php if ($is_logged_in): ?>
    showPage('student');
    <?php endif; ?>
    <?php endif; ?>
});
</script>
</body>
</html>