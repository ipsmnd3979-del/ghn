<?php
// index.php - Main entry point with page routing
session_start();
include '../../config/database.php';

// Get current page from URL parameter
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

// Define allowed pages
$allowed_pages = ['home', 'hostel', 'rooms', 'gallery', 'booking', 'payment', 'student', 'admin', 'contact', 'login', 'facilities'];

// Validate page
if (!in_array($page, $allowed_pages)) {
    $page = 'home';
}

// Check if user is logged in
$is_logged_in = isset($_SESSION['user_id']);
$user_name = $_SESSION['user_name'] ?? 'Guest';
$user_role = $_SESSION['user_role'] ?? 'guest';
$user_email = $_SESSION['user_email'] ?? '';

// Database connection
$database = new Database();
$db = $database->getConnection();

// Fetch data for home page
$featured_rooms = [];
$room_types = [];
$stats = [];

try {
    // Get room types
    $stmt = $db->query("SELECT DISTINCT type FROM rooms");
    $room_types = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Get available rooms with occupancy
    $stmt = $db->query("
        SELECT r.*, 
               COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0) as occupied_count,
               (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) as available_spots
        FROM rooms r 
        WHERE r.status = 'available'
        AND (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) > 0
        ORDER BY r.rent ASC
        LIMIT 6
    ");
    $featured_rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get statistics
    $stmt = $db->query("SELECT COUNT(*) as total_students FROM students WHERE status = 'active'");
    $stats['total_students'] = $stmt->fetchColumn();
    
    $stmt = $db->query("SELECT COUNT(*) as total_rooms FROM rooms");
    $stats['total_rooms'] = $stmt->fetchColumn();
    
    $stmt = $db->query("SELECT COUNT(*) as available_rooms FROM rooms WHERE status = 'available'");
    $stats['available_rooms'] = $stmt->fetchColumn();
    
    $stmt = $db->query("SELECT COUNT(*) as total_staff FROM staff WHERE status = 'active'");
    $stats['total_staff'] = $stmt->fetchColumn();
    
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Get user's booking if logged in
$user_booking = null;
$has_booking = false;
if ($is_logged_in && $user_role === 'student') {
    try {
        $stmt = $db->prepare("
            SELECT ra.*, r.room_number, r.floor, r.type, r.rent
            FROM room_allocations ra
            JOIN rooms r ON ra.room_id = r.id
            WHERE ra.student_id = ? AND ra.status IN ('pending', 'confirmed')
            LIMIT 1
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $user_booking = $stmt->fetch(PDO::FETCH_ASSOC);
        $has_booking = !empty($user_booking);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
    }
}

// Get today's mess menu
$today_menu = [];
try {
    $day = strtolower(date('l'));
    $stmt = $db->prepare("SELECT * FROM mess_menu WHERE day = ? AND is_current = 1");
    $stmt->execute([$day]);
    $today_menu = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Get announcements
$announcements = [];
try {
    $stmt = $db->query("SELECT * FROM announcements WHERE is_active = 1 ORDER BY created_at DESC LIMIT 5");
    $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Get all rooms for rooms page
$all_rooms = [];
try {
    $stmt = $db->query("
        SELECT r.*, 
               COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0) as occupied_count,
               (r.capacity - COALESCE((SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active'), 0)) as available_spots
        FROM rooms r 
        ORDER BY r.rent ASC
    ");
    $all_rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Get facilities data
$facilities = [
    ['icon' => 'fa-wifi', 'title' => 'High-Speed WiFi', 'desc' => '100 Mbps fiber internet, unlimited', 'color' => '#6C63FF'],
    ['icon' => 'fa-shield-alt', 'title' => '24/7 Security', 'desc' => 'CCTV + biometric + guard', 'color' => '#EC4899'],
    ['icon' => 'fa-utensils', 'title' => 'Dining Hall', 'desc' => '3 healthy meals daily', 'color' => '#F59E0B'],
    ['icon' => 'fa-book-open', 'title' => 'Study Room', 'desc' => 'Air-conditioned, 24/7 access', 'color' => '#0EA5E9'],
    ['icon' => 'fa-tshirt', 'title' => 'Laundry', 'desc' => 'Washer & dryer, weekly', 'color' => '#22C55E'],
    ['icon' => 'fa-parking', 'title' => 'Parking', 'desc' => 'Secure two-wheeler parking', 'color' => '#A855F7'],
    ['icon' => 'fa-hot-tub', 'title' => 'Water Heater', 'desc' => '24/7 hot water supply', 'color' => '#EF4444'],
    ['icon' => 'fa-bolt', 'title' => 'Power Backup', 'desc' => 'Uninterrupted power supply', 'color' => '#F97316'],
];

// Gallery images
$gallery_items = [
    ['src' => 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=500&q=80', 'cat' => 'rooms', 'label' => 'Single Room'],
    ['src' => 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=500&q=80', 'cat' => 'rooms', 'label' => 'Double Room'],
    ['src' => 'https://images.unsplash.com/photo-1567767292278-a4f21aa2d36e?w=500&q=80', 'cat' => 'common', 'label' => 'Living Area'],
    ['src' => 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=500&q=80', 'cat' => 'facilities', 'label' => 'Dining Hall'],
    ['src' => 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=500&q=80', 'cat' => 'outdoor', 'label' => 'Garden View'],
    ['src' => 'https://images.unsplash.com/photo-1566665797739-1674de7a421a?w=500&q=80', 'cat' => 'rooms', 'label' => 'Triple Room'],
    ['src' => 'https://images.unsplash.com/photo-1571508601891-ca5e7a713859?w=500&q=80', 'cat' => 'rooms', 'label' => 'Premium Suite'],
    ['src' => 'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?w=500&q=80', 'cat' => 'rooms', 'label' => 'Garden Suite'],
];

// FAQ data
$faqs = [
    ['q' => 'What is the minimum stay duration?', 'a' => 'Our minimum stay is 1 month. We offer flexible plans for 1, 3, 6, and 12 months.'],
    ['q' => 'Is the hostel only for girls?', 'a' => 'Yes, Graceful Living is exclusively for women — students and working professionals.'],
    ['q' => 'Are meals included in the rent?', 'a' => 'Yes, 3 nutritious meals (breakfast, lunch, dinner) are included for all residents.'],
    ['q' => 'What documents are required for booking?', 'a' => 'Aadhaar card, passport-size photograph, and address proof. For students, college ID is also required.'],
    ['q' => 'Is there a curfew?', 'a' => 'We have a soft curfew of 11:00 PM for safety. Late entries can be pre-arranged with the warden.'],
    ['q' => 'What security measures are in place?', 'a' => 'We have CCTV cameras, biometric entry, 24/7 security guard, and a female warden on-premises.'],
];

// Include the main template
include 'templates/main.php';
?>