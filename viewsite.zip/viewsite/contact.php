<?php
// contact.php - Enhanced with Google Map integration
session_start();

$user_name = $_SESSION['user_name'] ?? '';
$user_email = $_SESSION['user_email'] ?? '';
$user_role = $_SESSION['user_role'] ?? 'guest';

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error_message = 'Please fill in all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = 'Please enter a valid email address.';
    } else {
        $success_message = 'Thank you for your message! We will get back to you soon.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --sidebar-width: 270px;
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Background Animation */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) { width: 600px; height: 600px; background: #8B5CF6; top: -200px; left: -200px; animation-delay: 0s; }
        .bg-orbs:nth-child(2) { width: 400px; height: 400px; background: #EC4899; bottom: -150px; right: -100px; animation-delay: -7s; }
        .bg-orbs:nth-child(3) { width: 300px; height: 300px; background: #3B82F6; top: 50%; left: 50%; transform: translate(-50%, -50%); animation-delay: -14s; }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: rgba(18, 18, 26, 0.92);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--glass-border);
            z-index: 1000;
            padding: 1.5rem 0;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 1.5rem;
            text-decoration: none;
        }

        .sidebar-brand .brand-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-1);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
            margin-right: 12px;
            box-shadow: 0 4px 16px rgba(139, 92, 246, 0.3);
            flex-shrink: 0;
        }

        .sidebar-brand .brand-text {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .sidebar-brand .brand-text span { color: #8B5CF6; }
        .sidebar-brand .brand-sub {
            display: block;
            font-size: 0.55rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 0 0.75rem;
        }

        .sidebar-nav::-webkit-scrollbar { width: 4px; }
        .sidebar-nav::-webkit-scrollbar-track { background: transparent; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }

        .nav-section-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--text-muted);
            padding: 0.75rem 1rem 0.5rem;
        }

        .nav-item { margin-bottom: 2px; }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
            font-weight: 500;
            position: relative;
        }

        .nav-link i {
            width: 1.6rem;
            font-size: 1rem;
            color: var(--text-muted);
            transition: all 0.3s ease;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(139, 92, 246, 0.12);
            color: var(--text-primary);
        }

        .nav-link:hover i, .nav-link.active i { color: #8B5CF6; }

        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 24px;
            background: var(--gradient-1);
            border-radius: 0 4px 4px 0;
        }

        .sidebar-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .sidebar-footer .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.6rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .sidebar-footer .user-card:hover { background: rgba(255, 255, 255, 0.06); }

        .sidebar-footer .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            color: white;
            flex-shrink: 0;
        }

        .sidebar-footer .user-info { flex: 1; min-width: 0; }

        .sidebar-footer .user-info .name {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .sidebar-footer .user-info .role {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: capitalize;
        }

        #content-wrapper {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem 2rem;
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        /* Topbar */
        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1.5rem;
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .btn-toggle-sidebar {
            display: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-toggle-sidebar:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .page-title h1 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .page-title p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .topbar-user:hover { background: rgba(255, 255, 255, 0.08); }

        .topbar-user .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .topbar-user .user-name {
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        .topbar-user .user-role {
            font-size: 0.65rem;
            color: var(--text-muted);
        }

        /* Contact Grid */
        .contact-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }

        .contact-info-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 2rem;
        }

        .contact-info-card .card-title {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
        }

        .contact-info-card .card-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .contact-item {
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            padding: 0.75rem 0;
            border-bottom: 1px solid var(--glass-border);
        }

        .contact-item:last-child {
            border-bottom: none;
        }

        .contact-item .contact-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: rgba(139, 92, 246, 0.12);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #8B5CF6;
            font-size: 1rem;
            flex-shrink: 0;
        }

        .contact-item .contact-content .contact-label {
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-muted);
        }

        .contact-item .contact-content .contact-value {
            font-size: 0.9rem;
            color: var(--text-primary);
        }

        .contact-item .contact-content .contact-value a {
            color: var(--text-primary);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .contact-item .contact-content .contact-value a:hover {
            color: #8B5CF6;
        }

        .social-links {
            display: flex;
            gap: 0.75rem;
            margin-top: 1rem;
        }

        .social-link {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .social-link:hover {
            background: rgba(139, 92, 246, 0.12);
            border-color: #8B5CF6;
            color: #8B5CF6;
            transform: translateY(-3px);
        }

        .map-container {
            border-radius: 16px;
            overflow: hidden;
            margin-top: 1.5rem;
            border: 1px solid var(--glass-border);
        }

        .map-container iframe {
            width: 100%;
            height: 250px;
            border: none;
        }

        /* Contact Form */
        .form-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 2rem;
        }

        .form-card .card-title {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
        }

        .form-card .card-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .form-group {
            margin-bottom: 1.25rem;
        }

        .form-group label {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 0.3rem;
            display: block;
        }

        .form-group label .required {
            color: #EC4899;
        }

        .form-control,
        .form-select {
            background: rgba(255, 255, 255, 0.04) !important;
            border: 1px solid var(--glass-border) !important;
            border-radius: 12px !important;
            padding: 0.7rem 1rem !important;
            color: var(--text-primary) !important;
            font-size: 0.85rem !important;
            transition: all 0.3s ease;
        }

        .form-control::placeholder {
            color: var(--text-muted);
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #8B5CF6 !important;
            box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15) !important;
            background: rgba(255, 255, 255, 0.06) !important;
        }

        .form-control option {
            background: var(--bg-secondary);
            color: var(--text-primary);
        }

        textarea.form-control {
            resize: vertical;
            min-height: 120px;
        }

        .btn-submit {
            width: 100%;
            padding: 0.8rem;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.95rem;
            color: white;
            background: var(--gradient-1);
            transition: all 0.3s ease;
        }

        .btn-submit:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
        }

        .alert {
            border-radius: 12px;
            border: none;
            padding: 0.8rem 1.2rem;
            font-size: 0.85rem;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.12);
            color: #34D399;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.12);
            color: #F87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .footer {
            text-align: center;
            padding: 1.5rem 0 0.5rem;
            border-top: 1px solid var(--glass-border);
            margin-top: 2rem;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        .footer .footer-links {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            margin-top: 0.5rem;
            flex-wrap: wrap;
        }

        .footer .footer-links a {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.7rem;
            transition: color 0.3s ease;
        }

        .footer .footer-links a:hover {
            color: var(--text-secondary);
        }

        @media (max-width: 992px) {
            .contact-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            #content-wrapper {
                margin-left: 0;
                padding: 1rem;
            }

            .btn-toggle-sidebar {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .topbar {
                padding: 0.5rem 1rem;
                border-radius: 16px;
            }

            .page-title h1 { font-size: 1rem; }
            .page-title p { font-size: 0.7rem; }

            .topbar-user .user-name,
            .topbar-user .user-role { display: none; }

            .contact-info-card,
            .form-card {
                padding: 1.5rem;
            }

            .contact-item {
                flex-direction: column;
                gap: 0.3rem;
            }

            .contact-item .contact-icon {
                width: 32px;
                height: 32px;
                font-size: 0.8rem;
            }
        }

        @media (max-width: 480px) {
            .contact-info-card,
            .form-card {
                padding: 1rem;
            }
        }

        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: var(--bg-primary); }
        ::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(139, 92, 246, 0.5); }

        .dropdown-menu {
            background: var(--bg-secondary) !important;
            border: 1px solid var(--glass-border) !important;
        }

        .dropdown-item {
            color: var(--text-secondary) !important;
        }

        .dropdown-item:hover {
            background: rgba(139, 92, 246, 0.1) !important;
            color: var(--text-primary) !important;
        }

        .dropdown-divider {
            border-color: var(--glass-border) !important;
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <a href="indexview.php" class="sidebar-brand">
            <div class="brand-icon"><i class="fas fa-home"></i></div>
            <div>
                <div class="brand-text">Graceful<span>Living</span></div>
                <span class="brand-sub">Management System</span>
            </div>
        </a>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Main</div>
            <div class="nav-item">
                <a href="indexview.php" class="nav-link">
                    <i class="fas fa-th-large"></i> Dashboard
                </a>
            </div>

            <div class="nav-section-label">Management</div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i> My Profile
                </a>
            </div>
            <div class="nav-item">
                <a href="viewrooms.php" class="nav-link">
                    <i class="fas fa-bed"></i> Rooms
                </a>
            </div>
            <div class="nav-item">
                <a href="gallery.php" class="nav-link">
                    <i class="fas fa-images"></i> Gallery
                </a>
            </div>
            <div class="nav-item">
                <a href="payments.php" class="nav-link">
                    <i class="fas fa-credit-card"></i> Payments
                </a>
            </div>
            <div class="nav-item">
                <a href="contact.php" class="nav-link active">
                    <i class="fas fa-envelope"></i> Contact
                </a>
            </div>

            <div class="nav-section-label">Account</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </nav>

        <div class="sidebar-footer">
            <a href="profile.php" class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($user_name); ?></div>
                    <div class="role"><?php echo htmlspecialchars($user_role); ?></div>
                </div>
                <i class="fas fa-ellipsis-v" style="color: var(--text-muted); font-size: 0.7rem;"></i>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div id="content-wrapper">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left">
                <button class="btn-toggle-sidebar" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Contact Us</h1>
                    <p>Get in touch with us</p>
                </div>
            </div>
            <div class="topbar-right">
                <a href="profile.php" class="topbar-user">
                    <div class="avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                    <div>
                        <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
                        <div class="user-role"><?php echo htmlspecialchars($user_role); ?></div>
                    </div>
                </a>
            </div>
        </header>

        <!-- Contact Grid -->
        <div class="contact-grid">
            <!-- Contact Information -->
            <div>
                <div class="contact-info-card">
                    <div class="card-title">
                        <i class="fas fa-info-circle"></i> Get in Touch
                    </div>

                    <div class="contact-item">
                        <div class="contact-icon"><i class="fas fa-map-marker-alt"></i></div>
                        <div class="contact-content">
                            <div class="contact-label">Address</div>
                            <div class="contact-value">123 Hostel Road, City, State - 123456</div>
                        </div>
                    </div>

                    <div class="contact-item">
                        <div class="contact-icon"><i class="fas fa-phone"></i></div>
                        <div class="contact-content">
                            <div class="contact-label">Phone</div>
                            <div class="contact-value">
                                <a href="tel:+919876543210">+91 98765 43210</a>
                            </div>
                        </div>
                    </div>

                    <div class="contact-item">
                        <div class="contact-icon"><i class="fas fa-envelope"></i></div>
                        <div class="contact-content">
                            <div class="contact-label">Email</div>
                            <div class="contact-value">
                                <a href="mailto:info@girlshostel.com">info@girlshostel.com</a>
                            </div>
                        </div>
                    </div>

                    <div class="contact-item">
                        <div class="contact-icon"><i class="fas fa-clock"></i></div>
                        <div class="contact-content">
                            <div class="contact-label">Office Hours</div>
                            <div class="contact-value">Mon - Sat: 9:00 AM - 8:00 PM</div>
                        </div>
                    </div>

                    <div style="margin-top: 1.5rem;">
                        <div style="font-size:0.65rem; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; color:var(--text-muted); margin-bottom:0.5rem;">Follow Us</div>
                        <div class="social-links">
                            <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>

                    <div class="map-container">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2691.5424618871084!2d78.4500853101255!3d17.439799228976366!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb90c7b1c19745%3A0x2b372d7a718acfd4!2sflat%20no%2020%2C%20a%2F5%2C%207-1-11%2C%20Shivbagh%20Colony%20Road%2C%20ShivBagh%2C%20Balkampet%2C%20Hyderabad%2C%20Telangana%20500016!5e0!3m2!1sen!2sin!4v1782639896808!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div>
                <div class="form-card">
                    <div class="card-title">
                        <i class="fas fa-paper-plane"></i> Send a Message
                    </div>

                    <?php if ($success_message): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo $success_message; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($error_message): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="form-group">
                            <label>Your Name <span class="required">*</span></label>
                            <input type="text" class="form-control" name="name" placeholder="Enter your full name" 
                                   value="<?php echo htmlspecialchars($user_name ?? ''); ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Email Address <span class="required">*</span></label>
                            <input type="email" class="form-control" name="email" placeholder="Enter your email address" 
                                   value="<?php echo htmlspecialchars($user_email ?? ''); ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Subject <span class="required">*</span></label>
                            <select class="form-select" name="subject" required>
                                <option value="">Select a subject...</option>
                                <option value="general">General Inquiry</option>
                                <option value="booking">Room Booking</option>
                                <option value="visit">Book a Visit</option>
                                <option value="complaint">Complaint</option>
                                <option value="suggestion">Suggestion</option>
                                <option value="other">Other</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Message <span class="required">*</span></label>
                            <textarea class="form-control" name="message" placeholder="Write your message here..." required></textarea>
                        </div>

                        <button type="submit" class="btn-submit">
                            <i class="fas fa-paper-plane me-2"></i>Send Message
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Graceful Living — All rights reserved.</p>
            <div class="footer-links">
                <a href="about.php">About</a>
                <a href="contact.php">Contact</a>
                <a href="terms.php">Terms</a>
                <a href="privacy.php">Privacy</a>
            </div>
        </footer>
    </div>

    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Ready to Leave?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-secondary" style="color: var(--text-secondary) !important;">
                    Select "Logout" below if you are ready to end your current session.
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Sidebar Toggle
        $('#sidebarToggle').on('click', function() {
            $('#sidebar').toggleClass('open');
        });

        $(document).on('click', function(e) {
            if ($(window).width() <= 768) {
                if (!$(e.target).closest('#sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
                    $('#sidebar').removeClass('open');
                }
            }
        });
    </script>
</body>
</html>