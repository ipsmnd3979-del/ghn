<?php
// process_login.php - Login handler
session_start();
require_once 'config/database.php';

$error = '';
$redirect = 'index.php?page=home';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);
    
    try {
        $database = new Database();
        $db = $database->getConnection();
        
        $stmt = $db->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
        $stmt->execute([':email' => strtolower($email)]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            if ($user['status'] !== 'active') {
                $_SESSION['login_error'] = 'Your account is not active. Please contact support.';
                header("Location: index.php?page=login");
                exit();
            }
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['username'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            
            // Update last login
            $updateStmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
            $updateStmt->execute([':id' => $user['id']]);
            
            // Redirect based on role
            if ($user['role'] === 'admin') {
                $redirect = 'index.php?page=admin';
            } elseif ($user['role'] === 'staff') {
                $redirect = 'index.php?page=staff';
            } else {
                $redirect = 'index.php?page=student';
            }
            
            header("Location: " . $redirect);
            exit();
        } else {
            $_SESSION['login_error'] = 'Invalid email or password';
            header("Location: index.php?page=login");
            exit();
        }
    } catch (PDOException $e) {
        error_log('Login error: ' . $e->getMessage());
        $_SESSION['login_error'] = 'An error occurred. Please try again later.';
        header("Location: index.php?page=login");
        exit();
    }
}

header("Location: index.php?page=login");
exit();
?>