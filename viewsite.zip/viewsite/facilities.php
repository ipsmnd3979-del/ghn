<?php
// facilities.php - Hostel Facilities Showcase
session_start();
include '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'student';
$user_id = $_SESSION['user_id'] ?? 0;

$database = new Database();
$db = $database->getConnection();

// Get user's student details
$student_details = [];
try {
    $stmt = $db->prepare("SELECT * FROM students WHERE user_id = ? OR id = ?");
    $stmt->execute([$user_id, $user_id]);
    $student_details = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Sample facilities data - In production, fetch from database
$facilities = [
    [
        'id' => 1,
        'name' => '24/7 Security',
        'icon' => 'fa-shield-alt',
        'description' => 'Round-the-clock security with CCTV surveillance, security guards, and biometric access control for your safety.',
        'image' => 'https://images.unsplash.com/photo-1558002038-1055907df827',
        'features' => ['CCTV Cameras', 'Security Guards', 'Biometric Access', 'Emergency Alarms']
    ],
    [
        'id' => 2,
        'name' => 'High-Speed WiFi',
        'icon' => 'fa-wifi',
        'description' => 'Stay connected with our high-speed internet connection throughout the hostel. Perfect for online classes and entertainment.',
        'image' => 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8',
        'features' => ['100 Mbps Speed', 'WiFi 6', '24/7 Connectivity', 'Dedicated Bandwidth']
    ],
    [
        'id' => 3,
        'name' => 'Healthy Meals',
        'icon' => 'fa-utensils',
        'description' => 'Nutritious and delicious meals prepared fresh daily. Our menu includes vegetarian and non-vegetarian options.',
        'image' => 'https://images.unsplash.com/photo-1547592180-85f173990554',
        'features' => ['Fresh Ingredients', 'Variety Menu', 'Dietary Options', 'Clean Kitchen']
    ],
    [
        'id' => 4,
        'name' => 'Study Room',
        'icon' => 'fa-book-open',
        'description' => 'Quiet and well-lit study rooms with comfortable seating, perfect for focused study sessions and group discussions.',
        'image' => 'https://images.unsplash.com/photo-1509062522246-3755977927d7',
        'features' => ['Silent Zone', 'Study Tables', 'Good Lighting', 'Reference Books']
    ],
    [
        'id' => 5,
        'name' => 'Fitness Center',
        'icon' => 'fa-dumbbell',
        'description' => 'Stay fit and healthy with our well-equipped fitness center featuring modern equipment and yoga space.',
        'image' => 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48',
        'features' => ['Cardio Equipment', 'Strength Training', 'Yoga Space', 'Trainer Available']
    ],
    [
        'id' => 6,
        'name' => 'Common Room',
        'icon' => 'fa-users',
        'description' => 'A vibrant common room with TV, games, and comfortable seating for socializing and relaxing with friends.',
        'image' => 'https://images.unsplash.com/photo-1558618666-fcd25c85f3f0',
        'features' => ['TV & Entertainment', 'Board Games', 'Comfortable Seating', 'Indoor Games']
    ],
    [
        'id' => 7,
        'name' => 'Laundry Service',
        'icon' => 'fa-tshirt',
        'description' => 'Convenient laundry facilities with washing machines, dryers, and ironing stations for your daily needs.',
        'image' => 'https://images.unsplash.com/photo-1545173168-9f1947eebb7f',
        'features' => ['Washing Machines', 'Dryers', 'Ironing Station', 'Detergent Provided']
    ],
    [
        'id' => 8,
        'name' => 'Garden & Terrace',
        'icon' => 'fa-tree',
        'description' => 'Beautiful garden and rooftop terrace with seating areas, perfect for relaxation and enjoying the view.',
        'image' => 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae',
        'features' => ['Lush Garden', 'Rooftop View', 'Seating Areas', 'BBQ Area']
    ],
    [
        'id' => 9,
        'name' => 'Power Backup',
        'icon' => 'fa-bolt',
        'description' => 'Uninterrupted power supply with generator backup, ensuring you never face power outages.',
        'image' => 'https://images.unsplash.com/photo-1581092160607-ee22621dd758',
        'features' => ['Generator Backup', 'UPS Systems', '24/7 Power', 'Emergency Lighting']
    ],
    [
        'id' => 10,
        'name' => 'Medical Assistance',
        'icon' => 'fa-heartbeat',
        'description' => 'Quick access to medical assistance with first-aid facilities and tie-ups with nearby hospitals.',
        'image' => 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae',
        'features' => ['First-Aid Kit', 'Tie-up Hospitals', 'Emergency Services', 'Regular Health Camps']
    ],
    [
        'id' => 11,
        'name' => 'Transportation',
        'icon' => 'fa-bus',
        'description' => 'Convenient transportation facilities with bus services to nearby colleges and city center.',
        'image' => 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957',
        'features' => ['College Shuttle', 'City Transport', 'Bicycle Parking', 'Auto Services']
    ],
    [
        'id' => 12,
        'name' => 'Dining Area',
        'icon' => 'fa-utensil-spoon',
        'description' => 'Spacious and hygienic dining hall with a warm ambiance, serving delicious meals three times a day.',
        'image' => 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4',
        'features' => ['Spacious Hall', 'Clean Environment', 'Family Dining', 'Special Events']
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facilities - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --gradient-2: linear-gradient(135deg, #3B82F6, #8B5CF6);
            --gradient-3: linear-gradient(135deg, #10B981, #34D399);
            --gradient-4: linear-gradient(135deg, #F59E0B, #FBBF24);
            --sidebar-width: 270px;
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) { width: 600px; height: 600px; background: #8B5CF6; top: -200px; left: -200px; animation-delay: 0s; }
        .bg-orbs:nth-child(2) { width: 400px; height: 400px; background: #EC4899; bottom: -150px; right: -100px; animation-delay: -7s; }
        .bg-orbs:nth-child(3) { width: 300px; height: 300px; background: #3B82F6; top: 50%; left: 50%; transform: translate(-50%, -50%); animation-delay: -14s; }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: rgba(18, 18, 26, 0.92);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--glass-border);
            z-index: 1000;
            padding: 1.5rem 0;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 1.5rem;
            text-decoration: none;
        }

        .sidebar-brand .brand-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-1);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
            margin-right: 12px;
            box-shadow: 0 4px 16px rgba(139, 92, 246, 0.3);
            flex-shrink: 0;
        }

        .sidebar-brand .brand-text {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .sidebar-brand .brand-text span { color: #8B5CF6; }
        .sidebar-brand .brand-sub {
            display: block;
            font-size: 0.55rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 0 0.75rem;
        }

        .sidebar-nav::-webkit-scrollbar { width: 4px; }
        .sidebar-nav::-webkit-scrollbar-track { background: transparent; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }

        .nav-section-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--text-muted);
            padding: 0.75rem 1rem 0.5rem;
        }

        .nav-item { margin-bottom: 2px; }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
            font-weight: 500;
            position: relative;
        }

        .nav-link i {
            width: 1.6rem;
            font-size: 1rem;
            color: var(--text-muted);
            transition: all 0.3s ease;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(139, 92, 246, 0.12);
            color: var(--text-primary);
        }

        .nav-link:hover i, .nav-link.active i { color: #8B5CF6; }

        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 24px;
            background: var(--gradient-1);
            border-radius: 0 4px 4px 0;
        }

        .sidebar-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .sidebar-footer .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.6rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .sidebar-footer .user-card:hover { background: rgba(255, 255, 255, 0.06); }

        .sidebar-footer .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            color: white;
            flex-shrink: 0;
        }

        .sidebar-footer .user-info { flex: 1; min-width: 0; }

        .sidebar-footer .user-info .name {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .sidebar-footer .user-info .role {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: capitalize;
        }

        #content-wrapper {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem 2rem;
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        /* Topbar */
        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1.5rem;
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .btn-toggle-sidebar {
            display: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-toggle-sidebar:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .page-title h1 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .page-title p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .topbar-user:hover { background: rgba(255, 255, 255, 0.08); }

        .topbar-user .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .topbar-user .user-name {
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        .topbar-user .user-role {
            font-size: 0.65rem;
            color: var(--text-muted);
        }

        /* Hero Section */
        .facilities-hero {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 3rem 2rem;
            text-align: center;
            margin-bottom: 2rem;
        }

        .facilities-hero h2 {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }

        .facilities-hero h2 .highlight {
            background: var(--gradient-1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .facilities-hero p {
            color: var(--text-secondary);
            font-size: 1rem;
            max-width: 600px;
            margin: 0 auto;
        }

        /* Facilities Grid */
        .facilities-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 1.5rem;
        }

        .facility-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.4s ease;
            cursor: pointer;
        }

        .facility-card:hover {
            transform: translateY(-6px);
            border-color: rgba(139, 92, 246, 0.2);
            box-shadow: var(--shadow-glow);
        }

        .facility-card .facility-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: all 0.4s ease;
        }

        .facility-card:hover .facility-image {
            transform: scale(1.02);
        }

        .facility-card .facility-content {
            padding: 1.5rem;
        }

        .facility-card .facility-icon {
            width: 52px;
            height: 52px;
            border-radius: 14px;
            background: rgba(139, 92, 246, 0.12);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: #8B5CF6;
            margin-bottom: 0.75rem;
        }

        .facility-card .facility-name {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .facility-card .facility-desc {
            font-size: 0.85rem;
            color: var(--text-secondary);
            line-height: 1.6;
            margin-bottom: 1rem;
        }

        .facility-card .feature-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }

        .facility-card .feature-tag {
            font-size: 0.6rem;
            font-weight: 500;
            padding: 0.15rem 0.7rem;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            border-radius: 50px;
            color: var(--text-secondary);
        }

        /* Category Filter */
        .category-filter {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
            margin-bottom: 2rem;
            justify-content: center;
        }

        .filter-btn {
            padding: 0.4rem 1.2rem;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 500;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .filter-btn:hover, .filter-btn.active {
            background: rgba(139, 92, 246, 0.12);
            border-color: #8B5CF6;
            color: var(--text-primary);
        }

        .filter-btn.active {
            background: var(--gradient-1);
            border-color: transparent;
            color: white;
        }

        .footer {
            text-align: center;
            padding: 1.5rem 0 0.5rem;
            border-top: 1px solid var(--glass-border);
            margin-top: 2rem;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        .footer .footer-links {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            margin-top: 0.5rem;
            flex-wrap: wrap;
        }

        .footer .footer-links a {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.7rem;
            transition: color 0.3s ease;
        }

        .footer .footer-links a:hover {
            color: var(--text-secondary);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            #content-wrapper {
                margin-left: 0;
                padding: 1rem;
            }

            .btn-toggle-sidebar {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .topbar {
                padding: 0.5rem 1rem;
                border-radius: 16px;
            }

            .page-title h1 { font-size: 1rem; }
            .page-title p { font-size: 0.7rem; }

            .topbar-user .user-name,
            .topbar-user .user-role { display: none; }

            .facilities-hero {
                padding: 2rem 1rem;
            }

            .facilities-hero h2 {
                font-size: 1.5rem;
            }

            .facilities-grid {
                grid-template-columns: 1fr;
            }

            .facility-card .facility-image {
                height: 160px;
            }
        }

        @media (max-width: 480px) {
            .facilities-grid {
                grid-template-columns: 1fr;
            }

            .category-filter .filter-btn {
                font-size: 0.7rem;
                padding: 0.3rem 0.8rem;
            }
        }

        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: var(--bg-primary); }
        ::-webkit-scrollbar-thumb { background: rgba(139, 92, 246, 0.3); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(139, 92, 246, 0.5); }

        .dropdown-menu {
            background: var(--bg-secondary) !important;
            border: 1px solid var(--glass-border) !important;
        }

        .dropdown-item {
            color: var(--text-secondary) !important;
        }

        .dropdown-item:hover {
            background: rgba(139, 92, 246, 0.1) !important;
            color: var(--text-primary) !important;
        }

        .dropdown-divider {
            border-color: var(--glass-border) !important;
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <a href="indexview.php" class="sidebar-brand">
            <div class="brand-icon"><i class="fas fa-home"></i></div>
            <div>
                <div class="brand-text">Graceful<span>Living</span></div>
                <span class="brand-sub">Management System</span>
            </div>
        </a>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Main</div>
            <div class="nav-item">
                <a href="indexview.php" class="nav-link">
                    <i class="fas fa-th-large"></i> Dashboard
                </a>
            </div>

            <div class="nav-section-label">Management</div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i> My Profile
                </a>
            </div>
            <div class="nav-item">
                <a href="viewrooms.php" class="nav-link">
                    <i class="fas fa-bed"></i> Rooms
                </a>
            </div>
            <div class="nav-item">
                <a href="facilities.php" class="nav-link active">
                    <i class="fas fa-concierge-bell"></i> Facilities
                </a>
            </div>
            <div class="nav-item">
                <a href="gallery.php" class="nav-link">
                    <i class="fas fa-images"></i> Gallery
                </a>
            </div>
            <div class="nav-item">
                <a href="payments.php" class="nav-link">
                    <i class="fas fa-credit-card"></i> Payments
                </a>
            </div>

            <div class="nav-section-label">Account</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </nav>

        <div class="sidebar-footer">
            <a href="profile.php" class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($user_name); ?></div>
                    <div class="role"><?php echo htmlspecialchars($user_role); ?></div>
                </div>
                <i class="fas fa-ellipsis-v" style="color: var(--text-muted); font-size: 0.7rem;"></i>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div id="content-wrapper">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left">
                <button class="btn-toggle-sidebar" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Facilities</h1>
                    <p>Explore our premium amenities and services</p>
                </div>
            </div>
            <div class="topbar-right">
                <a href="profile.php" class="topbar-user">
                    <div class="avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                    <div>
                        <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
                        <div class="user-role"><?php echo htmlspecialchars($user_role); ?></div>
                    </div>
                </a>
            </div>
        </header>

        <!-- Hero Section -->
        <div class="facilities-hero">
            <h2>Premium <span class="highlight">Facilities</span></h2>
            <p>Experience the best amenities designed for your comfort, safety, and convenience during your stay with us.</p>
        </div>

        <!-- Category Filter -->
        <div class="category-filter">
            <button class="filter-btn active" data-filter="all">All</button>
            <button class="filter-btn" data-filter="security">Security</button>
            <button class="filter-btn" data-filter="amenities">Amenities</button>
            <button class="filter-btn" data-filter="food">Food & Dining</button>
            <button class="filter-btn" data-filter="health">Health & Fitness</button>
            <button class="filter-btn" data-filter="utility">Utility</button>
        </div>

        <!-- Facilities Grid -->
        <div class="facilities-grid" id="facilitiesGrid">
            <?php foreach ($facilities as $facility): ?>
                <div class="facility-card" data-category="all">
                    <img class="facility-image" src="<?php echo $facility['image']; ?>" alt="<?php echo htmlspecialchars($facility['name']); ?>" loading="lazy">
                    <div class="facility-content">
                        <div class="facility-icon">
                            <i class="fas <?php echo $facility['icon']; ?>"></i>
                        </div>
                        <h4 class="facility-name"><?php echo htmlspecialchars($facility['name']); ?></h4>
                        <p class="facility-desc"><?php echo htmlspecialchars($facility['description']); ?></p>
                        <div class="feature-tags">
                            <?php foreach ($facility['features'] as $feature): ?>
                                <span class="feature-tag"><?php echo htmlspecialchars($feature); ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Footer -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Graceful Living — All rights reserved.</p>
            <div class="footer-links">
                <a href="about.php">About</a>
                <a href="contact.php">Contact</a>
                <a href="terms.php">Terms</a>
                <a href="privacy.php">Privacy</a>
            </div>
        </footer>
    </div>

    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Ready to Leave?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-secondary" style="color: var(--text-secondary) !important;">
                    Select "Logout" below if you are ready to end your current session.
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Sidebar Toggle
        $('#sidebarToggle').on('click', function() {
            $('#sidebar').toggleClass('open');
        });

        $(document).on('click', function(e) {
            if ($(window).width() <= 768) {
                if (!$(e.target).closest('#sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
                    $('#sidebar').removeClass('open');
                }
            }
        });

        // Category Filter
        const filterBtns = document.querySelectorAll('.filter-btn');
        const facilityCards = document.querySelectorAll('.facility-card');

        // Map facility names to categories
        const facilityCategories = {
            '24/7 Security': 'security',
            'High-Speed WiFi': 'amenities',
            'Healthy Meals': 'food',
            'Study Room': 'amenities',
            'Fitness Center': 'health',
            'Common Room': 'amenities',
            'Laundry Service': 'utility',
            'Garden & Terrace': 'amenities',
            'Power Backup': 'utility',
            'Medical Assistance': 'health',
            'Transportation': 'utility',
            'Dining Area': 'food'
        };

        // Set category attribute for each card
        facilityCards.forEach(card => {
            const name = card.querySelector('.facility-name')?.textContent.trim() || '';
            const category = facilityCategories[name] || 'amenities';
            card.dataset.category = category;
        });

        filterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                filterBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');

                const filter = this.dataset.filter;

                facilityCards.forEach(card => {
                    if (filter === 'all' || card.dataset.category === filter) {
                        card.style.display = 'block';
                        setTimeout(() => {
                            card.style.opacity = '1';
                            card.style.transform = 'translateY(0)';
                        }, 50);
                    } else {
                        card.style.opacity = '0';
                        card.style.transform = 'translateY(20px)';
                        setTimeout(() => {
                            card.style.display = 'none';
                        }, 300);
                    }
                });
            });
        });
    </script>
</body>
</html>