-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2025 at 08:30 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `irls_hostel_management_management`
--
DROP DATABASE IF EXISTS `irls_hostel_management_management`;
CREATE DATABASE IF NOT EXISTS `irls_hostel_management_management`;
USE `irls_hostel_management_management`;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','manager','staff','student') DEFAULT 'staff',
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `last_login` timestamp NULL DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `status`, `last_login`, `profile_image`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@hostel.com', '$2y$10$Bwx3jiN1tzVaALkfJyYsHuneYO8ivQzzKUEu/ab3ffR/yTykv.YRC', 'admin', 'active', '2025-11-25 18:30:00', 'admin.jpg', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(2, 'staff', 'staff@hostel.com', '$2y$10$oV9zavYEg39Ah6bEWt/Y1eKghruqJ0bQaro0ByQJ1rqZjUP4Jbd76', 'staff', 'active', '2025-11-25 16:45:00', 'staff.jpg', '2025-11-01 00:00:00', '2025-11-25 16:45:00'),
(3, 'manager', 'manager@hostel.com', '$2y$10$NFFuiK3Xdbt0SugIIz3EXuqTKLF0NOMgDL.DhKkK/dw0mDgCUDKSe', 'manager', 'active', '2025-11-25 17:15:00', 'manager.jpg', '2025-11-01 00:00:00', '2025-11-25 17:15:00'),
(4, 'student1', 'priya.sharma@example.com', '$2y$10$2wjZ9R7q1Xv3LpK8mNtQ5eYb6Vc4Dx7Fg8Hj9K0L1M2N3O4P5Q6R', 'student', 'active', '2025-11-25 15:20:00', 'student1.jpg', '2025-11-01 00:00:00', '2025-11-25 15:20:00'),
(5, 'student2', 'anjali.patel@example.com', '$2y$10$3xkY8S7r2Wv4Mq9NtR6eYb7Vc5Dx8Fg9Hj0K1L2M3N4O5P6Q7R8S', 'student', 'active', '2025-11-25 14:30:00', 'student2.jpg', '2025-11-01 00:00:00', '2025-11-25 14:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `room_number` varchar(10) NOT NULL,
  `floor` int(11) NOT NULL,
  `capacity` int(11) DEFAULT 4,
  `occupied` int(11) DEFAULT 0,
  `type` enum('single','double','triple','quad','dormitory') DEFAULT 'quad',
  `rent` decimal(10,2) NOT NULL,
  `facilities` text DEFAULT NULL COMMENT 'JSON array of facilities',
  `status` enum('available','occupied','maintenance','cleaning') DEFAULT 'available',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_number`, `floor`, `capacity`, `occupied`, `type`, `rent`, `facilities`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(1, '101', 1, 2, 2, 'double', 9500.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\", \"Study Table\"]', 'occupied', 'Corner room with view', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(2, '102', 1, 2, 1, 'double', 9500.00, '[\"Attached Bathroom\", \"WiFi\", \"Cupboard\"]', 'occupied', 'Near staircase', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(3, '103', 1, 3, 3, 'triple', 8500.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\"]', 'occupied', 'Recently renovated', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(4, '104', 1, 4, 4, 'quad', 7500.00, '[\"WiFi\", \"Common Bathroom\"]', 'occupied', 'Economy sharing', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(5, '105', 1, 1, 1, 'single', 11000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\", \"Balcony\"]', 'occupied', 'Premium single room', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(6, '106', 1, 2, 0, 'double', 9500.00, '[\"Attached Bathroom\", \"WiFi\"]', 'available', 'Available for immediate allocation', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(7, '107', 1, 3, 0, 'triple', 8500.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\"]', 'available', 'Spacious room', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(8, '108', 1, 1, 0, 'single', 11000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\"]', 'maintenance', 'Under maintenance until 30th Nov', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(9, '201', 2, 2, 2, 'double', 9500.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\", \"Balcony\"]', 'occupied', 'Second floor corner', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(10, '202', 2, 3, 3, 'triple', 8500.00, '[\"Attached Bathroom\", \"WiFi\"]', 'occupied', 'Quiet location', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(11, '203', 2, 4, 2, 'quad', 7500.00, '[\"WiFi\", \"Common Bathroom\"]', 'occupied', 'Two beds available', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(12, '204', 2, 1, 1, 'single', 11000.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\", \"Study Table\"]', 'occupied', 'Luxury room', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(13, '205', 2, 2, 0, 'double', 9500.00, '[\"Attached Bathroom\", \"WiFi\"]', 'available', 'Newly painted', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(14, '301', 3, 3, 3, 'triple', 8500.00, '[\"AC\", \"Attached Bathroom\", \"WiFi\"]', 'occupied', 'Top floor view', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(15, '302', 3, 4, 4, 'quad', 7500.00, '[\"WiFi\", \"Common Bathroom\"]', 'occupied', 'Full capacity', '2025-11-01 00:00:00', '2025-11-25 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `student_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `guardian_name` varchar(100) DEFAULT NULL,
  `guardian_phone` varchar(15) DEFAULT NULL,
  `guardian_relation` varchar(50) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `admission_date` date DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive','graduated','left') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `student_id`, `name`, `email`, `phone`, `address`, `guardian_name`, `guardian_phone`, `guardian_relation`, `room_id`, `admission_date`, `image_path`, `status`, `created_at`, `updated_at`) VALUES
(1, 4, 'STU2025001', 'Priya Sharma', 'priya.sharma@example.com', '9876543210', '123 Main Street, Mumbai', 'Rajesh Sharma', '9876543211', 'Father', 1, '2025-08-01', 'stu001.jpg', 'active', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(2, 5, 'STU2025002', 'Anjali Patel', 'anjali.patel@example.com', '9876543212', '456 Park Avenue, Delhi', 'Sunil Patel', '9876543213', 'Father', 1, '2025-08-01', 'stu002.jpg', 'active', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(3, NULL, 'STU2025003', 'Sneha Reddy', 'sneha.reddy@example.com', '9876543214', '789 MG Road, Bangalore', 'Kumar Reddy', '9876543215', 'Father', 3, '2025-08-01', 'stu003.jpg', 'active', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(4, NULL, 'STU2025004', 'Meera Iyer', 'meera.iyer@example.com', '9876543216', '321 Temple Street, Chennai', 'Ramesh Iyer', '9876543217', 'Father', 3, '2025-08-01', 'stu004.jpg', 'active', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(5, NULL, 'STU2025005', 'Kavita Singh', 'kavita.singh@example.com', '9876543218', '654 Rose Lane, Kolkata', 'Amit Singh', '9876543219', 'Father', 3, '2025-08-01', 'stu005.jpg', 'active', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(6, NULL, 'STU2025006', 'Divya Kumar', 'divya.kumar@example.com', '9876543220', '987 Lake View, Hyderabad', 'Vikram Kumar', '9876543221', 'Father', 4, '2025-08-01', 'stu006.jpg', 'active', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(7, NULL, 'STU2025007', 'Pooja Verma', 'pooja.verma@example.com', '9876543222', '147 Hill Road, Pune', 'Sanjay Verma', '9876543223', 'Father', 4, '2025-08-01', 'stu007.jpg', 'active', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(8, NULL, 'STU2025008', 'Neha Gupta', 'neha.gupta@example.com', '9876543224', '258 Market Street, Ahmedabad', 'Rahul Gupta', '9876543225', 'Father', 4, '2025-08-01', 'stu008.jpg', 'active', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(9, NULL, 'STU2025009', 'Ritu Joshi', 'ritu.joshi@example.com', '9876543226', '369 Garden Avenue, Jaipur', 'Anil Joshi', '9876543227', 'Father', 4, '2025-08-01', 'stu009.jpg', 'active', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(10, NULL, 'STU2025010', 'Shweta Malhotra', 'shweta.malhotra@example.com', '9876543228', '741 Palace Road, Udaipur', 'Vijay Malhotra', '9876543229', 'Father', 5, '2025-08-01', 'stu010.jpg', 'active', '2025-11-01 00:00:00', '2025-11-25 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `staff_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `position` enum('warden','caretaker','cleaner','cook','security','electrician','plumber','admin_staff') DEFAULT 'admin_staff',
  `department` varchar(50) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `join_date` date DEFAULT NULL,
  `shift` enum('morning','evening','night','general') DEFAULT 'general',
  `image_path` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive','on_leave') DEFAULT 'active',
  `emergency_contact` varchar(15) DEFAULT NULL,
  `emergency_contact_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `user_id`, `staff_id`, `name`, `email`, `phone`, `address`, `position`, `department`, `salary`, `join_date`, `shift`, `image_path`, `status`, `emergency_contact`, `emergency_contact_name`, `created_at`, `updated_at`) VALUES
(1, 2, 'STF001', 'Mrs. Sunita Sharma', 'sunita.sharma@hostel.com', '9876543201', '45 Green Park, Delhi', 'warden', 'Administration', 75000.00, '2023-01-15', 'general', 'warden.jpg', 'active', '9876543202', 'Mr. Sharma', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(2, NULL, 'STF002', 'Mr. Raj Kumar', 'raj.kumar@hostel.com', '9876543203', '78 Sector 15, Noida', 'caretaker', 'Maintenance', 35000.00, '2023-02-20', 'morning', 'caretaker.jpg', 'active', '9876543204', 'Mrs. Kumar', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(3, NULL, 'STF003', 'Mrs. Laxmi Devi', 'laxmi.devi@hostel.com', '9876543205', '23 Krishna Nagar, Delhi', 'cleaner', 'Housekeeping', 18000.00, '2023-03-10', 'morning', 'cleaner1.jpg', 'active', '9876543206', 'Mr. Devi', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(4, NULL, 'STF004', 'Mr. Ram Singh', 'ram.singh@hostel.com', '9876543207', '56 Patel Road, Delhi', 'security', 'Security', 22000.00, '2023-01-20', 'night', 'security1.jpg', 'active', '9876543208', 'Mrs. Singh', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(5, NULL, 'STF005', 'Mrs. Geeta Rani', 'geeta.rani@hostel.com', '9876543209', '89 Malviya Nagar, Delhi', 'cook', 'Mess', 25000.00, '2023-02-15', 'morning', 'cook1.jpg', 'active', '9876543210', 'Mr. Rani', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(6, NULL, 'STF006', 'Mr. Anil Gupta', 'anil.gupta@hostel.com', '9876543211', '34 Lajpat Nagar, Delhi', 'electrician', 'Maintenance', 28000.00, '2023-04-05', 'general', 'electrician.jpg', 'active', '9876543212', 'Mrs. Gupta', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(7, NULL, 'STF007', 'Mr. Suresh Kumar', 'suresh.kumar@hostel.com', '9876543213', '67 Saket, Delhi', 'plumber', 'Maintenance', 26000.00, '2023-03-25', 'general', 'plumber.jpg', 'active', '9876543214', 'Mrs. Kumar', '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(8, NULL, 'STF008', 'Ms. Priya Verma', 'priya.verma@hostel.com', '9876543215', '12 Hauz Khas, Delhi', 'admin_staff', 'Administration', 32000.00, '2023-01-10', 'general', 'admin1.jpg', 'active', '9876543216', 'Mr. Verma', '2025-11-01 00:00:00', '2025-11-25 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `room_allocations`
--

CREATE TABLE `room_allocations` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `move_in_date` date NOT NULL,
  `move_out_date` date DEFAULT NULL,
  `special_requirements` text DEFAULT NULL,
  `status` enum('pending','confirmed','cancelled','completed') DEFAULT 'confirmed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_allocations`
--

INSERT INTO `room_allocations` (`id`, `student_id`, `room_id`, `move_in_date`, `move_out_date`, `special_requirements`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2025-08-01', NULL, 'Near window bed preferred', 'confirmed', '2025-08-01 00:00:00', '2025-11-25 18:30:00'),
(2, 2, 1, '2025-08-01', NULL, NULL, 'confirmed', '2025-08-01 00:00:00', '2025-11-25 18:30:00'),
(3, 3, 3, '2025-08-01', NULL, NULL, 'confirmed', '2025-08-01 00:00:00', '2025-11-25 18:30:00'),
(4, 4, 3, '2025-08-01', NULL, NULL, 'confirmed', '2025-08-01 00:00:00', '2025-11-25 18:30:00'),
(5, 5, 3, '2025-08-01', NULL, NULL, 'confirmed', '2025-08-01 00:00:00', '2025-11-25 18:30:00'),
(6, 6, 4, '2025-08-01', NULL, NULL, 'confirmed', '2025-08-01 00:00:00', '2025-11-25 18:30:00'),
(7, 7, 4, '2025-08-01', NULL, NULL, 'confirmed', '2025-08-01 00:00:00', '2025-11-25 18:30:00'),
(8, 8, 4, '2025-08-01', NULL, NULL, 'confirmed', '2025-08-01 00:00:00', '2025-11-25 18:30:00'),
(9, 9, 4, '2025-08-01', NULL, NULL, 'confirmed', '2025-08-01 00:00:00', '2025-11-25 18:30:00'),
(10, 10, 5, '2025-08-01', NULL, 'AC temperature control needed', 'confirmed', '2025-08-01 00:00:00', '2025-11-25 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_type` enum('rent','mess','security','maintenance','fine','other') DEFAULT 'rent',
  `payment_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('paid','pending','overdue','cancelled') DEFAULT 'pending',
  `description` text DEFAULT NULL,
  `receipt_number` varchar(50) DEFAULT NULL,
  `payment_method` enum('cash','bank_transfer','online','cheque') DEFAULT 'cash',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `student_id`, `amount`, `payment_type`, `payment_date`, `due_date`, `status`, `description`, `receipt_number`, `payment_method`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 6000.00, 'rent', '2025-11-05', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT001', 'online', 1, '2025-11-05 00:00:00', '2025-11-25 18:30:00'),
(2, 1, 3500.00, 'mess', '2025-11-05', '2025-11-10', 'paid', 'Monthly mess charges - November 2025', 'RCPT002', 'online', 1, '2025-11-05 00:00:00', '2025-11-25 18:30:00'),
(3, 2, 6000.00, 'rent', '2025-11-06', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT003', 'bank_transfer', 1, '2025-11-06 00:00:00', '2025-11-25 18:30:00'),
(4, 2, 3500.00, 'mess', '2025-11-06', '2025-11-10', 'paid', 'Monthly mess charges - November 2025', 'RCPT004', 'bank_transfer', 1, '2025-11-06 00:00:00', '2025-11-25 18:30:00'),
(5, 3, 8000.00, 'rent', '2025-11-07', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT005', 'online', 1, '2025-11-07 00:00:00', '2025-11-25 18:30:00'),
(6, 3, 3500.00, 'mess', '2025-11-07', '2025-11-10', 'paid', 'Monthly mess charges - November 2025', 'RCPT006', 'online', 1, '2025-11-07 00:00:00', '2025-11-25 18:30:00'),
(7, 4, 7000.00, 'rent', '2025-11-08', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT007', 'cash', 1, '2025-11-08 00:00:00', '2025-11-25 18:30:00'),
(8, 5, 7000.00, 'rent', '2025-11-12', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT008', 'cash', 1, '2025-11-12 00:00:00', '2025-11-25 18:30:00'),
(9, 6, 7000.00, 'rent', NULL, '2025-11-10', 'pending', 'Monthly hostel rent - November 2025', NULL, 'cash', NULL, '2025-11-10 00:00:00', '2025-11-25 18:30:00'),
(10, 7, 8000.00, 'rent', NULL, '2025-11-10', 'pending', 'Monthly hostel rent - November 2025', NULL, 'cash', NULL, '2025-11-10 00:00:00', '2025-11-25 18:30:00'),
(11, 8, 8000.00, 'rent', '2025-11-09', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT009', 'online', 1, '2025-11-09 00:00:00', '2025-11-25 18:30:00'),
(12, 9, 5000.00, 'rent', '2025-11-10', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT010', 'bank_transfer', 1, '2025-11-10 00:00:00', '2025-11-25 18:30:00'),
(13, 10, 5000.00, 'rent', '2025-11-21', '2025-11-10', 'overdue', 'Monthly hostel rent - November 2025', NULL, 'cash', NULL, '2025-11-21 00:00:00', '2025-11-25 18:30:00'),
(14, 11, 5000.00, 'rent', '2025-11-11', '2025-11-10', 'paid', 'Monthly hostel rent - November 2025', 'RCPT011', 'online', 1, '2025-11-11 00:00:00', '2025-11-25 18:30:00'),
(15, 15, 8000.00, 'rent', NULL, '2025-11-25', 'pending', 'Monthly hostel rent - November 2025', NULL, 'cash', NULL, '2025-11-25 00:00:00', '2025-11-25 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `category` enum('electrical','plumbing','cleaning','furniture','security','other') DEFAULT 'other',
  `status` enum('pending','in_progress','resolved') DEFAULT 'pending',
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `assigned_to` int(11) DEFAULT NULL COMMENT 'Staff ID',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `resolved_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `student_id`, `title`, `description`, `category`, `status`, `priority`, `assigned_to`, `created_at`, `updated_at`, `resolved_at`) VALUES
(1, 1, 'AC Not Working', 'The air conditioner in room 101 is not cooling properly. It makes strange noise when turned on.', 'electrical', 'resolved', 'high', 6, '2025-11-10 04:00:00', '2025-11-11 08:50:00', '2025-11-11 08:50:00'),
(2, 3, 'Leaking Tap', 'The bathroom tap in room 103 is leaking continuously, causing water wastage.', 'plumbing', 'in_progress', 'medium', 7, '2025-11-12 05:45:00', '2025-11-25 18:30:00', NULL),
(3, 5, 'Broken Study Table', 'One leg of the study table in room 103 is broken and needs immediate repair.', 'furniture', 'pending', 'medium', NULL, '2025-11-13 11:15:00', '2025-11-25 18:30:00', NULL),
(4, 7, 'WiFi Connectivity Issue', 'Poor WiFi signal in room 104, especially in the corner beds. Need router adjustment.', 'other', 'resolved', 'low', 6, '2025-11-14 04:50:00', '2025-11-15 06:00:00', '2025-11-15 06:00:00'),
(5, 2, 'Room Cleaning Required', 'Room 101 needs deep cleaning. Dust accumulation in corners and under beds.', 'cleaning', 'in_progress', 'low', 3, '2025-11-15 09:00:00', '2025-11-25 18:30:00', NULL),
(6, 9, 'Security Concern', 'Street light near hostel back gate is not working, creating security concerns at night.', 'security', 'pending', 'high', 4, '2025-11-16 13:50:00', '2025-11-25 18:30:00', NULL),
(7, 4, 'Power Socket Not Working', 'The power socket near bed 2 in room 103 is not working. Cannot charge devices.', 'electrical', 'resolved', 'medium', 6, '2025-11-17 03:15:00', '2025-11-17 10:00:00', '2025-11-17 10:00:00'),
(8, 10, 'Window Latch Broken', 'Window latch in room 105 is broken, cannot lock window properly.', 'furniture', 'pending', 'medium', 2, '2025-11-20 10:30:00', '2025-11-25 18:30:00', NULL),
(9, 6, 'Water Heater Issue', 'Water heater in bathroom not working properly, gives only cold water.', 'plumbing', 'in_progress', 'medium', 7, '2025-11-22 14:20:00', '2025-11-25 18:30:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mess_menu`
--

CREATE TABLE `mess_menu` (
  `id` int(11) NOT NULL,
  `day` enum('monday','tuesday','wednesday','thursday','friday','saturday','sunday') DEFAULT NULL,
  `breakfast` text DEFAULT NULL,
  `lunch` text DEFAULT NULL,
  `dinner` text DEFAULT NULL,
  `special_notes` text DEFAULT NULL,
  `week_start_date` date DEFAULT NULL,
  `is_current` tinyint(1) DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mess_menu`
--

INSERT INTO `mess_menu` (`id`, `day`, `breakfast`, `lunch`, `dinner`, `special_notes`, `week_start_date`, `is_current`, `created_by`, `updated_at`, `created_at`) VALUES
(1, 'monday', 'Poha, Bread Butter, Tea, Milk', 'Dal Makhani, Jeera Rice, Roti, Mix Veg, Salad, Pickle', 'Chole Masala, Rice, Roti, Raita, Salad', 'Special dessert: Kheer', '2025-11-24', 1, 5, '2025-11-24 00:00:00', '2025-11-24 00:00:00'),
(2, 'tuesday', 'Sandwich, Cornflakes, Tea, Coffee', 'Rajma, Rice, Roti, Aloo Gobhi, Salad, Curd', 'Paneer Butter Masala, Rice, Roti, Salad, Papad', 'Evening snack: Samosa', '2025-11-24', 1, 5, '2025-11-24 00:00:00', '2025-11-24 00:00:00'),
(3, 'wednesday', 'Idli Sambhar, Tea, Milk', 'Chana Masala, Rice, Roti, Bhindi, Salad, Pickle', 'Egg Curry, Rice, Roti, Salad', 'Non-veg day', '2025-11-24', 1, 5, '2025-11-24 00:00:00', '2025-11-24 00:00:00'),
(4, 'thursday', 'Paratha with Curd, Tea, Coffee', 'Dal Tadka, Rice, Roti, Baingan Bharta, Salad', 'Kadhi Pakoda, Rice, Roti, Salad, Pickle', 'Special: Gulab Jamun', '2025-11-24', 1, 5, '2025-11-24 00:00:00', '2025-11-24 00:00:00'),
(5, 'friday', 'Aloo Paratha, Tea, Milk', 'Mix Dal, Rice, Roti, Aloo Matar, Salad, Curd', 'Fish Curry, Rice, Roti, Salad', 'Non-veg day, Special fish preparation', '2025-11-24', 1, 5, '2025-11-24 00:00:00', '2025-11-24 00:00:00'),
(6, 'saturday', 'Dosa, Chutney, Tea, Coffee', 'Vegetable Biryani, Raita, Papad, Salad', 'Matar Paneer, Rice, Roti, Salad', 'Weekend special menu', '2025-11-24', 1, 5, '2025-11-24 00:00:00', '2025-11-24 00:00:00'),
(7, 'sunday', 'Puri Sabzi, Tea, Milk', 'Chicken Curry, Rice, Roti, Salad', 'Pav Bhaji, Salad, Buttermilk', 'Non-veg day, Special chicken preparation', '2025-11-24', 1, 5, '2025-11-24 00:00:00', '2025-11-24 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `room_maintenance`
--

CREATE TABLE `room_maintenance` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('cleaning','repair','inspection','renovation','other') DEFAULT 'repair',
  `status` enum('scheduled','in_progress','completed','cancelled') DEFAULT 'scheduled',
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `scheduled_date` date DEFAULT NULL,
  `completed_date` date DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT 0.00,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_maintenance`
--

INSERT INTO `room_maintenance` (`id`, `room_id`, `title`, `description`, `type`, `status`, `priority`, `scheduled_date`, `completed_date`, `assigned_to`, `cost`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 8, 'Electrical Wiring Check', 'Complete electrical wiring inspection and replacement of old wires in room 108', 'repair', 'completed', 'high', '2025-11-10', '2025-11-12', 6, 2500.00, 1, '2025-11-10 00:00:00', '2025-11-12 00:00:00'),
(2, 6, 'Deep Cleaning', 'Deep cleaning and sanitization of room 106 before new student allocation', 'cleaning', 'scheduled', 'medium', '2025-11-26', NULL, 3, 500.00, 1, '2025-11-20 00:00:00', '2025-11-25 18:30:00'),
(3, 7, 'Furniture Repair', 'Repair and polishing of all furniture in room 107', 'repair', 'in_progress', 'medium', '2025-11-15', NULL, 2, 1200.00, 1, '2025-11-15 00:00:00', '2025-11-25 18:30:00'),
(4, 1, 'AC Servicing', 'Regular maintenance and servicing of AC units in room 101', 'repair', 'scheduled', 'low', '2025-11-28', NULL, 6, 800.00, 1, '2025-11-25 00:00:00', '2025-11-25 18:30:00'),
(5, 4, 'Bathroom Renovation', 'Partial renovation of attached bathroom including tile work and plumbing', 'renovation', 'scheduled', 'high', '2025-12-01', NULL, 7, 5000.00, 1, '2025-11-20 00:00:00', '2025-11-25 18:30:00'),
(6, 2, 'Safety Inspection', 'Quarterly safety inspection including fire safety equipment check', 'inspection', 'completed', 'medium', '2025-11-05', '2025-11-08', 2, 0.00, 1, '2025-11-05 00:00:00', '2025-11-08 00:00:00'),
(7, 3, 'Window Repair', 'Repair of broken window latch and glass panel replacement', 'repair', 'completed', 'medium', '2025-11-18', '2025-11-20', 2, 1500.00, 1, '2025-11-18 00:00:00', '2025-11-20 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `visitor_name` varchar(100) NOT NULL,
  `visitor_phone` varchar(15) DEFAULT NULL,
  `relation` varchar(50) DEFAULT NULL,
  `purpose` varchar(200) DEFAULT NULL,
  `visit_date` date NOT NULL,
  `entry_time` time NOT NULL,
  `exit_time` time DEFAULT NULL,
  `status` enum('checked_in','checked_out') DEFAULT 'checked_in',
  `id_proof_type` varchar(50) DEFAULT NULL,
  `id_proof_number` varchar(100) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`id`, `student_id`, `visitor_name`, `visitor_phone`, `relation`, `purpose`, `visit_date`, `entry_time`, `exit_time`, `status`, `id_proof_type`, `id_proof_number`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'Rajesh Sharma', '9876543211', 'Father', 'Fee Payment and Meeting', '2025-11-10', '14:30:00', '16:45:00', 'checked_out', 'Aadhar Card', 'XXXX-XXXX-1234', 4, '2025-11-10 14:30:00', '2025-11-10 16:45:00'),
(2, 3, 'Kumar Reddy', '9876543215', 'Father', 'Delivering Books', '2025-11-12', '11:00:00', '12:30:00', 'checked_out', 'Driving License', 'DL-123456', 4, '2025-11-12 11:00:00', '2025-11-12 12:30:00'),
(3, 5, 'Amit Singh', '9876543219', 'Father', 'Family Visit', '2025-11-15', '16:00:00', '18:30:00', 'checked_out', 'PAN Card', 'ABCDE1234F', 4, '2025-11-15 16:00:00', '2025-11-15 18:30:00'),
(4, 2, 'Sunil Patel', '9876543213', 'Father', 'Medical Emergency', '2025-11-18', '09:30:00', NULL, 'checked_in', 'Voter ID', 'VOTER-789456', 4, '2025-11-18 09:30:00', '2025-11-18 09:30:00'),
(5, 10, 'Vijay Malhotra', '9876543229', 'Father', 'Meeting Warden', '2025-11-20', '15:00:00', '17:15:00', 'checked_out', 'Passport', 'P1234567', 4, '2025-11-20 15:00:00', '2025-11-20 17:15:00'),
(6, 7, 'Sanjay Verma', '9876543223', 'Father', 'Room Inspection', '2025-11-22', '10:45:00', '12:30:00', 'checked_out', 'Aadhar Card', 'XXXX-XXXX-5678', 4, '2025-11-22 10:45:00', '2025-11-22 12:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `mess_menu_templates`
--

CREATE TABLE `mess_menu_templates` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `breakfast_items` text DEFAULT NULL,
  `lunch_items` text NOT NULL,
  `dinner_items` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT 'general',
  `created_by` int(11) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mess_menu_templates`
--

INSERT INTO `mess_menu_templates` (`id`, `name`, `breakfast_items`, `lunch_items`, `dinner_items`, `description`, `category`, `created_by`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'Standard Vegetarian', 'Poha, Bread, Butter, Tea, Milk', 'Dal, Rice, Roti, Sabzi, Salad, Curd', 'Rice, Roti, Sabzi, Dal, Salad', 'Standard vegetarian meal plan', 'vegetarian', 5, 1, '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(2, 'Premium Non-Veg', 'Sandwich, Cornflakes, Tea, Coffee', 'Chicken Curry, Rice, Roti, Salad, Raita', 'Fish Curry, Rice, Roti, Salad', 'Premium non-vegetarian meals', 'non-vegetarian', 5, 0, '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(3, 'Special Weekend', 'Puri Sabzi, Tea, Milk', 'Vegetable Biryani, Raita, Papad, Salad', 'Paneer Butter Masala, Rice, Roti, Salad', 'Special weekend menu', 'special', 5, 0, '2025-11-01 00:00:00', '2025-11-25 18:30:00'),
(4, 'Economy Meal', 'Idli Sambhar, Tea', 'Dal, Rice, Roti, Simple Sabzi', 'Rice, Dal, Roti', 'Budget friendly meal plan', 'economy', 5, 0, '2025-11-01 00:00:00', '2025-11-25 18:30:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `room_number` (`room_number`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `staff_id` (`staff_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `room_allocations`
--
ALTER TABLE `room_allocations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `receipt_number` (`receipt_number`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `assigned_to` (`assigned_to`);

--
-- Indexes for table `mess_menu`
--
ALTER TABLE `mess_menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `room_maintenance`
--
ALTER TABLE `room_maintenance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `assigned_to` (`assigned_to`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `mess_menu_templates`
--
ALTER TABLE `mess_menu_templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `room_allocations`
--
ALTER TABLE `room_allocations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `mess_menu`
--
ALTER TABLE `mess_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `room_maintenance`
--
ALTER TABLE `room_maintenance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `visitors`
--
ALTER TABLE `visitors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `mess_menu_templates`
--
ALTER TABLE `mess_menu_templates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `room_allocations`
--
ALTER TABLE `room_allocations`
  ADD CONSTRAINT `room_allocations_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `room_allocations_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `complaints_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `complaints_ibfk_2` FOREIGN KEY (`assigned_to`) REFERENCES `staff` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `mess_menu`
--
ALTER TABLE `mess_menu`
  ADD CONSTRAINT `mess_menu_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `room_maintenance`
--
ALTER TABLE `room_maintenance`
  ADD CONSTRAINT `room_maintenance_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `room_maintenance_ibfk_2` FOREIGN KEY (`assigned_to`) REFERENCES `staff` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `room_maintenance_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `visitors`
--
ALTER TABLE `visitors`
  ADD CONSTRAINT `visitors_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `visitors_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `mess_menu_templates`
--
ALTER TABLE `mess_menu_templates`
  ADD CONSTRAINT `mess_menu_templates_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;