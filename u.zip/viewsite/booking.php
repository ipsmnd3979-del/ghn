<?php
session_start();
include 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Fetch bookings based on user role
if ($user_role === 'student') {
    // Student can only see their own bookings
    $stmt = $db->prepare("SELECT ra.*, r.room_number, r.floor, r.type, r.rent, s.name as student_name
                         FROM room_allocations ra
                         JOIN rooms r ON ra.room_id = r.id
                         JOIN students s ON ra.student_id = s.id
                         WHERE ra.student_id = ?
                         ORDER BY ra.created_at DESC");
    $stmt->execute([$user_id]);
} else {
    // Admin/Staff can see all bookings
    $stmt = $db->prepare("SELECT ra.*, r.room_number, r.floor, r.type, r.rent, s.name as student_name
                         FROM room_allocations ra
                         JOIN rooms r ON ra.room_id = r.id
                         JOIN students s ON ra.student_id = s.id
                         ORDER BY ra.created_at DESC");
    $stmt->execute();
}

$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle booking actions (cancel, confirm, etc.)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $booking_id = $_POST['booking_id'] ?? 0;
    
    if ($action && $booking_id) {
        try {
            switch ($action) {
                case 'cancel':
                    $stmt = $db->prepare("UPDATE room_allocations SET status = 'cancelled' WHERE id = ?");
                    $stmt->execute([$booking_id]);
                    $_SESSION['success_message'] = "Booking cancelled successfully!";
                    break;
                    
                case 'confirm':
                    $stmt = $db->prepare("UPDATE room_allocations SET status = 'confirmed' WHERE id = ?");
                    $stmt->execute([$booking_id]);
                    $_SESSION['success_message'] = "Booking confirmed successfully!";
                    break;
                    
                case 'complete':
                    $stmt = $db->prepare("UPDATE room_allocations SET status = 'completed', move_out_date = CURDATE() WHERE id = ?");
                    $stmt->execute([$booking_id]);
                    $_SESSION['success_message'] = "Booking marked as completed!";
                    break;
            }
            
            header("Location: booking.php");
            exit();
            
        } catch (PDOException $e) {
            $_SESSION['error_message'] = "Action failed: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .booking-card {
            border-left: 4px solid;
            transition: all 0.3s ease;
        }
        .booking-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .status-confirmed { border-left-color: #28a745; }
        .status-pending { border-left-color: #ffc107; }
        .status-cancelled { border-left-color: #dc3545; }
        .status-completed { border-left-color: #6c757d; }
        
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <!-- Page Header -->
        <div class="row mb-4">
            <div class="col-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="indexview.php">Home</a></li>
                        <li class="breadcrumb-item active">My Bookings</li>
                    </ol>
                </nav>
                
                <div class="d-flex justify-content-between align-items-center">
                    <h2><i class="fas fa-calendar-check me-2"></i>
                        <?php echo $user_role === 'student' ? 'My Bookings' : 'All Bookings'; ?>
                    </h2>
                    <?php if ($user_role === 'student'): ?>
                        <a href="rooms.php" class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i>Book New Room
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Success/Error Messages -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle me-2"></i>
                <?php echo $_SESSION['success_message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <?php echo $_SESSION['error_message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <!-- Booking Statistics -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card p-3 text-center">
                    <h4><?php echo count($bookings); ?></h4>
                    <p class="mb-0">Total Bookings</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card p-3 text-center">
                    <h4><?php echo count(array_filter($bookings, function($b) { return $b['status'] === 'confirmed'; })); ?></h4>
                    <p class="mb-0">Confirmed</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card p-3 text-center">
                    <h4><?php echo count(array_filter($bookings, function($b) { return $b['status'] === 'pending'; })); ?></h4>
                    <p class="mb-0">Pending</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card p-3 text-center">
                    <h4><?php echo count(array_filter($bookings, function($b) { return $b['status'] === 'completed'; })); ?></h4>
                    <p class="mb-0">Completed</p>
                </div>
            </div>
        </div>

        <!-- Bookings List -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-list me-2"></i>
                    Booking History
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($bookings)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No Bookings Found</h5>
                        <p class="text-muted">
                            <?php echo $user_role === 'student' 
                                ? 'You haven\'t made any room bookings yet.' 
                                : 'No bookings have been made yet.'; ?>
                        </p>
                        <?php if ($user_role === 'student'): ?>
                            <a href="rooms.php" class="btn btn-primary">
                                <i class="fas fa-search me-2"></i>Browse Available Rooms
                            </a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <?php if ($user_role !== 'student'): ?>
                                        <th>Student</th>
                                    <?php endif; ?>
                                    <th>Room</th>
                                    <th>Type</th>
                                    <th>Move-in Date</th>
                                    <th>Rent</th>
                                    <th>Status</th>
                                    <th>Booking Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($bookings as $booking): ?>
                                    <tr>
                                        <?php if ($user_role !== 'student'): ?>
                                            <td>
                                                <strong><?php echo htmlspecialchars($booking['student_name']); ?></strong>
                                            </td>
                                        <?php endif; ?>
                                        <td>
                                            <strong>Room <?php echo $booking['room_number']; ?></strong>
                                            <br><small class="text-muted">Floor <?php echo $booking['floor']; ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?php echo ucfirst($booking['type']); ?></span>
                                        </td>
                                        <td>
                                            <?php echo date('M j, Y', strtotime($booking['move_in_date'])); ?>
                                        </td>
                                        <td>
                                            ₹<?php echo number_format($booking['rent']); ?>/month
                                        </td>
                                        <td>
                                            <?php
                                            $status_class = '';
                                            switch ($booking['status']) {
                                                case 'confirmed': $status_class = 'bg-success'; break;
                                                case 'pending': $status_class = 'bg-warning'; break;
                                                case 'cancelled': $status_class = 'bg-danger'; break;
                                                case 'completed': $status_class = 'bg-secondary'; break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $status_class; ?>">
                                                <?php echo ucfirst($booking['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php echo date('M j, Y', strtotime($booking['created_at'])); ?>
                                            <br><small class="text-muted"><?php echo date('g:i A', strtotime($booking['created_at'])); ?></small>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <!-- View Details -->
                                                <button type="button" class="btn btn-info" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#bookingModal<?php echo $booking['id']; ?>">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                
                                                <!-- Action Buttons -->
                                                <?php if ($user_role !== 'student'): ?>
                                                    <?php if ($booking['status'] === 'pending'): ?>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                                            <input type="hidden" name="action" value="confirm">
                                                            <button type="submit" class="btn btn-success" 
                                                                    onclick="return confirm('Confirm this booking?')">
                                                                <i class="fas fa-check"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                    
                                                    <?php if (in_array($booking['status'], ['pending', 'confirmed'])): ?>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                                            <input type="hidden" name="action" value="cancel">
                                                            <button type="submit" class="btn btn-danger" 
                                                                    onclick="return confirm('Cancel this booking?')">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                    
                                                    <?php if ($booking['status'] === 'confirmed'): ?>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                                            <input type="hidden" name="action" value="complete">
                                                            <button type="submit" class="btn btn-secondary" 
                                                                    onclick="return confirm('Mark this booking as completed?')">
                                                                <i class="fas fa-flag-checkered"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <!-- Student Actions -->
                                                    <?php if (in_array($booking['status'], ['pending', 'confirmed'])): ?>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                                            <input type="hidden" name="action" value="cancel">
                                                            <button type="submit" class="btn btn-danger btn-sm" 
                                                                    onclick="return confirm('Are you sure you want to cancel this booking?')">
                                                                Cancel
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- Booking Details Modal -->
                                    <div class="modal fade" id="bookingModal<?php echo $booking['id']; ?>" tabindex="-1">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Booking Details</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h6>Room Information</h6>
                                                            <p><strong>Room:</strong> <?php echo $booking['room_number']; ?></p>
                                                            <p><strong>Floor:</strong> <?php echo $booking['floor']; ?></p>
                                                            <p><strong>Type:</strong> <?php echo ucfirst($booking['type']); ?></p>
                                                            <p><strong>Rent:</strong> ₹<?php echo number_format($booking['rent']); ?>/month</p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <h6>Booking Information</h6>
                                                            <p><strong>Student:</strong> <?php echo htmlspecialchars($booking['student_name']); ?></p>
                                                            <p><strong>Move-in Date:</strong> <?php echo date('F j, Y', strtotime($booking['move_in_date'])); ?></p>
                                                            <p><strong>Status:</strong> 
                                                                <span class="badge <?php echo $status_class; ?>">
                                                                    <?php echo ucfirst($booking['status']); ?>
                                                                </span>
                                                            </p>
                                                            <p><strong>Booked On:</strong> <?php echo date('F j, Y g:i A', strtotime($booking['created_at'])); ?></p>
                                                        </div>
                                                    </div>
                                                    <?php if (!empty($booking['special_requirements'])): ?>
                                                        <div class="mt-3">
                                                            <h6>Special Requirements</h6>
                                                            <p class="text-muted"><?php echo htmlspecialchars($booking['special_requirements']); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>