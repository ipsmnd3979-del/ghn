<?php
session_start();
include '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get user data from session
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'student';
$user_email = $_SESSION['user_email'] ?? '';
$user_id = $_SESSION['user_id'] ?? 0;

// Get room ID from URL
$room_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($room_id <= 0) {
    header("Location: viewrooms.php");
    exit();
}

// Fetch room details from database
$room = [];
try {
    $stmt = $db->prepare("
        SELECT r.*, 
               r.occupied as current_occupants,
               (SELECT GROUP_CONCAT(s.name SEPARATOR ', ') 
                FROM students s 
                WHERE s.room_id = r.id AND s.status = 'active') as occupant_names,
               (SELECT COUNT(*) 
                FROM students s 
                WHERE s.room_id = r.id AND s.status = 'active') as occupant_count
        FROM rooms r 
        WHERE r.id = ?
    ");
    $stmt->execute([$room_id]);
    $room = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// If room not found, redirect
if (!$room) {
    header("Location: viewrooms.php");
    exit();
}

// Get user's student details
$student_details = [];
try {
    $stmt = $db->prepare("SELECT * FROM students WHERE user_id = ? OR id = ?");
    $stmt->execute([$user_id, $user_id]);
    $student_details = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Check if user is already allocated to this room
$is_allocated = false;
if (!empty($student_details)) {
    try {
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM room_allocations 
            WHERE student_id = ? AND room_id = ? AND status = 'confirmed'
        ");
        $stmt->execute([$student_details['id'], $room_id]);
        $is_allocated = $stmt->fetchColumn() > 0;
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
    }
}

// Check if user already has an active allocation
$has_active_allocation = false;
if (!empty($student_details)) {
    try {
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM room_allocations 
            WHERE student_id = ? AND status = 'confirmed'
        ");
        $stmt->execute([$student_details['id']]);
        $has_active_allocation = $stmt->fetchColumn() > 0;
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
    }
}

// Get similar rooms
$similar_rooms = [];
try {
    $stmt = $db->prepare("
        SELECT id, room_number, floor, type, rent, status 
        FROM rooms 
        WHERE type = ? AND id != ? 
        ORDER BY rent
        LIMIT 4
    ");
    $stmt->execute([$room['type'], $room_id]);
    $similar_rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Check if user can book (student role, no active allocation, room available)
$can_book = ($user_role === 'student' && 
             !$has_active_allocation && 
             $room['status'] === 'available' &&
             $room['occupied'] < $room['capacity']);

// Process booking request
$booking_message = '';
$booking_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_room'])) {
    if (!$can_book) {
        $booking_error = "You cannot book this room at the moment.";
    } else {
        $move_in_date = $_POST['move_in_date'] ?? '';
        $special_requirements = $_POST['special_requirements'] ?? '';
        
        if (empty($move_in_date)) {
            $booking_error = "Please select a move-in date.";
        } else {
            try {
                $db->beginTransaction();
                
                // Create room allocation
                $stmt = $db->prepare("
                    INSERT INTO room_allocations 
                    (student_id, room_id, move_in_date, special_requirements, status) 
                    VALUES (?, ?, ?, ?, 'pending')
                ");
                $stmt->execute([
                    $student_details['id'],
                    $room_id,
                    $move_in_date,
                    $special_requirements
                ]);
                
                // Update room occupied count
                $new_occupied = $room['occupied'] + 1;
                $new_status = ($new_occupied >= $room['capacity']) ? 'occupied' : 'available';
                
                $stmt = $db->prepare("
                    UPDATE rooms SET occupied = ?, status = ? WHERE id = ?
                ");
                $stmt->execute([$new_occupied, $new_status, $room_id]);
                
                $db->commit();
                
                $booking_message = "Room booking request submitted successfully! Please wait for confirmation.";
                
                // Refresh room data
                $stmt = $db->prepare("
                    SELECT r.*, r.occupied as current_occupants,
                           (SELECT GROUP_CONCAT(s.name SEPARATOR ', ') 
                            FROM students s 
                            WHERE s.room_id = r.id AND s.status = 'active') as occupant_names
                    FROM rooms r 
                    WHERE r.id = ?
                ");
                $stmt->execute([$room_id]);
                $room = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $can_book = false; // Disable booking after successful submission
                
            } catch (PDOException $e) {
                $db->rollBack();
                $booking_error = "Booking failed: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room <?php echo htmlspecialchars($room['room_number']); ?> - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --gradient-2: linear-gradient(135deg, #3B82F6, #8B5CF6);
            --gradient-3: linear-gradient(135deg, #10B981, #34D399);
            --gradient-4: linear-gradient(135deg, #F59E0B, #FBBF24);
            --sidebar-width: 270px;
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Animated Background */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) {
            width: 600px;
            height: 600px;
            background: #8B5CF6;
            top: -200px;
            left: -200px;
            animation-delay: 0s;
        }

        .bg-orbs:nth-child(2) {
            width: 400px;
            height: 400px;
            background: #EC4899;
            bottom: -150px;
            right: -100px;
            animation-delay: -7s;
        }

        .bg-orbs:nth-child(3) {
            width: 300px;
            height: 300px;
            background: #3B82F6;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation-delay: -14s;
        }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: rgba(18, 18, 26, 0.92);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-right: 1px solid var(--glass-border);
            z-index: 1000;
            padding: 1.5rem 0;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 1.5rem;
            text-decoration: none;
        }

        .sidebar-brand .brand-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-1);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
            margin-right: 12px;
            box-shadow: 0 4px 16px rgba(139, 92, 246, 0.3);
            flex-shrink: 0;
        }

        .sidebar-brand .brand-text {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .sidebar-brand .brand-text span {
            color: #8B5CF6;
        }

        .sidebar-brand .brand-sub {
            display: block;
            font-size: 0.55rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 0 0.75rem;
        }

        .sidebar-nav::-webkit-scrollbar {
            width: 4px;
        }

        .sidebar-nav::-webkit-scrollbar-track {
            background: transparent;
        }

        .sidebar-nav::-webkit-scrollbar-thumb {
            background: rgba(139, 92, 246, 0.3);
            border-radius: 10px;
        }

        .nav-section-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--text-muted);
            padding: 0.75rem 1rem 0.5rem;
        }

        .nav-item {
            margin-bottom: 2px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
            font-weight: 500;
            position: relative;
        }

        .nav-link i {
            width: 1.6rem;
            font-size: 1rem;
            color: var(--text-muted);
            transition: all 0.3s ease;
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(139, 92, 246, 0.12);
            color: var(--text-primary);
        }

        .nav-link:hover i,
        .nav-link.active i {
            color: #8B5CF6;
        }

        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 24px;
            background: var(--gradient-1);
            border-radius: 0 4px 4px 0;
        }

        .sidebar-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .sidebar-footer .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.6rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .sidebar-footer .user-card:hover {
            background: rgba(255, 255, 255, 0.06);
        }

        .sidebar-footer .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            color: white;
            flex-shrink: 0;
        }

        .sidebar-footer .user-info {
            flex: 1;
            min-width: 0;
        }

        .sidebar-footer .user-info .name {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .sidebar-footer .user-info .role {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: capitalize;
        }

        /* Main Content */
        #content-wrapper {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem 2rem;
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        /* Topbar */
        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1.5rem;
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .btn-toggle-sidebar {
            display: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-toggle-sidebar:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .page-title h1 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .page-title p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .topbar-user:hover {
            background: rgba(255, 255, 255, 0.08);
        }

        .topbar-user .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .topbar-user .user-name {
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        .topbar-user .user-role {
            font-size: 0.65rem;
            color: var(--text-muted);
        }

        /* Breadcrumb */
        .breadcrumb {
            padding: 0.5rem 0;
            margin-bottom: 1.5rem;
            background: transparent;
        }

        .breadcrumb-item a {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.8rem;
            transition: color 0.3s ease;
        }

        .breadcrumb-item a:hover {
            color: #8B5CF6;
        }

        .breadcrumb-item.active {
            color: var(--text-primary);
            font-size: 0.8rem;
        }

        .breadcrumb-item + .breadcrumb-item::before {
            color: var(--text-muted);
        }

        /* Alerts */
        .alert {
            border-radius: 12px;
            border: none;
            padding: 0.8rem 1.2rem;
            font-size: 0.85rem;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.12);
            color: #34D399;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.12);
            color: #F87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        /* Room Detail Grid */
        .room-detail-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
        }

        /* Room Main Card */
        .room-main-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 2rem;
        }

        .room-main-card .room-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            margin-bottom: 1.5rem;
        }

        .room-main-card .room-number {
            font-size: 2rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -1px;
        }

        .room-main-card .room-number small {
            font-size: 0.9rem;
            font-weight: 400;
            color: var(--text-muted);
        }

        .room-main-card .room-status {
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.3rem 1rem;
            border-radius: 50px;
        }

        .room-status.available {
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
        }

        .room-status.occupied {
            background: rgba(139, 92, 246, 0.15);
            color: #8B5CF6;
        }

        .room-status.maintenance {
            background: rgba(245, 158, 11, 0.15);
            color: #F59E0B;
        }

        .room-main-card .room-price {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--text-primary);
            margin: 1rem 0;
        }

        .room-main-card .room-price small {
            font-size: 1rem;
            font-weight: 400;
            color: var(--text-muted);
        }

        .room-main-card .room-details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin: 1.5rem 0;
        }

        .room-main-card .detail-item {
            padding: 0.75rem 1rem;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 12px;
            border: 1px solid var(--glass-border);
        }

        .room-main-card .detail-item .detail-label {
            font-size: 0.55rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-muted);
        }

        .room-main-card .detail-item .detail-value {
            font-size: 0.95rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-top: 0.1rem;
        }

        .room-main-card .facilities-section {
            margin: 1.5rem 0;
        }

        .room-main-card .facilities-section h5 {
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 0.75rem;
        }

        .room-main-card .facilities-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .room-main-card .facility-tag {
            padding: 0.3rem 0.8rem;
            background: rgba(139, 92, 246, 0.08);
            border: 1px solid rgba(139, 92, 246, 0.15);
            border-radius: 50px;
            font-size: 0.7rem;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .room-main-card .facility-tag i {
            color: #10B981;
            font-size: 0.55rem;
        }

        .room-main-card .occupants-section {
            padding: 1rem;
            background: rgba(255, 255, 255, 0.02);
            border-radius: 12px;
            border: 1px solid var(--glass-border);
            margin: 1rem 0;
        }

        .room-main-card .occupants-section h5 {
            font-size: 0.8rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .room-main-card .occupants-section .occupant-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0;
        }

        .room-main-card .occupants-section .occupant-item .occ-avatar {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: var(--gradient-2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.6rem;
            font-weight: 600;
            color: white;
        }

        .room-main-card .occupants-section .occupant-item .occ-name {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        .room-main-card .btn-book {
            width: 100%;
            padding: 0.8rem;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            color: white;
            background: var(--gradient-1);
            transition: all 0.3s ease;
            margin-top: 1rem;
        }

        .room-main-card .btn-book:hover:not(:disabled) {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
        }

        .room-main-card .btn-book:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }

        .room-main-card .btn-book.booked {
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        /* Sidebar Info */
        .info-sidebar {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .info-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.5rem;
        }

        .info-card .card-title {
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .info-card .card-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .info-card .info-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.6rem 0;
            border-bottom: 1px solid var(--glass-border);
        }

        .info-card .info-item:last-child {
            border-bottom: none;
        }

        .info-card .info-item .info-icon {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            background: rgba(139, 92, 246, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #8B5CF6;
            font-size: 0.8rem;
            flex-shrink: 0;
        }

        .info-card .info-item .info-content .info-label {
            font-size: 0.55rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
            letter-spacing: 0.3px;
        }

        .info-card .info-item .info-content .info-value {
            font-size: 0.85rem;
            color: var(--text-primary);
        }

        /* Booking Modal */
        .modal-content {
            background: var(--bg-secondary);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
        }

        .modal-header,
        .modal-footer {
            border-color: var(--glass-border);
        }

        .modal-title {
            color: var(--text-primary);
        }

        .modal-title i {
            color: #8B5CF6;
        }

        .btn-close {
            filter: invert(1) brightness(2);
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
        }

        .btn-primary {
            background: var(--gradient-1);
            border: none;
            color: white;
        }

        .btn-primary:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        .modal-body .form-label {
            color: var(--text-secondary);
            font-size: 0.8rem;
            font-weight: 500;
        }

        .modal-body .form-control,
        .modal-body .form-select {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            color: var(--text-primary);
            border-radius: 12px;
            padding: 0.7rem 1rem;
        }

        .modal-body .form-control:focus,
        .modal-body .form-select:focus {
            border-color: #8B5CF6;
            box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15);
        }

        .modal-body .form-control::placeholder {
            color: var(--text-muted);
        }

        .modal-body .form-select option {
            background: var(--bg-secondary);
            color: var(--text-primary);
        }

        /* Similar Rooms */
        .similar-room-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .similar-room-card:hover {
            background: rgba(255, 255, 255, 0.06);
            transform: translateX(4px);
        }

        .similar-room-card .similar-room-number {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .similar-room-card .similar-room-number small {
            font-size: 0.65rem;
            font-weight: 400;
            color: var(--text-muted);
        }

        .similar-room-card .similar-room-price {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .similar-room-card .similar-room-price small {
            font-size: 0.55rem;
            font-weight: 400;
            color: var(--text-muted);
        }

        .similar-room-card .similar-room-status {
            font-size: 0.5rem;
            font-weight: 600;
            text-transform: uppercase;
            padding: 0.1rem 0.5rem;
            border-radius: 50px;
        }

        .similar-room-card .similar-room-status.available {
            background: rgba(16, 185, 129, 0.12);
            color: #10B981;
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 1.5rem 0 0.5rem;
            border-top: 1px solid var(--glass-border);
            margin-top: 2rem;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .room-detail-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            #content-wrapper {
                margin-left: 0;
                padding: 1rem;
            }

            .btn-toggle-sidebar {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .topbar {
                padding: 0.5rem 1rem;
                border-radius: 16px;
            }

            .page-title h1 {
                font-size: 1rem;
            }

            .page-title p {
                font-size: 0.7rem;
            }

            .topbar-user .user-name,
            .topbar-user .user-role {
                display: none;
            }

            .room-main-card {
                padding: 1.5rem;
            }

            .room-main-card .room-number {
                font-size: 1.5rem;
            }

            .room-main-card .room-price {
                font-size: 2rem;
            }

            .room-main-card .room-details-grid {
                grid-template-columns: 1fr 1fr;
            }

            .room-main-card .room-header {
                flex-direction: column;
                gap: 0.5rem;
            }
        }

        @media (max-width: 480px) {
            .room-main-card .room-details-grid {
                grid-template-columns: 1fr;
            }

            .room-main-card .facilities-grid {
                gap: 0.3rem;
            }

            .room-main-card .facility-tag {
                font-size: 0.6rem;
                padding: 0.2rem 0.6rem;
            }
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg-primary);
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(139, 92, 246, 0.3);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: rgba(139, 92, 246, 0.5);
        }

        .dropdown-menu {
            background: var(--bg-secondary) !important;
            border: 1px solid var(--glass-border) !important;
        }

        .dropdown-item {
            color: var(--text-secondary) !important;
        }

        .dropdown-item:hover {
            background: rgba(139, 92, 246, 0.1) !important;
            color: var(--text-primary) !important;
        }

        .dropdown-divider {
            border-color: var(--glass-border) !important;
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <a href="indexview.php" class="sidebar-brand">
            <div class="brand-icon">
                <i class="fas fa-home"></i>
            </div>
            <div>
                <div class="brand-text">Graceful<span>Living</span></div>
                <span class="brand-sub">Management System</span>
            </div>
        </a>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Main</div>
            <div class="nav-item">
                <a href="indexview.php" class="nav-link">
                    <i class="fas fa-th-large"></i>
                    Dashboard
                </a>
            </div>

            <div class="nav-section-label">Management</div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    My Profile
                </a>
            </div>
            <div class="nav-item">
                <a href="viewrooms.php" class="nav-link active">
                    <i class="fas fa-bed"></i>
                    Rooms
                </a>
            </div>
            <div class="nav-item">
                <a href="payments.php" class="nav-link">
                    <i class="fas fa-credit-card"></i>
                    Payments
                </a>
            </div>

            <div class="nav-section-label">Account</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i>
                    Settings
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </nav>

        <div class="sidebar-footer">
            <a href="profile.php" class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($user_name); ?></div>
                    <div class="role"><?php echo htmlspecialchars($user_role); ?></div>
                </div>
                <i class="fas fa-ellipsis-v" style="color: var(--text-muted); font-size: 0.7rem;"></i>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div id="content-wrapper">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left">
                <button class="btn-toggle-sidebar" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Room Details</h1>
                    <p>View complete room information</p>
                </div>
            </div>
            <div class="topbar-right">
                <a href="viewrooms.php" class="btn" style="background:rgba(255,255,255,0.04);border:1px solid var(--glass-border);color:var(--text-secondary);border-radius:12px;padding:0.4rem 1rem;font-size:0.8rem;transition:all 0.3s ease;text-decoration:none;">
                    <i class="fas fa-arrow-left me-2"></i>Back to Rooms
                </a>
                <a href="profile.php" class="topbar-user">
                    <div class="avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                    <div>
                        <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
                        <div class="user-role"><?php echo htmlspecialchars($user_role); ?></div>
                    </div>
                </a>
            </div>
        </header>

        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="indexview.php">Home</a></li>
                <li class="breadcrumb-item"><a href="viewrooms.php">Rooms</a></li>
                <li class="breadcrumb-item active">Room <?php echo htmlspecialchars($room['room_number']); ?></li>
            </ol>
        </nav>

        <!-- Messages -->
        <?php if ($booking_message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i>
                <?php echo $booking_message; ?>
            </div>
        <?php endif; ?>

        <?php if ($booking_error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo $booking_error; ?>
            </div>
        <?php endif; ?>

        <!-- Room Detail -->
        <div class="room-detail-grid">
            <!-- Main Room Info -->
            <div class="room-main-card">
                <div class="room-header">
                    <div>
                        <div class="room-number">
                            Room <?php echo htmlspecialchars($room['room_number']); ?>
                            <small>• Floor <?php echo htmlspecialchars($room['floor']); ?></small>
                        </div>
                    </div>
                    <span class="room-status <?php echo $room['status']; ?>">
                        <i class="fas fa-circle me-1" style="font-size:0.4rem;"></i>
                        <?php echo ucfirst($room['status']); ?>
                    </span>
                </div>

                <div class="room-price">
                    ₹<?php echo number_format($room['rent'] ?? 0); ?>
                    <small>/month</small>
                </div>

                <div class="room-details-grid">
                    <div class="detail-item">
                        <div class="detail-label">Room Type</div>
                        <div class="detail-value"><?php echo ucfirst($room['type'] ?? 'Standard'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Capacity</div>
                        <div class="detail-value"><?php echo $room['capacity'] ?? 1; ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Current Occupants</div>
                        <div class="detail-value"><?php echo $room['occupied'] ?? 0; ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Available Spaces</div>
                        <div class="detail-value" style="color: <?php echo ($room['capacity'] - $room['occupied']) > 0 ? '#10B981' : '#EF4444'; ?>;">
                            <?php echo max(0, ($room['capacity'] ?? 1) - ($room['occupied'] ?? 0)); ?>
                        </div>
                    </div>
                </div>

                <?php 
                $facilities = [];
                if (!empty($room['facilities'])) {
                    $facilities = json_decode($room['facilities'], true);
                    if (!is_array($facilities)) {
                        $facilities = explode(',', $room['facilities']);
                    }
                }
                if (!empty($facilities)): 
                ?>
                <div class="facilities-section">
                    <h5><i class="fas fa-star me-2" style="color:#F59E0B;"></i>Facilities & Amenities</h5>
                    <div class="facilities-grid">
                        <?php foreach ($facilities as $facility): ?>
                            <?php $facility = trim($facility); ?>
                            <?php if (!empty($facility) && $facility !== 'null'): ?>
                            <span class="facility-tag">
                                <i class="fas fa-check-circle"></i>
                                <?php echo htmlspecialchars($facility); ?>
                            </span>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (!empty($room['occupant_names'])): ?>
                <div class="occupants-section">
                    <h5><i class="fas fa-users me-2" style="color:#8B5CF6;"></i>Current Occupants</h5>
                    <?php 
                    $occupants = explode(', ', $room['occupant_names']);
                    foreach ($occupants as $occupant): 
                        if (empty(trim($occupant))) continue;
                    ?>
                    <div class="occupant-item">
                        <div class="occ-avatar"><?php echo strtoupper(substr(trim($occupant), 0, 2)); ?></div>
                        <span class="occ-name"><?php echo htmlspecialchars(trim($occupant)); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if ($room['status'] === 'available' && $room['occupied'] < $room['capacity']): ?>
                    <?php if ($user_role === 'student'): ?>
                        <?php if ($has_active_allocation): ?>
                            <button class="btn-book" disabled>
                                <i class="fas fa-check-circle me-2"></i>Already Allocated
                            </button>
                        <?php elseif ($is_allocated): ?>
                            <button class="btn-book booked" disabled>
                                <i class="fas fa-check-circle me-2"></i>Already Booked
                            </button>
                        <?php else: ?>
                            <button class="btn-book" onclick="openBookingModal()">
                                <i class="fas fa-calendar-plus me-2"></i>Book This Room
                            </button>
                        <?php endif; ?>
                    <?php else: ?>
                        <button class="btn-book" disabled>
                            <i class="fas fa-times-circle me-2"></i>Students Only
                        </button>
                    <?php endif; ?>
                <?php else: ?>
                    <button class="btn-book" disabled>
                        <i class="fas fa-times-circle me-2"></i>Not Available
                    </button>
                <?php endif; ?>
            </div>

            <!-- Sidebar Info -->
            <div class="info-sidebar">
                <!-- Quick Info -->
                <div class="info-card">
                    <div class="card-title">
                        <i class="fas fa-info-circle"></i>Quick Information
                    </div>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-tag"></i></div>
                        <div class="info-content">
                            <div class="info-label">Room Type</div>
                            <div class="info-value"><?php echo ucfirst($room['type'] ?? 'Standard'); ?></div>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-layer-group"></i></div>
                        <div class="info-content">
                            <div class="info-label">Floor</div>
                            <div class="info-value">Floor <?php echo htmlspecialchars($room['floor']); ?></div>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-users"></i></div>
                        <div class="info-content">
                            <div class="info-label">Capacity</div>
                            <div class="info-value"><?php echo $room['capacity'] ?? 1; ?></div>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-rupee-sign"></i></div>
                        <div class="info-content">
                            <div class="info-label">Rent</div>
                            <div class="info-value">₹<?php echo number_format($room['rent'] ?? 0); ?>/month</div>
                        </div>
                    </div>
                    <?php if (!empty($room['notes'])): ?>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-sticky-note"></i></div>
                        <div class="info-content">
                            <div class="info-label">Notes</div>
                            <div class="info-value" style="font-size:0.75rem;"><?php echo htmlspecialchars($room['notes']); ?></div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Similar Rooms -->
                <?php if (!empty($similar_rooms)): ?>
                <div class="info-card">
                    <div class="card-title">
                        <i class="fas fa-door-open"></i>Similar Rooms Available
                    </div>
                    <?php foreach ($similar_rooms as $similar): ?>
                    <a href="room_details.php?id=<?php echo $similar['id']; ?>" class="similar-room-card">
                        <div>
                            <div class="similar-room-number">
                                Room <?php echo htmlspecialchars($similar['room_number']); ?>
                                <small>• Floor <?php echo htmlspecialchars($similar['floor']); ?></small>
                            </div>
                        </div>
                        <div>
                            <div class="similar-room-price">
                                ₹<?php echo number_format($similar['rent'] ?? 0); ?>
                                <small>/m</small>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Graceful Living — All rights reserved.</p>
        </footer>
    </div>

    <!-- Booking Modal -->
    <div class="modal fade" id="bookingModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">
                        <i class="fas fa-calendar-plus me-2"></i>Book Room <?php echo htmlspecialchars($room['room_number']); ?>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <div class="text-center mb-4">
                            <div style="width:80px;height:80px;background:rgba(139,92,246,0.1);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1rem;">
                                <i class="fas fa-bed" style="font-size:2rem;color:#8B5CF6;"></i>
                            </div>
                            <h5>Confirm Room Booking</h5>
                            <p style="color:var(--text-secondary);font-size:0.85rem;">
                                You are about to book <strong>Room <?php echo htmlspecialchars($room['room_number']); ?></strong>.
                                Please fill in the details below.
                            </p>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Move-in Date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="move_in_date" 
                                   min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Special Requirements</label>
                            <textarea class="form-control" name="special_requirements" rows="3" 
                                      placeholder="Any special requests or requirements..."></textarea>
                        </div>

                        <div style="background:rgba(255,255,255,0.03);border-radius:12px;padding:1rem;border:1px solid var(--glass-border);">
                            <div class="d-flex justify-content-between" style="padding:0.3rem 0;border-bottom:1px solid var(--glass-border);">
                                <span style="color:var(--text-muted);font-size:0.8rem;">Room Number</span>
                                <span style="font-weight:600;">Room <?php echo htmlspecialchars($room['room_number']); ?></span>
                            </div>
                            <div class="d-flex justify-content-between" style="padding:0.3rem 0;border-bottom:1px solid var(--glass-border);">
                                <span style="color:var(--text-muted);font-size:0.8rem;">Room Type</span>
                                <span style="font-weight:600;"><?php echo ucfirst($room['type'] ?? 'Standard'); ?></span>
                            </div>
                            <div class="d-flex justify-content-between" style="padding:0.3rem 0;">
                                <span style="color:var(--text-muted);font-size:0.8rem;">Rent</span>
                                <span style="font-weight:600;color:#10B981;">₹<?php echo number_format($room['rent'] ?? 0); ?>/month</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-0">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="book_room" class="btn btn-primary">
                            <i class="fas fa-check me-2"></i>Confirm Booking
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Ready to Leave?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-secondary" style="color: var(--text-secondary) !important;">
                    Select "Logout" below if you are ready to end your current session.
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Sidebar Toggle
        $('#sidebarToggle').on('click', function() {
            $('#sidebar').toggleClass('open');
        });

        // Close sidebar on outside click (mobile)
        $(document).on('click', function(e) {
            if ($(window).width() <= 768) {
                if (!$(e.target).closest('#sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
                    $('#sidebar').removeClass('open');
                }
            }
        });

        // Open Booking Modal
        function openBookingModal() {
            $('#bookingModal').modal('show');
        }
    </script>
</body>
</html>