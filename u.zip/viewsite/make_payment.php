<?php
session_start();
include 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$payment_id = $_GET['id'] ?? 0;
$payment = null;

if ($payment_id) {
    $stmt = $db->prepare("SELECT p.*, s.name as student_name FROM payments p 
                         JOIN students s ON p.student_id = s.id 
                         WHERE p.id = ?");
    $stmt->execute([$payment_id]);
    $payment = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (!$payment) {
    header("Location: payments.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make Payment - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Make Payment</h2>
        <div class="card mt-4">
            <div class="card-body">
                <h4>Payment Details</h4>
                <p><strong>Description:</strong> <?php echo htmlspecialchars($payment['description']); ?></p>
                <p><strong>Amount:</strong> ₹<?php echo number_format($payment['amount'], 2); ?></p>
                <p><strong>Due Date:</strong> <?php echo date('M j, Y', strtotime($payment['due_date'])); ?></p>
                
                <form>
                    <div class="mb-3">
                        <label class="form-label">Payment Method</label>
                        <select class="form-select" required>
                            <option value="">Select Payment Method</option>
                            <option value="online">Online Payment</option>
                            <option value="bank">Bank Transfer</option>
                            <option value="cash">Cash</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-success">Proceed to Pay</button>
                    <a href="payments.php" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>