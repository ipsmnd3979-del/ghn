
<?php
session_start();
include 'config/database.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'student') {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];
$success_message = $error_message = "";

// Get room details if room_id is provided
$room_id = $_GET['room_id'] ?? '';
$room_details = null;

if (!empty($room_id)) {
    try {
        $stmt = $db->prepare("SELECT * FROM rooms WHERE id = ? AND status = 'available'");
        $stmt->execute([$room_id]);
        $room_details = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$room_details) {
            $error_message = "Selected room is not available or doesn't exist.";
        }
    } catch (PDOException $e) {
        $error_message = "Error fetching room details: " . $e->getMessage();
    }
}

// Check if user already has an active booking
try {
    $check_booking_stmt = $db->prepare("
        SELECT id FROM students 
        WHERE user_id = ? AND status = 'active'
    ");
    $check_booking_stmt->execute([$user_id]);
    
    if ($check_booking_stmt->fetch()) {
        $error_message = "You already have an active room booking. Please contact administration for changes.";
    }
} catch (PDOException $e) {
    $error_message = "Error checking existing bookings: " . $e->getMessage();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register_booking'])) {
    $room_id = $_POST['room_id'];
    $enrollment_number = $_POST['enrollment_number'];
    $guardian_name = $_POST['guardian_name'];
    $guardian_phone = $_POST['guardian_phone'];
    $emergency_contact = $_POST['emergency_contact'];
    $address = $_POST['address'];
    $college_name = $_POST['college_name'];
    $course_name = $_POST['course_name'];
    $year_of_study = $_POST['year_of_study'];
    $check_in_date = $_POST['check_in_date'];
    $special_requests = $_POST['special_requests'];
    
    // Validate required fields
    if (empty($room_id) || empty($enrollment_number) || empty($guardian_name) || empty($emergency_contact)) {
        $error_message = "Please fill all required fields.";
    } else {
        try {
            // Start transaction
            $db->beginTransaction();
            
            // Check room availability again
            $check_room_stmt = $db->prepare("
                SELECT capacity, 
                       (SELECT COUNT(*) FROM students WHERE room_id = ? AND status = 'active') as current_occupants 
                FROM rooms 
                WHERE id = ? AND status = 'available'
            ");
            $check_room_stmt->execute([$room_id, $room_id]);
            $room_check = $check_room_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$room_check || $room_check['current_occupants'] >= $room_check['capacity']) {
                throw new Exception("Selected room is no longer available.");
            }
            
            // Insert into students table
            $student_stmt = $db->prepare("
                INSERT INTO students 
                (user_id, room_id, enrollment_number, guardian_name, guardian_phone, 
                 emergency_contact, address, college_name, course_name, year_of_study, 
                 check_in_date, status, deposit_status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', 'pending')
            ");
            $student_stmt->execute([
                $user_id, $room_id, $enrollment_number, $guardian_name, $guardian_phone,
                $emergency_contact, $address, $college_name, $course_name, $year_of_study,
                $check_in_date
            ]);
            
            $student_id = $db->lastInsertId();
            
            // Create booking record
            $booking_stmt = $db->prepare("
                INSERT INTO bookings 
                (user_id, room_id, check_in_date, status, total_amount, security_deposit, special_requests) 
                VALUES (?, ?, ?, 'confirmed', ?, 5000.00, ?)
            ");
            $booking_stmt->execute([
                $user_id, $room_id, $check_in_date, $room_details['rent'], $special_requests
            ]);
            
            $booking_id = $db->lastInsertId();
            
            // Update room status if it becomes full
            if (($room_check['current_occupants'] + 1) >= $room_check['capacity']) {
                $update_room_stmt = $db->prepare("UPDATE rooms SET status = 'occupied' WHERE id = ?");
                $update_room_stmt->execute([$room_id]);
            }
            
            // Create notification
            $notification_stmt = $db->prepare("
                INSERT INTO notifications (user_id, title, message, type, related_id, related_type) 
                VALUES (?, 'Booking Confirmed', 'Your room booking has been confirmed for Room {$room_details['room_number']}', 'booking', ?, 'booking')
            ");
            $notification_stmt->execute([$user_id, $booking_id]);
            
            // Commit transaction
            $db->commit();
            
            $success_message = "Room booking registered successfully! Welcome to Graceful Living Girls Hostel.";
            
        } catch (Exception $e) {
            $db->rollBack();
            $error_message = "Booking failed: " . $e->getMessage();
        }
    }
}

// Get available rooms for dropdown
$available_rooms = [];
try {
    $rooms_stmt = $db->query("
        SELECT r.*, 
               (r.capacity - (SELECT COUNT(*) FROM students s WHERE s.room_id = r.id AND s.status = 'active')) as available_spots
        FROM rooms r 
        WHERE r.status = 'available'
        AND (r.capacity - (SELECT COUNT(*) FROM students s WHERE s.room_id = r.id AND s.status = 'active')) > 0
        ORDER BY r.floor, r.room_number
    ");
    $available_rooms = $rooms_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_message = "Error fetching available rooms: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Your Room - Graceful Living Girls Hostel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #8a2be2;
            --primary-dark: #6a1cb0;
            --secondary: #ff69b4;
            --accent: #9370db;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
        }

        * {
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e6e6fa 100%);
            min-height: 100vh;
        }

        .booking-container {
            max-width: 1200px;
            margin: 2rem auto;
        }

        .booking-card {
            background: white;
            border-radius: 25px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 2rem;
        }

        .booking-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 2rem;
            text-align: center;
        }

        .booking-header h1 {
            margin: 0;
            font-size: 2.5rem;
            font-weight: 700;
        }

        .booking-header p {
            margin: 0.5rem 0 0 0;
            opacity: 0.9;
        }

        .booking-steps {
            display: flex;
            justify-content: space-between;
            padding: 2rem;
            background: var(--light);
            border-bottom: 1px solid #e5e7eb;
        }

        .step {
            text-align: center;
            flex: 1;
            position: relative;
        }

        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: white;
            border: 2px solid #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 0.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .step.active .step-number {
            background: var(--primary);
            border-color: var(--primary);
            color: white;
        }

        .step-label {
            font-size: 0.9rem;
            color: var(--dark);
            font-weight: 500;
        }

        .step.active .step-label {
            color: var(--primary);
        }

        .booking-content {
            padding: 2rem;
        }

        .room-summary {
            background: linear-gradient(135deg, var(--light) 0%, #f0f4ff 100%);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            border: 2px solid rgba(138, 43, 226, 0.1);
        }

        .form-section {
            margin-bottom: 2rem;
        }

        .section-title {
            color: var(--primary);
            border-bottom: 2px solid var(--primary);
            padding-bottom: 0.5rem;
            margin-bottom: 1.5rem;
            font-weight: 600;
        }

        .form-control, .form-select {
            border-radius: 12px;
            border: 2px solid #e5e7eb;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(138, 43, 226, 0.1);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--accent));
            border: none;
            border-radius: 12px;
            padding: 1rem 2rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(138, 43, 226, 0.3);
        }

        .alert {
            border-radius: 15px;
            border: none;
            padding: 1.5rem;
        }

        .alert-success {
            background: linear-gradient(135deg, var(--success), #34d399);
            color: white;
        }

        .alert-danger {
            background: linear-gradient(135deg, var(--danger), #f87171);
            color: white;
        }

        .info-card {
            background: var(--light);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--primary);
        }

        @media (max-width: 768px) {
            .booking-steps {
                flex-direction: column;
                gap: 1rem;
            }
            
            .booking-header h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>

    <div class="booking-container">
        <!-- Messages -->
        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <div class="d-flex align-items-center">
                    <i class="fas fa-check-circle me-3 fs-4"></i>
                    <div>
                        <h5 class="mb-1">Booking Successful!</h5>
                        <p class="mb-0"><?php echo $success_message; ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-danger">
                <div class="d-flex align-items-center">
                    <i class="fas fa-exclamation-circle me-3 fs-4"></i>
                    <div>
                        <h5 class="mb-1">Booking Error</h5>
                        <p class="mb-0"><?php echo $error_message; ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (empty($success_message) && empty($error_message)): ?>
        <div class="booking-card">
            <!-- Header -->
            <div class="booking-header">
                <h1><i class="fas fa-home me-3"></i>Book Your Room</h1>
                <p>Complete your hostel accommodation registration</p>
            </div>

            <!-- Booking Steps -->
            <div class="booking-steps">
                <div class="step active">
                    <div class="step-number">1</div>
                    <div class="step-label">Room Selection</div>
                </div>
                <div class="step active">
                    <div class="step-number">2</div>
                    <div class="step-label">Personal Details</div>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-label">Confirmation</div>
                </div>
            </div>

            <!-- Booking Content -->
            <div class="booking-content">
                <form method="POST" action="" id="bookingForm">
                    <!-- Room Selection -->
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-door-open me-2"></i>Room Selection</h3>
                        
                        <?php if ($room_details): ?>
                        <div class="room-summary">
                            <div class="row">
                                <div class="col-md-6">
                                    <h5>Selected Room</h5>
                                    <p class="mb-1"><strong>Room Number:</strong> <?php echo $room_details['room_number']; ?></p>
                                    <p class="mb-1"><strong>Floor:</strong> <?php echo $room_details['floor']; ?></p>
                                    <p class="mb-1"><strong>Type:</strong> <?php echo ucfirst($room_details['type']); ?> Sharing</p>
                                    <p class="mb-1"><strong>Capacity:</strong> <?php echo $room_details['capacity']; ?> students</p>
                                </div>
                                <div class="col-md-6">
                                    <h5>Pricing Details</h5>
                                    <h4 class="text-primary">₹<?php echo number_format($room_details['rent']); ?>/month</h4>
                                    <p class="mb-1"><strong>Security Deposit:</strong> ₹5,000</p>
                                    <p class="mb-0 text-success"><small><i class="fas fa-check-circle me-1"></i>Available for booking</small></p>
                                </div>
                            </div>
                            <input type="hidden" name="room_id" value="<?php echo $room_id; ?>">
                        </div>
                        <?php else: ?>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Select Room *</label>
                            <select class="form-select" name="room_id" required>
                                <option value="">Choose a room...</option>
                                <?php foreach ($available_rooms as $room): ?>
                                    <option value="<?php echo $room['id']; ?>" <?php echo $room_id == $room['id'] ? 'selected' : ''; ?>>
                                        Room <?php echo $room['room_number']; ?> - Floor <?php echo $room['floor']; ?> - 
                                        <?php echo ucfirst($room['type']); ?> Sharing - ₹<?php echo number_format($room['rent']); ?>/month
                                        (<?php echo $room['available_spots']; ?> spots available)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Personal Information -->
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-user me-2"></i>Personal Information</h3>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Enrollment Number *</label>
                                <input type="text" class="form-control" name="enrollment_number" required 
                                       placeholder="Enter your college enrollment number">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Check-in Date *</label>
                                <input type="date" class="form-control" name="check_in_date" required 
                                       min="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">College Name *</label>
                                <input type="text" class="form-control" name="college_name" required 
                                       placeholder="Enter your college name">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Course Name *</label>
                                <input type="text" class="form-control" name="course_name" required 
                                       placeholder="Enter your course name">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Year of Study *</label>
                                <select class="form-select" name="year_of_study" required>
                                    <option value="">Select year</option>
                                    <option value="1st Year">1st Year</option>
                                    <option value="2nd Year">2nd Year</option>
                                    <option value="3rd Year">3rd Year</option>
                                    <option value="4th Year">4th Year</option>
                                    <option value="Postgraduate">Postgraduate</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Emergency Contact *</label>
                                <input type="tel" class="form-control" name="emergency_contact" required 
                                       placeholder="Emergency contact number">
                            </div>
                        </div>
                    </div>

                    <!-- Guardian Information -->
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-users me-2"></i>Guardian Information</h3>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Guardian Name *</label>
                                <input type="text" class="form-control" name="guardian_name" required 
                                       placeholder="Enter guardian's full name">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Guardian Phone</label>
                                <input type="tel" class="form-control" name="guardian_phone" 
                                       placeholder="Guardian's phone number">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Permanent Address *</label>
                            <textarea class="form-control" name="address" rows="3" required 
                                      placeholder="Enter your permanent address"></textarea>
                        </div>
                    </div>

                    <!-- Additional Information -->
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-info-circle me-2"></i>Additional Information</h3>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Special Requests</label>
                            <textarea class="form-control" name="special_requests" rows="3" 
                                      placeholder="Any special requests or requirements..."></textarea>
                        </div>
                    </div>

                    <!-- Important Information -->
                    <div class="info-card">
                        <h5><i class="fas fa-exclamation-triangle me-2 text-warning"></i>Important Information</h5>
                        <ul class="mb-0">
                            <li>Security deposit of ₹5,000 is refundable upon checkout</li>
                            <li>Monthly rent must be paid by the 5th of each month</li>
                            <li>Minimum stay period: 3 months</li>
                            <li>Provide valid college ID and address proof during check-in</li>
                            <li>Cancellation policy: 15 days notice required</li>
                        </ul>
                    </div>

                    <!-- Submit Button -->
                    <div class="text-center">
                        <button type="submit" name="register_booking" class="btn btn-primary btn-lg">
                            <i class="fas fa-check-circle me-2"></i>Confirm Booking
                        </button>
                        <a href="viewrooms.php" class="btn btn-outline-secondary btn-lg ms-2">
                            <i class="fas fa-arrow-left me-2"></i>Back to Rooms
                        </a>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <!-- Success Actions -->
        <?php if ($success_message): ?>
            <div class="text-center mt-4">
                <a href="student_dashboard.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-tachometer-alt me-2"></i>Go to Dashboard
                </a>
                <a href="viewrooms.php" class="btn btn-outline-primary btn-lg ms-2">
                    <i class="fas fa-home me-2"></i>View More Rooms
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Form validation
            const form = document.getElementById('bookingForm');
            form.addEventListener('submit', function(e) {
                const checkInDate = new Date(document.querySelector('input[name="check_in_date"]').value);
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                
                if (checkInDate < today) {
                    e.preventDefault();
                    alert('Check-in date cannot be in the past.');
                    return false;
                }
            });

            // Auto-fill today's date as minimum for check-in
            const checkInField = document.querySelector('input[name="check_in_date"]');
            if (checkInField && !checkInField.value) {
                const tomorrow = new Date();
                tomorrow.setDate(tomorrow.getDate() + 1);
                checkInField.min = tomorrow.toISOString().split('T')[0];
            }
        });
    </script>
</body>
</html>
