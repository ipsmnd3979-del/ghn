<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user data from session
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'student';
$user_email = $_SESSION['user_email'] ?? '';

// Set page title based on user role
$page_title = ucfirst($user_role) . " Dashboard";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --gradient-2: linear-gradient(135deg, #3B82F6, #8B5CF6);
            --gradient-3: linear-gradient(135deg, #10B981, #34D399);
            --gradient-4: linear-gradient(135deg, #F59E0B, #FBBF24);
            --sidebar-width: 270px;
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Animated Background */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.15;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) {
            width: 600px;
            height: 600px;
            background: #8B5CF6;
            top: -200px;
            left: -200px;
            animation-delay: 0s;
        }

        .bg-orbs:nth-child(2) {
            width: 400px;
            height: 400px;
            background: #EC4899;
            bottom: -150px;
            right: -100px;
            animation-delay: -7s;
        }

        .bg-orbs:nth-child(3) {
            width: 300px;
            height: 300px;
            background: #3B82F6;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation-delay: -14s;
        }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: rgba(18, 18, 26, 0.92);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-right: 1px solid var(--glass-border);
            z-index: 1000;
            padding: 1.5rem 0;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 1.5rem;
            text-decoration: none;
        }

        .sidebar-brand .brand-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-1);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
            margin-right: 12px;
            box-shadow: 0 4px 16px rgba(139, 92, 246, 0.3);
            flex-shrink: 0;
        }

        .sidebar-brand .brand-text {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .sidebar-brand .brand-text span {
            color: #8B5CF6;
        }

        .sidebar-brand .brand-sub {
            display: block;
            font-size: 0.55rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 0 0.75rem;
        }

        .sidebar-nav::-webkit-scrollbar {
            width: 4px;
        }

        .sidebar-nav::-webkit-scrollbar-track {
            background: transparent;
        }

        .sidebar-nav::-webkit-scrollbar-thumb {
            background: rgba(139, 92, 246, 0.3);
            border-radius: 10px;
        }

        .nav-section-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--text-muted);
            padding: 0.75rem 1rem 0.5rem;
        }

        .nav-item {
            margin-bottom: 2px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
            font-weight: 500;
            position: relative;
        }

        .nav-link i {
            width: 1.6rem;
            font-size: 1rem;
            color: var(--text-muted);
            transition: all 0.3s ease;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(139, 92, 246, 0.12);
            color: var(--text-primary);
        }

        .nav-link:hover i, .nav-link.active i {
            color: #8B5CF6;
        }

        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 24px;
            background: var(--gradient-1);
            border-radius: 0 4px 4px 0;
        }

        .nav-link .badge-dot {
            margin-left: auto;
            width: 6px;
            height: 6px;
            background: #EC4899;
            border-radius: 50%;
            animation: pulse-dot 2s infinite;
        }

        @keyframes pulse-dot {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(0.8); }
        }

        .sidebar-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .sidebar-footer .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.6rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .sidebar-footer .user-card:hover {
            background: rgba(255, 255, 255, 0.06);
        }

        .sidebar-footer .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            color: white;
            flex-shrink: 0;
        }

        .sidebar-footer .user-info {
            flex: 1;
            min-width: 0;
        }

        .sidebar-footer .user-info .name {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .sidebar-footer .user-info .role {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: capitalize;
        }

        /* Main Content */
        #content-wrapper {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem 2rem;
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        /* Topbar */
        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1.5rem;
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .btn-toggle-sidebar {
            display: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-toggle-sidebar:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .page-title h1 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .page-title p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .topbar-btn {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            position: relative;
        }

        .topbar-btn:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .topbar-btn .notification-dot {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 6px;
            height: 6px;
            background: #EC4899;
            border-radius: 50%;
            border: 2px solid var(--bg-secondary);
        }

        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .topbar-user:hover {
            background: rgba(255, 255, 255, 0.08);
        }

        .topbar-user .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .topbar-user .user-name {
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        .topbar-user .user-role {
            font-size: 0.65rem;
            color: var(--text-muted);
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.25rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.25rem 1.5rem;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-4px);
            border-color: rgba(139, 92, 246, 0.2);
            box-shadow: var(--shadow-glow);
        }

        .stat-card .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            margin-bottom: 0.75rem;
        }

        .stat-card .stat-icon.purple {
            background: rgba(139, 92, 246, 0.15);
            color: #8B5CF6;
        }

        .stat-card .stat-icon.green {
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
        }

        .stat-card .stat-icon.yellow {
            background: rgba(245, 158, 11, 0.15);
            color: #F59E0B;
        }

        .stat-card .stat-icon.blue {
            background: rgba(59, 130, 246, 0.15);
            color: #3B82F6;
        }

        .stat-card .stat-label {
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-muted);
            margin-bottom: 0.25rem;
        }

        .stat-card .stat-value {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .stat-card .stat-change {
            font-size: 0.7rem;
            font-weight: 600;
            margin-top: 0.5rem;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 10px;
            border-radius: 50px;
        }

        .stat-card .stat-change.up {
            color: #10B981;
            background: rgba(16, 185, 129, 0.12);
        }

        .stat-card .stat-change.down {
            color: #EF4444;
            background: rgba(239, 68, 68, 0.12);
        }

        .stat-card .stat-glow {
            position: absolute;
            top: -50%;
            right: -20%;
            width: 150px;
            height: 150px;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.1;
            pointer-events: none;
        }

        .stat-card:nth-child(1) .stat-glow { background: #8B5CF6; }
        .stat-card:nth-child(2) .stat-glow { background: #10B981; }
        .stat-card:nth-child(3) .stat-glow { background: #F59E0B; }
        .stat-card:nth-child(4) .stat-glow { background: #3B82F6; }

        /* Charts Row */
        .charts-row {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .chart-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.5rem;
        }

        .chart-card .chart-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.25rem;
        }

        .chart-card .chart-title {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .chart-card .chart-subtitle {
            font-size: 0.7rem;
            color: var(--text-muted);
        }

        .chart-card .chart-body {
            height: 260px;
            position: relative;
        }

        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }

        .quick-action {
            padding: 1.5rem 1rem;
            border-radius: 16px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--glass-border);
            text-align: center;
            text-decoration: none;
            color: var(--text-secondary);
            transition: all 0.3s ease;
        }

        .quick-action:hover {
            background: rgba(255, 255, 255, 0.06);
            transform: translateY(-3px);
            color: var(--text-primary);
            border-color: rgba(139, 92, 246, 0.2);
        }

        .quick-action i {
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
            display: block;
        }

        .quick-action .action-label {
            font-size: 0.75rem;
            font-weight: 500;
        }

        .quick-action.purple i { color: #8B5CF6; }
        .quick-action.green i { color: #10B981; }
        .quick-action.yellow i { color: #F59E0B; }
        .quick-action.blue i { color: #3B82F6; }

        /* Recent Activity */
        .activity-item {
            display: flex;
            align-items: flex-start;
            gap: 14px;
            padding: 0.8rem 0;
            border-bottom: 1px solid var(--glass-border);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-item .activity-icon {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            flex-shrink: 0;
        }

        .activity-item .activity-icon.purple { background: rgba(139, 92, 246, 0.12); color: #8B5CF6; }
        .activity-item .activity-icon.green { background: rgba(16, 185, 129, 0.12); color: #10B981; }
        .activity-item .activity-icon.blue { background: rgba(59, 130, 246, 0.12); color: #3B82F6; }
        .activity-item .activity-icon.yellow { background: rgba(245, 158, 11, 0.12); color: #F59E0B; }

        .activity-item .activity-content {
            flex: 1;
            min-width: 0;
        }

        .activity-item .activity-text {
            font-size: 0.8rem;
            color: var(--text-secondary);
            line-height: 1.4;
        }

        .activity-item .activity-text strong {
            color: var(--text-primary);
        }

        .activity-item .activity-time {
            font-size: 0.65rem;
            color: var(--text-muted);
            margin-top: 2px;
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 1.5rem 0 0.5rem;
            border-top: 1px solid var(--glass-border);
            margin-top: 2rem;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .charts-row {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            #content-wrapper {
                margin-left: 0;
                padding: 1rem;
            }

            .btn-toggle-sidebar {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .topbar {
                padding: 0.5rem 1rem;
                border-radius: 16px;
            }

            .page-title h1 {
                font-size: 1rem;
            }

            .page-title p {
                font-size: 0.7rem;
            }

            .topbar-user .user-name,
            .topbar-user .user-role {
                display: none;
            }

            .stats-grid {
                grid-template-columns: 1fr 1fr;
                gap: 0.75rem;
            }

            .stat-card {
                padding: 1rem;
            }

            .stat-card .stat-value {
                font-size: 1.2rem;
            }

            .quick-actions {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }

            .quick-actions {
                grid-template-columns: 1fr;
            }
        }

        /* Dark scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg-primary);
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(139, 92, 246, 0.3);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: rgba(139, 92, 246, 0.5);
        }

        /* Modal Override */
        .modal-content {
            background: var(--bg-secondary);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
        }

        .modal-header, .modal-footer {
            border-color: var(--glass-border);
        }

        .modal-title {
            color: var(--text-primary);
        }

        .btn-close {
            filter: invert(1) brightness(2);
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
        }

        .btn-primary {
            background: var(--gradient-1);
            border: none;
            color: white;
        }

        .btn-primary:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <a href="indexview.php" class="sidebar-brand">
            <div class="brand-icon">
                <i class="fas fa-home"></i>
            </div>
            <div>
                <div class="brand-text">Graceful<span>Living</span></div>
                <span class="brand-sub">Management System</span>
            </div>
        </a>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Main</div>
            <div class="nav-item">
                <a href="indexview.php" class="nav-link active">
                    <i class="fas fa-th-large"></i>
                    Dashboard
                </a>
            </div>

            <div class="nav-section-label">Management</div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    My Profile
                </a>
            </div>
            <?php if ($user_role === 'admin' || $user_role === 'staff'): ?>
            <div class="nav-item">
                <a href="students.php" class="nav-link">
                    <i class="fas fa-users"></i>
                    Students
                    <span class="badge-dot"></span>
                </a>
            </div>
            <?php endif; ?>
            <div class="nav-item">
                <a href="rooms.php" class="nav-link">
                    <i class="fas fa-bed"></i>
                    Rooms
                </a>
            </div>
            <div class="nav-item">
                <a href="payments.php" class="nav-link">
                    <i class="fas fa-credit-card"></i>
                    Payments
                </a>
            </div>

            <?php if ($user_role === 'admin'): ?>
            <div class="nav-section-label">Administration</div>
            <div class="nav-item">
                <a href="staff.php" class="nav-link">
                    <i class="fas fa-user-tie"></i>
                    Staff Management
                </a>
            </div>
            <div class="nav-item">
                <a href="reports.php" class="nav-link">
                    <i class="fas fa-chart-bar"></i>
                    Reports
                </a>
            </div>
            <?php endif; ?>

            <div class="nav-section-label">Account</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i>
                    Settings
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </nav>

        <div class="sidebar-footer">
            <a href="profile.php" class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($user_name); ?></div>
                    <div class="role"><?php echo htmlspecialchars($user_role); ?></div>
                </div>
                <i class="fas fa-ellipsis-v" style="color: var(--text-muted); font-size: 0.7rem;"></i>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div id="content-wrapper">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left">
                <button class="btn-toggle-sidebar" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Dashboard</h1>
                    <p>Welcome back, <?php echo htmlspecialchars($user_name); ?> 👋</p>
                </div>
            </div>
            <div class="topbar-right">
                <button class="topbar-btn" title="Notifications">
                    <i class="fas fa-bell"></i>
                    <span class="notification-dot"></span>
                </button>
                <button class="topbar-btn" title="Messages">
                    <i class="fas fa-envelope"></i>
                </button>
                <a href="profile.php" class="topbar-user">
                    <div class="avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                    <div>
                        <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
                        <div class="user-role"><?php echo htmlspecialchars($user_role); ?></div>
                    </div>
                </a>
            </div>
        </header>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-glow"></div>
                <div class="stat-icon purple">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-label">Total Students</div>
                <div class="stat-value">0</div>
                <div class="stat-change up">
                    <i class="fas fa-arrow-up"></i> 0%
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-glow"></div>
                <div class="stat-icon green">
                    <i class="fas fa-bed"></i>
                </div>
                <div class="stat-label">Available Rooms</div>
                <div class="stat-value">0</div>
                <div class="stat-change up">
                    <i class="fas fa-arrow-up"></i> 0%
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-glow"></div>
                <div class="stat-icon yellow">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-label">Pending Requests</div>
                <div class="stat-value">0</div>
                <div class="stat-change down">
                    <i class="fas fa-arrow-down"></i> 0%
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-glow"></div>
                <div class="stat-icon blue">
                    <i class="fas fa-rupee-sign"></i>
                </div>
                <div class="stat-label">Total Revenue</div>
                <div class="stat-value">₹0</div>
                <div class="stat-change up">
                    <i class="fas fa-arrow-up"></i> 0%
                </div>
            </div>
        </div>

        <!-- Charts -->
        <div class="charts-row">
            <div class="chart-card">
                <div class="chart-header">
                    <div>
                        <div class="chart-title">Revenue Overview</div>
                        <div class="chart-subtitle">Monthly earnings trend</div>
                    </div>
                    <span style="font-size:0.7rem; color: var(--text-muted);">
                        <i class="fas fa-calendar-alt"></i> 2026
                    </span>
                </div>
                <div class="chart-body">
                    <canvas id="myAreaChart"></canvas>
                </div>
            </div>
            <div class="chart-card">
                <div class="chart-header">
                    <div>
                        <div class="chart-title">Room Occupancy</div>
                        <div class="chart-subtitle">Current distribution</div>
                    </div>
                </div>
                <div class="chart-body">
                    <canvas id="myPieChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Bottom Row -->
        <div class="row g-4">
            <!-- Recent Activity -->
            <div class="col-lg-6">
                <div class="chart-card" style="height:100%;">
                    <div class="chart-header">
                        <div>
                            <div class="chart-title">Recent Activity</div>
                            <div class="chart-subtitle">Latest updates from your hostel</div>
                        </div>
                        <a href="#" style="font-size:0.7rem; color: #8B5CF6; text-decoration:none;">View All</a>
                    </div>
                    <div>
                        <div class="activity-item">
                            <div class="activity-icon purple">
                                <i class="fas fa-user-plus"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-text"><strong>New student</strong> registered for Room 204</div>
                                <div class="activity-time"><i class="far fa-clock me-1"></i> 2 hours ago</div>
                            </div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-icon green">
                                <i class="fas fa-credit-card"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-text"><strong>Payment received</strong> ₹15,000 from Aisha Sharma</div>
                                <div class="activity-time"><i class="far fa-clock me-1"></i> 5 hours ago</div>
                            </div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-icon blue">
                                <i class="fas fa-tools"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-text"><strong>Maintenance</strong> request resolved for Room 312</div>
                                <div class="activity-time"><i class="far fa-clock me-1"></i> Yesterday</div>
                            </div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-icon yellow">
                                <i class="fas fa-bullhorn"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-text"><strong>Notice posted:</strong> "Cultural Night - This Friday"</div>
                                <div class="activity-time"><i class="far fa-clock me-1"></i> Yesterday</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="col-lg-6">
                <div class="chart-card" style="height:100%;">
                    <div class="chart-header">
                        <div>
                            <div class="chart-title">Quick Actions</div>
                            <div class="chart-subtitle">Frequently used tools</div>
                        </div>
                    </div>
                    <div class="quick-actions">
                        <a href="pay-fees.php" class="quick-action purple">
                            <i class="fas fa-credit-card"></i>
                            <span class="action-label">Pay Fees</span>
                        </a>
                        <a href="submit-complaint.php" class="quick-action yellow">
                            <i class="fas fa-exclamation-triangle"></i>
                            <span class="action-label">Complaint</span>
                        </a>
                        <a href="book-facility.php" class="quick-action green">
                            <i class="fas fa-calendar-alt"></i>
                            <span class="action-label">Book Facility</span>
                        </a>
                        <a href="view-notices.php" class="quick-action blue">
                            <i class="fas fa-bullhorn"></i>
                            <span class="action-label">View Notices</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Graceful Living — All rights reserved.</p>
        </footer>
    </div>

    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Ready to Leave?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-secondary" style="color: var(--text-secondary) !important;">
                    Select "Logout" below if you are ready to end your current session.
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        // Sidebar Toggle
        $('#sidebarToggle').on('click', function() {
            $('#sidebar').toggleClass('open');
        });

        // Close sidebar on outside click (mobile)
        $(document).on('click', function(e) {
            if ($(window).width() <= 768) {
                if (!$(e.target).closest('#sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
                    $('#sidebar').removeClass('open');
                }
            }
        });

        // Area Chart
        const ctx1 = document.getElementById('myAreaChart').getContext('2d');
        new Chart(ctx1, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Revenue',
                    data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                    borderColor: '#8B5CF6',
                    backgroundColor: 'rgba(139, 92, 246, 0.08)',
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#8B5CF6',
                    pointBorderColor: '#8B5CF6',
                    pointRadius: 3,
                    pointHoverRadius: 6,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(18,18,26,0.9)',
                        titleColor: '#fff',
                        bodyColor: 'rgba(255,255,255,0.7)',
                        borderColor: 'rgba(255,255,255,0.05)',
                        borderWidth: 1,
                        cornerRadius: 12,
                        padding: 12,
                    }
                },
                scales: {
                    x: {
                        grid: { color: 'rgba(255,255,255,0.03)', drawBorder: false },
                        ticks: { color: 'rgba(255,255,255,0.3)', font: { size: 10 } }
                    },
                    y: {
                        grid: { color: 'rgba(255,255,255,0.03)', drawBorder: false },
                        ticks: { 
                            color: 'rgba(255,255,255,0.3)', 
                            font: { size: 10 },
                            callback: function(value) { return '₹' + value; }
                        }
                    }
                }
            }
        });

        // Pie Chart
        const ctx2 = document.getElementById('myPieChart').getContext('2d');
        new Chart(ctx2, {
            type: 'doughnut',
            data: {
                labels: ['Occupied', 'Available', 'Maintenance'],
                datasets: [{
                    data: [0, 0, 0],
                    backgroundColor: ['#8B5CF6', '#10B981', '#F59E0B'],
                    borderWidth: 0,
                    hoverOffset: 8,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '75%',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(18,18,26,0.9)',
                        titleColor: '#fff',
                        bodyColor: 'rgba(255,255,255,0.7)',
                        borderColor: 'rgba(255,255,255,0.05)',
                        borderWidth: 1,
                        cornerRadius: 12,
                        padding: 12,
                    }
                }
            }
        });
    </script>
</body>
</html>