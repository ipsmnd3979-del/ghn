<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user data from session
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'student';
$user_email = $_SESSION['user_email'] ?? '';

// Mock user data - In real application, fetch from database
$user_data = [
    'full_name' => $user_name,
    'email' => $user_email,
    'phone' => '+91 98765 43210',
    'address' => '123, Hostel Street, City, State - 123456',
    'student_id' => 'STU' . rand(1000, 9999),
    'room_number' => '204',
    'date_of_birth' => '2000-01-15',
    'gender' => 'Female',
    'guardian_name' => 'Parent Name',
    'guardian_phone' => '+91 98765 43211',
    'guardian_relation' => 'Father',
    'joined_date' => '2025-06-01',
    'status' => 'Active',
    'profile_image' => null,
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --gradient-2: linear-gradient(135deg, #3B82F6, #8B5CF6);
            --gradient-3: linear-gradient(135deg, #10B981, #34D399);
            --gradient-4: linear-gradient(135deg, #F59E0B, #FBBF24);
            --sidebar-width: 270px;
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Animated Background */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) {
            width: 600px;
            height: 600px;
            background: #8B5CF6;
            top: -200px;
            left: -200px;
            animation-delay: 0s;
        }

        .bg-orbs:nth-child(2) {
            width: 400px;
            height: 400px;
            background: #EC4899;
            bottom: -150px;
            right: -100px;
            animation-delay: -7s;
        }

        .bg-orbs:nth-child(3) {
            width: 300px;
            height: 300px;
            background: #3B82F6;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation-delay: -14s;
        }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: rgba(18, 18, 26, 0.92);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-right: 1px solid var(--glass-border);
            z-index: 1000;
            padding: 1.5rem 0;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 1.5rem;
            text-decoration: none;
        }

        .sidebar-brand .brand-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-1);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
            margin-right: 12px;
            box-shadow: 0 4px 16px rgba(139, 92, 246, 0.3);
            flex-shrink: 0;
        }

        .sidebar-brand .brand-text {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .sidebar-brand .brand-text span {
            color: #8B5CF6;
        }

        .sidebar-brand .brand-sub {
            display: block;
            font-size: 0.55rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 0 0.75rem;
        }

        .sidebar-nav::-webkit-scrollbar {
            width: 4px;
        }

        .sidebar-nav::-webkit-scrollbar-track {
            background: transparent;
        }

        .sidebar-nav::-webkit-scrollbar-thumb {
            background: rgba(139, 92, 246, 0.3);
            border-radius: 10px;
        }

        .nav-section-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--text-muted);
            padding: 0.75rem 1rem 0.5rem;
        }

        .nav-item {
            margin-bottom: 2px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
            font-weight: 500;
            position: relative;
        }

        .nav-link i {
            width: 1.6rem;
            font-size: 1rem;
            color: var(--text-muted);
            transition: all 0.3s ease;
        }

        .nav-link:hover, .nav-link.active {
            background: rgba(139, 92, 246, 0.12);
            color: var(--text-primary);
        }

        .nav-link:hover i, .nav-link.active i {
            color: #8B5CF6;
        }

        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 24px;
            background: var(--gradient-1);
            border-radius: 0 4px 4px 0;
        }

        .sidebar-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .sidebar-footer .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.6rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .sidebar-footer .user-card:hover {
            background: rgba(255, 255, 255, 0.06);
        }

        .sidebar-footer .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            color: white;
            flex-shrink: 0;
        }

        .sidebar-footer .user-info {
            flex: 1;
            min-width: 0;
        }

        .sidebar-footer .user-info .name {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .sidebar-footer .user-info .role {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: capitalize;
        }

        /* Main Content */
        #content-wrapper {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem 2rem;
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        /* Topbar */
        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1.5rem;
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .btn-toggle-sidebar {
            display: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-toggle-sidebar:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .page-title h1 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .page-title p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .topbar-user:hover {
            background: rgba(255, 255, 255, 0.08);
        }

        .topbar-user .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .topbar-user .user-name {
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        .topbar-user .user-role {
            font-size: 0.65rem;
            color: var(--text-muted);
        }

        /* Profile Content */
        .profile-grid {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 1.5rem;
        }

        /* Profile Card */
        .profile-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 2rem 1.5rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .profile-card .card-glow {
            position: absolute;
            top: -50%;
            left: 50%;
            transform: translateX(-50%);
            width: 200px;
            height: 200px;
            background: radial-gradient(circle, rgba(139, 92, 246, 0.1), transparent);
            border-radius: 50%;
            pointer-events: none;
        }

        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            font-weight: 700;
            color: white;
            margin: 0 auto 1rem;
            position: relative;
            box-shadow: 0 8px 32px rgba(139, 92, 246, 0.3);
        }

        .profile-avatar .status-badge {
            position: absolute;
            bottom: 4px;
            right: 4px;
            width: 16px;
            height: 16px;
            background: #10B981;
            border-radius: 50%;
            border: 3px solid var(--bg-secondary);
        }

        .profile-card .profile-name {
            font-size: 1.2rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .profile-card .profile-role {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }

        .profile-card .profile-id {
            font-size: 0.7rem;
            color: var(--text-muted);
            background: rgba(255, 255, 255, 0.04);
            padding: 0.25rem 1rem;
            border-radius: 50px;
            display: inline-block;
            margin-bottom: 1.5rem;
        }

        .profile-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.75rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid var(--glass-border);
        }

        .profile-stat {
            text-align: center;
        }

        .profile-stat .stat-value {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .profile-stat .stat-label {
            font-size: 0.6rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .profile-actions {
            display: flex;
            gap: 0.5rem;
            margin-top: 1.5rem;
        }

        .profile-actions .btn {
            flex: 1;
            padding: 0.6rem;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary-glass {
            background: var(--gradient-1);
            border: none;
            color: white;
        }

        .btn-primary-glass:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        .btn-secondary-glass {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
        }

        .btn-secondary-glass:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
        }

        /* Details Card */
        .details-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.5rem;
        }

        .details-card .card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.5rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px solid var(--glass-border);
        }

        .details-card .card-title {
            font-size: 1rem;
            font-weight: 600;
        }

        .details-card .card-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .details-card .edit-btn {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            padding: 0.3rem 0.8rem;
            border-radius: 8px;
            font-size: 0.7rem;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .details-card .edit-btn:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        .detail-item {
            padding: 0.75rem 1rem;
            background: rgba(255, 255, 255, 0.02);
            border-radius: 12px;
            border: 1px solid var(--glass-border);
        }

        .detail-item .detail-label {
            font-size: 0.6rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-muted);
            margin-bottom: 0.25rem;
        }

        .detail-item .detail-value {
            font-size: 0.9rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        .detail-item .detail-value .badge-status {
            font-size: 0.65rem;
            padding: 0.15rem 0.6rem;
            border-radius: 50px;
            font-weight: 500;
        }

        .badge-status.active {
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
        }

        .badge-status.inactive {
            background: rgba(239, 68, 68, 0.15);
            color: #EF4444;
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 1.5rem 0 0.5rem;
            border-top: 1px solid var(--glass-border);
            margin-top: 2rem;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .profile-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            #content-wrapper {
                margin-left: 0;
                padding: 1rem;
            }

            .btn-toggle-sidebar {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .topbar {
                padding: 0.5rem 1rem;
                border-radius: 16px;
            }

            .page-title h1 {
                font-size: 1rem;
            }

            .page-title p {
                font-size: 0.7rem;
            }

            .topbar-user .user-name,
            .topbar-user .user-role {
                display: none;
            }

            .details-grid {
                grid-template-columns: 1fr;
            }

            .profile-avatar {
                width: 80px;
                height: 80px;
                font-size: 2rem;
            }
        }

        @media (max-width: 480px) {
            .profile-stats {
                grid-template-columns: 1fr 1fr;
            }

            .profile-actions {
                flex-direction: column;
            }
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg-primary);
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(139, 92, 246, 0.3);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: rgba(139, 92, 246, 0.5);
        }

        /* Modal Override */
        .modal-content {
            background: var(--bg-secondary);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
        }

        .modal-header, .modal-footer {
            border-color: var(--glass-border);
        }

        .modal-title {
            color: var(--text-primary);
        }

        .btn-close {
            filter: invert(1) brightness(2);
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
        }

        .btn-primary {
            background: var(--gradient-1);
            border: none;
            color: white;
        }

        .btn-primary:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <a href="indexview.php" class="sidebar-brand">
            <div class="brand-icon">
                <i class="fas fa-home"></i>
            </div>
            <div>
                <div class="brand-text">Graceful<span>Living</span></div>
                <span class="brand-sub">Management System</span>
            </div>
        </a>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Main</div>
            <div class="nav-item">
                <a href="indexview.php" class="nav-link">
                    <i class="fas fa-th-large"></i>
                    Dashboard
                </a>
            </div>

            <div class="nav-section-label">Management</div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link active">
                    <i class="fas fa-user"></i>
                    My Profile
                </a>
            </div>
            <?php if ($user_role === 'admin' || $user_role === 'staff'): ?>
            <div class="nav-item">
                <a href="students.php" class="nav-link">
                    <i class="fas fa-users"></i>
                    Students
                </a>
            </div>
            <?php endif; ?>
            <div class="nav-item">
                <a href="viewrooms.php" class="nav-link">
                    <i class="fas fa-bed"></i>
                    Rooms
                </a>
            </div>
            <div class="nav-item">
                <a href="payments.php" class="nav-link">
                    <i class="fas fa-credit-card"></i>
                    Payments
                </a>
            </div>

            <?php if ($user_role === 'admin'): ?>
            <div class="nav-section-label">Administration</div>
            <div class="nav-item">
                <a href="staff.php" class="nav-link">
                    <i class="fas fa-user-tie"></i>
                    Staff Management
                </a>
            </div>
            <div class="nav-item">
                <a href="reports.php" class="nav-link">
                    <i class="fas fa-chart-bar"></i>
                    Reports
                </a>
            </div>
            <?php endif; ?>

            <div class="nav-section-label">Account</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i>
                    Settings
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </nav>

        <div class="sidebar-footer">
            <a href="profile.php" class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($user_name); ?></div>
                    <div class="role"><?php echo htmlspecialchars($user_role); ?></div>
                </div>
                <i class="fas fa-ellipsis-v" style="color: var(--text-muted); font-size: 0.7rem;"></i>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div id="content-wrapper">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left">
                <button class="btn-toggle-sidebar" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>My Profile</h1>
                    <p>View and manage your personal information</p>
                </div>
            </div>
            <div class="topbar-right">
                <a href="settings.php" class="topbar-user">
                    <div class="avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                    <div>
                        <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
                        <div class="user-role"><?php echo htmlspecialchars($user_role); ?></div>
                    </div>
                </a>
            </div>
        </header>

        <!-- Profile Content -->
        <div class="profile-grid">
            <!-- Left Column - Profile Card -->
            <div class="profile-card">
                <div class="card-glow"></div>
                <div class="profile-avatar">
                    <?php echo strtoupper(substr($user_data['full_name'], 0, 2)); ?>
                    <span class="status-badge"></span>
                </div>
                <h3 class="profile-name"><?php echo htmlspecialchars($user_data['full_name']); ?></h3>
                <p class="profile-role"><?php echo ucfirst(htmlspecialchars($user_role)); ?></p>
                <span class="profile-id">
                    <i class="far fa-id-card me-1"></i>
                    <?php echo htmlspecialchars($user_data['student_id']); ?>
                </span>

                <div class="profile-stats">
                    <div class="profile-stat">
                        <div class="stat-value"><?php echo htmlspecialchars($user_data['room_number']); ?></div>
                        <div class="stat-label">Room</div>
                    </div>
                    <div class="profile-stat">
                        <div class="stat-value"><?php echo htmlspecialchars($user_data['joined_date']); ?></div>
                        <div class="stat-label">Joined</div>
                    </div>
                </div>

                <div class="profile-actions">
                    <a href="#editProfile" class="btn btn-primary-glass" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                        <i class="fas fa-edit me-2"></i>Edit
                    </a>
                    <a href="settings.php" class="btn btn-secondary-glass">
                        <i class="fas fa-cog me-2"></i>Settings
                    </a>
                </div>
            </div>

            <!-- Right Column - Details -->
            <div>
                <!-- Personal Information -->
                <div class="details-card mb-3">
                    <div class="card-header">
                        <div class="card-title">
                            <i class="fas fa-user-circle"></i>Personal Information
                        </div>
                        <a href="#editProfile" class="edit-btn" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                            <i class="fas fa-pen me-1"></i>Edit
                        </a>
                    </div>
                    <div class="details-grid">
                        <div class="detail-item">
                            <div class="detail-label">Full Name</div>
                            <div class="detail-value"><?php echo htmlspecialchars($user_data['full_name']); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Email Address</div>
                            <div class="detail-value" style="font-size:0.8rem;"><?php echo htmlspecialchars($user_data['email']); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Phone Number</div>
                            <div class="detail-value"><?php echo htmlspecialchars($user_data['phone']); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Date of Birth</div>
                            <div class="detail-value"><?php echo htmlspecialchars($user_data['date_of_birth']); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Gender</div>
                            <div class="detail-value"><?php echo htmlspecialchars($user_data['gender']); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Status</div>
                            <div class="detail-value">
                                <span class="badge-status <?php echo strtolower($user_data['status']); ?>">
                                    <?php echo htmlspecialchars($user_data['status']); ?>
                                </span>
                            </div>
                        </div>
                        <div class="detail-item" style="grid-column: 1 / -1;">
                            <div class="detail-label">Address</div>
                            <div class="detail-value" style="font-size:0.85rem;"><?php echo htmlspecialchars($user_data['address']); ?></div>
                        </div>
                    </div>
                </div>

                <!-- Guardian Information -->
                <div class="details-card">
                    <div class="card-header">
                        <div class="card-title">
                            <i class="fas fa-user-friends"></i>Guardian Information
                        </div>
                        <a href="#editProfile" class="edit-btn" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                            <i class="fas fa-pen me-1"></i>Edit
                        </a>
                    </div>
                    <div class="details-grid">
                        <div class="detail-item">
                            <div class="detail-label">Guardian Name</div>
                            <div class="detail-value"><?php echo htmlspecialchars($user_data['guardian_name']); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Relation</div>
                            <div class="detail-value"><?php echo htmlspecialchars($user_data['guardian_relation']); ?></div>
                        </div>
                        <div class="detail-item" style="grid-column: 1 / -1;">
                            <div class="detail-label">Guardian Phone</div>
                            <div class="detail-value"><?php echo htmlspecialchars($user_data['guardian_phone']); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Graceful Living — All rights reserved.</p>
        </footer>
    </div>

    <!-- Edit Profile Modal -->
    <div class="modal fade" id="editProfileModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">
                        <i class="fas fa-edit me-2" style="color:#8B5CF6;"></i>Edit Profile
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label" style="color: var(--text-secondary); font-size:0.8rem;">Full Name</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($user_data['full_name']); ?>" style="background: rgba(255,255,255,0.04); border: 1px solid var(--glass-border); color: white; border-radius: 12px; padding: 0.7rem 1rem;">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" style="color: var(--text-secondary); font-size:0.8rem;">Email Address</label>
                                <input type="email" class="form-control" value="<?php echo htmlspecialchars($user_data['email']); ?>" style="background: rgba(255,255,255,0.04); border: 1px solid var(--glass-border); color: white; border-radius: 12px; padding: 0.7rem 1rem;">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" style="color: var(--text-secondary); font-size:0.8rem;">Phone Number</label>
                                <input type="tel" class="form-control" value="<?php echo htmlspecialchars($user_data['phone']); ?>" style="background: rgba(255,255,255,0.04); border: 1px solid var(--glass-border); color: white; border-radius: 12px; padding: 0.7rem 1rem;">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" style="color: var(--text-secondary); font-size:0.8rem;">Date of Birth</label>
                                <input type="date" class="form-control" value="<?php echo htmlspecialchars($user_data['date_of_birth']); ?>" style="background: rgba(255,255,255,0.04); border: 1px solid var(--glass-border); color: white; border-radius: 12px; padding: 0.7rem 1rem;">
                            </div>
                            <div class="col-md-12">
                                <label class="form-label" style="color: var(--text-secondary); font-size:0.8rem;">Address</label>
                                <textarea class="form-control" rows="2" style="background: rgba(255,255,255,0.04); border: 1px solid var(--glass-border); color: white; border-radius: 12px; padding: 0.7rem 1rem;"><?php echo htmlspecialchars($user_data['address']); ?></textarea>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" style="color: var(--text-secondary); font-size:0.8rem;">Guardian Name</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($user_data['guardian_name']); ?>" style="background: rgba(255,255,255,0.04); border: 1px solid var(--glass-border); color: white; border-radius: 12px; padding: 0.7rem 1rem;">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" style="color: var(--text-secondary); font-size:0.8rem;">Guardian Phone</label>
                                <input type="tel" class="form-control" value="<?php echo htmlspecialchars($user_data['guardian_phone']); ?>" style="background: rgba(255,255,255,0.04); border: 1px solid var(--glass-border); color: white; border-radius: 12px; padding: 0.7rem 1rem;">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" style="color: var(--text-secondary); font-size:0.8rem;">Relation</label>
                                <select class="form-select" style="background: rgba(255,255,255,0.04); border: 1px solid var(--glass-border); color: white; border-radius: 12px; padding: 0.7rem 1rem;">
                                    <option value="Father" <?php echo $user_data['guardian_relation'] == 'Father' ? 'selected' : ''; ?>>Father</option>
                                    <option value="Mother" <?php echo $user_data['guardian_relation'] == 'Mother' ? 'selected' : ''; ?>>Mother</option>
                                    <option value="Brother" <?php echo $user_data['guardian_relation'] == 'Brother' ? 'selected' : ''; ?>>Brother</option>
                                    <option value="Sister" <?php echo $user_data['guardian_relation'] == 'Sister' ? 'selected' : ''; ?>>Sister</option>
                                    <option value="Uncle" <?php echo $user_data['guardian_relation'] == 'Uncle' ? 'selected' : ''; ?>>Uncle</option>
                                    <option value="Aunt" <?php echo $user_data['guardian_relation'] == 'Aunt' ? 'selected' : ''; ?>>Aunt</option>
                                    <option value="Other" <?php echo $user_data['guardian_relation'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary" onclick="alert('Profile updated successfully!')">
                        <i class="fas fa-save me-2"></i>Save Changes
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Ready to Leave?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-secondary" style="color: var(--text-secondary) !important;">
                    Select "Logout" below if you are ready to end your current session.
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Sidebar Toggle
        $('#sidebarToggle').on('click', function() {
            $('#sidebar').toggleClass('open');
        });

        // Close sidebar on outside click (mobile)
        $(document).on('click', function(e) {
            if ($(window).width() <= 768) {
                if (!$(e.target).closest('#sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
                    $('#sidebar').removeClass('open');
                }
            }
        });
    </script>
</body>
</html>