<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms & Conditions - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Terms and Conditions</h2>
        <div class="card mt-4">
            <div class="card-body">
                <h4>Hostel Accommodation Agreement</h4>
                
                <h5 class="mt-4">1. Eligibility</h5>
                <p>Only bonafide female students are eligible for hostel accommodation.</p>
                
                <h5>2. Duration of Stay</h5>
                <p>Accommodation is provided for the academic year. Students must vacate during vacation periods unless special permission is obtained.</p>
                
                <h5>3. Fees and Payments</h5>
                <ul>
                    <li>Hostel fees must be paid in advance</li>
                    <li>Security deposit is refundable after deduction of any damages</li>
                    <li>No refund for partial months</li>
                </ul>
                
                <h5>4. Rules and Regulations</h5>
                <ul>
                    <li>Strict adherence to hostel timings</li>
                    <li>No unauthorized guests allowed in rooms</li>
                    <li>Proper maintenance of room and common areas</li>
                    <li>Compliance with all security protocols</li>
                </ul>
                
                <h5>5. Termination</h5>
                <p>The management reserves the right to terminate accommodation for violation of rules.</p>
                
                <a href="book_room.php" class="btn btn-primary mt-3">Back to Booking</a>
            </div>
        </div>
    </div>
</body>
</html>