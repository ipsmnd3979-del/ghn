
    <!-- Footer -->
    <footer class="bg-dark text-white mt-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5 class="mb-3">
                        <i class="fas fa-home me-2"></i>Graceful Living
                    </h5>
                    <p class="text-light">A safe and comfortable home away from home for female students. Experience the perfect blend of comfort, security, and community.</p>
                    <div class="social-links">
                        <a href="#" class="text-light me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-light me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-light"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 mb-4">
                    <h6 class="mb-3">Quick Links</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="indexview.php" class="text-light text-decoration-none">Home</a></li>
                        <li class="mb-2"><a href="viewrooms.php" class="text-light text-decoration-none">Rooms</a></li>
                        <li class="mb-2"><a href="booking.php" class="text-light text-decoration-none">Bookings</a></li>
                        <li class="mb-2"><a href="payments.php" class="text-light text-decoration-none">Payments</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <h6 class="mb-3">Contact Info</h6>
                    <ul class="list-unstyled text-light">
                        <li class="mb-2">
                            <i class="fas fa-map-marker-alt me-2"></i>
                            123 Hostel Road, City
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-phone me-2"></i>
                            +91 98765 43210
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-envelope me-2"></i>
                            info@gracefulliving.com
                        </li>
                    </ul>
                </div>
                <div class="col-lg-3 mb-4">
                    <h6 class="mb-3">Emergency Contacts</h6>
                    <ul class="list-unstyled text-light">
                        <li class="mb-2">Warden: +91 98765 43211</li>
                        <li class="mb-2">Security: +91 98765 43212</li>
                        <li class="mb-2">Ambulance: 102</li>
                        <li class="mb-2">Police: 100</li>
                    </ul>
                </div>
            </div>
            <hr class="bg-light">
            <div class="text-center pt-3">
                <p class="mb-0">&copy; 2024 Graceful Living Girls Hostel. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>