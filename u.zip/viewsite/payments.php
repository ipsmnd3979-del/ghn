<?php
session_start();
include '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get user data from session
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'student';
$user_email = $_SESSION['user_email'] ?? '';
$user_id = $_SESSION['user_id'] ?? 0;

// Fetch user's student details
$student_details = [];
try {
    $stmt = $db->prepare("SELECT * FROM students WHERE user_id = ? OR id = ?");
    $stmt->execute([$user_id, $user_id]);
    $student_details = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// If user is student, get their student_id
$student_id = $student_details['id'] ?? $user_id;

// Fetch user's payments only
$payments = [];
try {
    $stmt = $db->prepare("
        SELECT p.*, 
               s.name as student_name, 
               s.student_id as student_roll_no,
               s.phone,
               r.room_number
        FROM payments p 
        LEFT JOIN students s ON p.student_id = s.id 
        LEFT JOIN rooms r ON s.room_id = r.id
        WHERE p.student_id = ? 
        ORDER BY p.created_at DESC 
        LIMIT 50
    ");
    $stmt->execute([$student_id]);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch user's payment statistics
$stats = [
    'total_payments' => 0,
    'total_collected' => 0,
    'total_pending' => 0,
    'total_overdue' => 0,
    'total_paid' => 0
];

try {
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total_payments,
            SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) as total_collected,
            SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) as total_pending,
            SUM(CASE WHEN status = 'overdue' THEN amount ELSE 0 END) as total_overdue,
            SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) as total_paid
        FROM payments
        WHERE student_id = ?
    ");
    $stmt->execute([$student_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}

// Fetch user's room information
$room_info = [];
try {
    $stmt = $db->prepare("
        SELECT r.*, 
               s.name as student_name,
               s.student_id as student_roll_no
        FROM rooms r
        JOIN students s ON s.room_id = r.id
        WHERE s.id = ?
    ");
    $stmt->execute([$student_id]);
    $room_info = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Payments - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --gradient-2: linear-gradient(135deg, #3B82F6, #8B5CF6);
            --gradient-3: linear-gradient(135deg, #10B981, #34D399);
            --gradient-4: linear-gradient(135deg, #F59E0B, #FBBF24);
            --sidebar-width: 270px;
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Animated Background */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) {
            width: 600px;
            height: 600px;
            background: #8B5CF6;
            top: -200px;
            left: -200px;
            animation-delay: 0s;
        }

        .bg-orbs:nth-child(2) {
            width: 400px;
            height: 400px;
            background: #EC4899;
            bottom: -150px;
            right: -100px;
            animation-delay: -7s;
        }

        .bg-orbs:nth-child(3) {
            width: 300px;
            height: 300px;
            background: #3B82F6;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation-delay: -14s;
        }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: rgba(18, 18, 26, 0.92);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-right: 1px solid var(--glass-border);
            z-index: 1000;
            padding: 1.5rem 0;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            padding: 0 1.5rem 1.5rem;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 1.5rem;
            text-decoration: none;
        }

        .sidebar-brand .brand-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-1);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
            margin-right: 12px;
            box-shadow: 0 4px 16px rgba(139, 92, 246, 0.3);
            flex-shrink: 0;
        }

        .sidebar-brand .brand-text {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .sidebar-brand .brand-text span {
            color: #8B5CF6;
        }

        .sidebar-brand .brand-sub {
            display: block;
            font-size: 0.55rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 0 0.75rem;
        }

        .sidebar-nav::-webkit-scrollbar {
            width: 4px;
        }

        .sidebar-nav::-webkit-scrollbar-track {
            background: transparent;
        }

        .sidebar-nav::-webkit-scrollbar-thumb {
            background: rgba(139, 92, 246, 0.3);
            border-radius: 10px;
        }

        .nav-section-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: var(--text-muted);
            padding: 0.75rem 1rem 0.5rem;
        }

        .nav-item {
            margin-bottom: 2px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.7rem 1rem;
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
            font-weight: 500;
            position: relative;
        }

        .nav-link i {
            width: 1.6rem;
            font-size: 1rem;
            color: var(--text-muted);
            transition: all 0.3s ease;
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(139, 92, 246, 0.12);
            color: var(--text-primary);
        }

        .nav-link:hover i,
        .nav-link.active i {
            color: #8B5CF6;
        }

        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 24px;
            background: var(--gradient-1);
            border-radius: 0 4px 4px 0;
        }

        .sidebar-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
        }

        .sidebar-footer .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.6rem;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.03);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .sidebar-footer .user-card:hover {
            background: rgba(255, 255, 255, 0.06);
        }

        .sidebar-footer .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            color: white;
            flex-shrink: 0;
        }

        .sidebar-footer .user-info {
            flex: 1;
            min-width: 0;
        }

        .sidebar-footer .user-info .name {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .sidebar-footer .user-info .role {
            font-size: 0.65rem;
            color: var(--text-muted);
            text-transform: capitalize;
        }

        /* Main Content */
        #content-wrapper {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem 2rem;
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        /* Topbar */
        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1.5rem;
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .btn-toggle-sidebar {
            display: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-toggle-sidebar:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-primary);
        }

        .page-title h1 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .page-title p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .topbar-user:hover {
            background: rgba(255, 255, 255, 0.08);
        }

        .topbar-user .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .topbar-user .user-name {
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        .topbar-user .user-role {
            font-size: 0.65rem;
            color: var(--text-muted);
        }

        /* Student Info Card */
        .student-info-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            display: grid;
            grid-template-columns: auto 1fr auto;
            gap: 1.5rem;
            align-items: center;
        }

        .student-info-card .student-avatar {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            font-weight: 700;
            color: white;
            flex-shrink: 0;
        }

        .student-info-card .student-details h3 {
            font-size: 1.1rem;
            font-weight: 700;
            margin: 0;
        }

        .student-info-card .student-details p {
            color: var(--text-secondary);
            font-size: 0.85rem;
            margin: 0;
        }

        .student-info-card .student-details .detail-tag {
            display: inline-block;
            padding: 0.1rem 0.6rem;
            background: rgba(139, 92, 246, 0.12);
            border-radius: 50px;
            font-size: 0.7rem;
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .student-info-card .room-badge {
            padding: 0.4rem 1.2rem;
            background: rgba(16, 185, 129, 0.12);
            border: 1px solid rgba(16, 185, 129, 0.2);
            border-radius: 12px;
            text-align: center;
        }

        .student-info-card .room-badge .room-number {
            font-size: 1.2rem;
            font-weight: 700;
            color: #10B981;
        }

        .student-info-card .room-badge .room-label {
            font-size: 0.65rem;
            color: var(--text-muted);
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1.25rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.25rem 1.5rem;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-4px);
            border-color: rgba(139, 92, 246, 0.2);
            box-shadow: var(--shadow-glow);
        }

        .stat-card .stat-glow {
            position: absolute;
            top: -50%;
            right: -20%;
            width: 150px;
            height: 150px;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.08;
            pointer-events: none;
        }

        .stat-card:nth-child(1) .stat-glow { background: #8B5CF6; }
        .stat-card:nth-child(2) .stat-glow { background: #10B981; }
        .stat-card:nth-child(3) .stat-glow { background: #F59E0B; }
        .stat-card:nth-child(4) .stat-glow { background: #EF4444; }

        .stat-card .stat-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }

        .stat-card .stat-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
        }

        .stat-card .stat-icon.purple { background: rgba(139, 92, 246, 0.15); color: #8B5CF6; }
        .stat-card .stat-icon.green { background: rgba(16, 185, 129, 0.15); color: #10B981; }
        .stat-card .stat-icon.yellow { background: rgba(245, 158, 11, 0.15); color: #F59E0B; }
        .stat-card .stat-icon.red { background: rgba(239, 68, 68, 0.15); color: #EF4444; }

        .stat-card .stat-value {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: -0.5px;
        }

        .stat-card .stat-label {
            font-size: 0.7rem;
            font-weight: 500;
            color: var(--text-muted);
        }

        /* Payment Table */
        .payment-section {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 1.5rem;
        }

        .payment-section .section-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.25rem;
        }

        .payment-section .section-title {
            font-size: 1rem;
            font-weight: 600;
        }

        .payment-section .section-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .payment-section .payment-count {
            font-size: 0.7rem;
            color: var(--text-muted);
            background: rgba(255, 255, 255, 0.04);
            padding: 0.2rem 0.8rem;
            border-radius: 50px;
            border: 1px solid var(--glass-border);
        }

        .table-wrap {
            overflow-x: auto;
        }

        .payment-table {
            width: 100%;
            border-collapse: collapse;
        }

        .payment-table th {
            font-size: 0.6rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-muted);
            padding: 0.6rem 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--glass-border);
        }

        .payment-table td {
            padding: 0.7rem 0.75rem;
            font-size: 0.8rem;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--glass-border);
        }

        .payment-table tr:last-child td {
            border-bottom: none;
        }

        .payment-table td strong {
            color: var(--text-primary);
        }

        .payment-table .status-badge {
            font-size: 0.55rem;
            font-weight: 600;
            padding: 0.15rem 0.6rem;
            border-radius: 50px;
            text-transform: uppercase;
        }

        .status-badge.paid {
            background: rgba(16, 185, 129, 0.15);
            color: #10B981;
        }

        .status-badge.pending {
            background: rgba(245, 158, 11, 0.15);
            color: #F59E0B;
        }

        .status-badge.overdue {
            background: rgba(239, 68, 68, 0.15);
            color: #EF4444;
        }

        .payment-table .payment-method {
            font-size: 0.65rem;
            padding: 0.1rem 0.5rem;
            background: rgba(255, 255, 255, 0.04);
            border-radius: 50px;
            border: 1px solid var(--glass-border);
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 1.5rem 0 0.5rem;
            border-top: 1px solid var(--glass-border);
            margin-top: 2rem;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            #content-wrapper {
                margin-left: 0;
                padding: 1rem;
            }

            .btn-toggle-sidebar {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .topbar {
                padding: 0.5rem 1rem;
                border-radius: 16px;
            }

            .page-title h1 {
                font-size: 1rem;
            }

            .page-title p {
                font-size: 0.7rem;
            }

            .topbar-user .user-name,
            .topbar-user .user-role {
                display: none;
            }

            .stats-grid {
                grid-template-columns: 1fr 1fr;
                gap: 0.75rem;
            }

            .stat-card {
                padding: 1rem;
            }

            .stat-card .stat-value {
                font-size: 1.2rem;
            }

            .student-info-card {
                grid-template-columns: 1fr;
                text-align: center;
                gap: 0.75rem;
            }

            .student-info-card .student-avatar {
                margin: 0 auto;
            }

            .student-info-card .room-badge {
                display: inline-block;
            }

            .payment-section .section-header {
                flex-direction: column;
                gap: 0.5rem;
                align-items: flex-start;
            }
        }

        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg-primary);
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(139, 92, 246, 0.3);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: rgba(139, 92, 246, 0.5);
        }

        .dropdown-menu {
            background: var(--bg-secondary) !important;
            border: 1px solid var(--glass-border) !important;
        }

        .dropdown-item {
            color: var(--text-secondary) !important;
        }

        .dropdown-item:hover {
            background: rgba(139, 92, 246, 0.1) !important;
            color: var(--text-primary) !important;
        }

        .dropdown-divider {
            border-color: var(--glass-border) !important;
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <a href="indexview.php" class="sidebar-brand">
            <div class="brand-icon">
                <i class="fas fa-home"></i>
            </div>
            <div>
                <div class="brand-text">Graceful<span>Living</span></div>
                <span class="brand-sub">Management System</span>
            </div>
        </a>

        <nav class="sidebar-nav">
            <div class="nav-section-label">Main</div>
            <div class="nav-item">
                <a href="indexview.php" class="nav-link">
                    <i class="fas fa-th-large"></i>
                    Dashboard
                </a>
            </div>

            <div class="nav-section-label">Management</div>
            <div class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    My Profile
                </a>
            </div>
            <div class="nav-item">
                <a href="rooms.php" class="nav-link">
                    <i class="fas fa-bed"></i>
                    Rooms
                </a>
            </div>
            <div class="nav-item">
                <a href="payments.php" class="nav-link active">
                    <i class="fas fa-credit-card"></i>
                    My Payments
                </a>
            </div>

            <div class="nav-section-label">Account</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i>
                    Settings
                </a>
            </div>
            <div class="nav-item">
                <a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </nav>

        <div class="sidebar-footer">
            <a href="profile.php" class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($user_name); ?></div>
                    <div class="role"><?php echo htmlspecialchars($user_role); ?></div>
                </div>
                <i class="fas fa-ellipsis-v" style="color: var(--text-muted); font-size: 0.7rem;"></i>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div id="content-wrapper">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left">
                <button class="btn-toggle-sidebar" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>My Payments</h1>
                    <p>View your payment history and status</p>
                </div>
            </div>
            <div class="topbar-right">
                <a href="profile.php" class="topbar-user">
                    <div class="avatar"><?php echo strtoupper(substr($user_name, 0, 2)); ?></div>
                    <div>
                        <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
                        <div class="user-role"><?php echo htmlspecialchars($user_role); ?></div>
                    </div>
                </a>
            </div>
        </header>

        <!-- Student Info Card -->
        <div class="student-info-card">
            <div class="student-avatar">
                <?php echo strtoupper(substr($student_details['name'] ?? $user_name, 0, 2)); ?>
            </div>
            <div class="student-details">
                <h3><?php echo htmlspecialchars($student_details['name'] ?? $user_name); ?></h3>
                <p>
                    <span class="detail-tag">
                        <i class="fas fa-id-card me-1"></i>
                        <?php echo htmlspecialchars($student_details['student_id'] ?? 'N/A'); ?>
                    </span>
                    <span class="detail-tag" style="background:rgba(16,185,129,0.12);color:#10B981;">
                        <i class="fas fa-envelope me-1"></i>
                        <?php echo htmlspecialchars($user_email); ?>
                    </span>
                </p>
                <p style="font-size:0.75rem;">
                    <i class="fas fa-phone me-1" style="color:var(--text-muted);"></i>
                    <?php echo htmlspecialchars($student_details['phone'] ?? 'N/A'); ?>
                </p>
            </div>
            <div>
                <div class="room-badge">
                    <div class="room-number">
                        <i class="fas fa-bed me-1" style="font-size:0.8rem;color:var(--text-muted);"></i>
                        <?php echo htmlspecialchars($room_info['room_number'] ?? 'N/A'); ?>
                    </div>
                    <div class="room-label">Room Number</div>
                </div>
            </div>
        </div>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-glow"></div>
                <div class="stat-top">
                    <div class="stat-icon purple">
                        <i class="fas fa-receipt"></i>
                    </div>
                </div>
                <div class="stat-value"><?php echo $stats['total_payments'] ?? 0; ?></div>
                <div class="stat-label">Total Payments</div>
            </div>
            <div class="stat-card">
                <div class="stat-glow"></div>
                <div class="stat-top">
                    <div class="stat-icon green">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
                <div class="stat-value">₹<?php echo number_format(($stats['total_collected'] ?? 0), 0); ?></div>
                <div class="stat-label">Total Paid</div>
            </div>
            <div class="stat-card">
                <div class="stat-glow"></div>
                <div class="stat-top">
                    <div class="stat-icon yellow">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
                <div class="stat-value">₹<?php echo number_format(($stats['total_pending'] ?? 0), 0); ?></div>
                <div class="stat-label">Pending Amount</div>
            </div>
            <div class="stat-card">
                <div class="stat-glow"></div>
                <div class="stat-top">
                    <div class="stat-icon red">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
                <div class="stat-value">₹<?php echo number_format(($stats['total_overdue'] ?? 0), 0); ?></div>
                <div class="stat-label">Overdue Amount</div>
            </div>
        </div>

        <!-- Payment Table -->
        <div class="payment-section">
            <div class="section-header">
                <div class="section-title">
                    <i class="fas fa-list"></i>Payment History
                </div>
                <span class="payment-count">
                    <i class="fas fa-file-invoice me-1"></i>
                    <?php echo count($payments); ?> records
                </span>
            </div>
            <div class="table-wrap">
                <table class="payment-table">
                    <thead>
                        <tr>
                            <th>Receipt No</th>
                            <th>Payment Type</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($payments)): ?>
                            <?php foreach ($payments as $payment): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($payment['receipt_number'] ?? 'N/A'); ?></strong></td>
                                <td><?php echo ucfirst(htmlspecialchars($payment['payment_type'] ?? 'N/A')); ?></td>
                                <td>₹<?php echo number_format($payment['amount'] ?? 0, 2); ?></td>
                                <td>
                                    <span class="payment-method">
                                        <?php echo ucfirst(htmlspecialchars($payment['payment_method'] ?? 'N/A')); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M j, Y', strtotime($payment['created_at'] ?? 'now')); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $payment['status'] ?? 'pending'; ?>">
                                        <?php echo ucfirst($payment['status'] ?? 'Pending'); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm" style="background:rgba(139,92,246,0.1);border:none;color:#8B5CF6;border-radius:8px;padding:0.2rem 0.5rem;" onclick="alert('Receipt: <?php echo htmlspecialchars($payment['receipt_number'] ?? 'N/A'); ?>\nAmount: ₹<?php echo number_format($payment['amount'] ?? 0, 2); ?>\nStatus: <?php echo ucfirst($payment['status'] ?? 'Pending'); ?>')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php if (($payment['status'] ?? '') === 'paid'): ?>
                                    <button class="btn btn-sm" style="background:rgba(16,185,129,0.1);border:none;color:#10B981;border-radius:8px;padding:0.2rem 0.5rem;" onclick="window.print()">
                                        <i class="fas fa-print"></i>
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-4" style="color: var(--text-muted);">
                                    <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                                    No payment records found
                                    <p style="font-size:0.7rem;margin-top:0.25rem;">You haven't made any payments yet.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> Graceful Living — All rights reserved.</p>
        </footer>
    </div>

    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Ready to Leave?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-secondary" style="color: var(--text-secondary) !important;">
                    Select "Logout" below if you are ready to end your current session.
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Sidebar Toggle
        $('#sidebarToggle').on('click', function() {
            $('#sidebar').toggleClass('open');
        });

        // Close sidebar on outside click (mobile)
        $(document).on('click', function(e) {
            if ($(window).width() <= 768) {
                if (!$(e.target).closest('#sidebar').length && !$(e.target).closest('#sidebarToggle').length) {
                    $('#sidebar').removeClass('open');
                }
            }
        });
    </script>
</body>
</html>