<?php
// register.php
session_start();
include '../config/database.php';

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $address = trim($_POST['address'] ?? '');
    $guardian_name = trim($_POST['guardian_name'] ?? '');
    $guardian_phone = trim($_POST['guardian_phone'] ?? '');
    $guardian_relation = trim($_POST['guardian_relation'] ?? '');

    // Validation
    if (empty($name)) {
        $errors[] = "Full name is required";
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email address is required";
    }

    if (empty($phone) || strlen($phone) < 10) {
        $errors[] = "Valid phone number is required";
    }

  
    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters long";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }

    // Check if email already exists
    if (empty($errors)) {
        try {
            $stmt = $db->prepare("SELECT id FROM students WHERE email = ? OR student_id = ?");
            $stmt->execute([$email, $student_id]);
            if ($stmt->fetch()) {
                $errors[] = "Email or Student ID already exists";
            }
        } catch (PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }

    // If no errors, create student account
    if (empty($errors)) {
        try {
            // Start transaction
            $db->beginTransaction();

            // Generate unique username
            $username = strtolower(str_replace(' ', '.', $name)) . rand(100, 999);
            
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert into users table
            $stmt = $db->prepare("INSERT INTO users (username, email, password, role, status) VALUES (?, ?, ?, 'student', 'active')");
            $stmt->execute([$username, $email, $hashed_password]);
            $user_id = $db->lastInsertId();

            

            // Commit transaction
            $db->commit();

            $success = true;
            
            // Auto login after successful registration
            $_SESSION['user_id'] = $student_db_id;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_role'] = 'student';
            $_SESSION['user_email'] = $email;

            // Redirect to dashboard or home page
            header("Location: indexview.php");
            exit();

        } catch (PDOException $e) {
            $db->rollBack();
            $errors[] = "Registration failed: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Girls Hostel Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="https://i.im.ge/2025/11/21/42uJYF.50340aa0cf39ee714ff31e1c53d403ba-removebg-preview.png" type="image/x-icon">

    <style>
        :root {
            --primary: #6C3CE1;
            --primary-light: #8B5CF6;
            --secondary: #EC4899;
            --accent: #F59E0B;
            --dark-bg: #0F0A1A;
            --card-bg: rgba(255, 255, 255, 0.05);
            --glass-border: rgba(255, 255, 255, 0.1);
            --text-white: #FFFFFF;
            --text-muted: rgba(255, 255, 255, 0.6);
            --shadow-glow: 0 0 60px rgba(108, 60, 225, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: var(--dark-bg);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated Background */
        body::before {
            content: '';
            position: fixed;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: 
                radial-gradient(ellipse at 20% 50%, rgba(108, 60, 225, 0.15) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 20%, rgba(236, 72, 153, 0.12) 0%, transparent 50%),
                radial-gradient(ellipse at 50% 80%, rgba(245, 158, 11, 0.08) 0%, transparent 50%);
            animation: rotateBg 40s linear infinite;
            z-index: 0;
        }

        @keyframes rotateBg {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Floating Particles */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
            overflow: hidden;
        }

        .particle {
            position: absolute;
            width: 6px;
            height: 6px;
            background: var(--primary-light);
            border-radius: 50%;
            opacity: 0.3;
            animation: floatParticle 15s infinite ease-in-out;
        }

        .particle:nth-child(1) { left: 10%; animation-delay: 0s; animation-duration: 18s; }
        .particle:nth-child(2) { left: 20%; animation-delay: 2s; animation-duration: 14s; }
        .particle:nth-child(3) { left: 35%; animation-delay: 4s; animation-duration: 20s; }
        .particle:nth-child(4) { left: 50%; animation-delay: 1s; animation-duration: 16s; }
        .particle:nth-child(5) { left: 65%; animation-delay: 3s; animation-duration: 22s; }
        .particle:nth-child(6) { left: 78%; animation-delay: 5s; animation-duration: 17s; }
        .particle:nth-child(7) { left: 88%; animation-delay: 0.5s; animation-duration: 19s; }
        .particle:nth-child(8) { left: 45%; animation-delay: 2.5s; animation-duration: 15s; }

        @keyframes floatParticle {
            0%, 100% { transform: translateY(0) scale(1); opacity: 0.2; }
            50% { transform: translateY(-100vh) scale(0.5); opacity: 0.6; }
        }

        /* Main Container */
        .register-container {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 1100px;
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 32px;
            border: 1px solid var(--glass-border);
            box-shadow: var(--shadow-glow), inset 0 1px 0 rgba(255, 255, 255, 0.05);
            overflow: hidden;
        }

        /* Left Panel */
        .register-left {
            padding: 3.5rem 2.5rem;
            background: linear-gradient(145deg, rgba(108, 60, 225, 0.15), rgba(236, 72, 153, 0.08));
            backdrop-filter: blur(10px);
            border-right: 1px solid var(--glass-border);
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 2.5rem;
        }

        .brand-logo .icon-wrapper {
            width: 52px;
            height: 52px;
            background: linear-gradient(135deg, var(--primary-light), var(--secondary));
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            box-shadow: 0 8px 32px rgba(108, 60, 225, 0.3);
        }

        .brand-logo h1 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-white);
            margin: 0;
            letter-spacing: -0.5px;
        }

        .brand-logo h1 span {
            color: var(--secondary);
        }

        .brand-logo small {
            display: block;
            font-size: 0.65rem;
            font-weight: 300;
            color: var(--text-muted);
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        .welcome-text {
            margin-bottom: 2rem;
        }

        .welcome-text h2 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-white);
            margin-bottom: 0.5rem;
            line-height: 1.2;
        }

        .welcome-text h2 .highlight {
            background: linear-gradient(135deg, var(--primary-light), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .welcome-text p {
            color: var(--text-muted);
            font-size: 0.95rem;
            line-height: 1.7;
        }

        .features-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin: 1.5rem 0 2rem;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            background: rgba(255, 255, 255, 0.04);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.05);
            transition: all 0.3s ease;
        }

        .feature-item:hover {
            background: rgba(255, 255, 255, 0.08);
            transform: translateY(-2px);
        }

        .feature-item i {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, rgba(108, 60, 225, 0.2), rgba(236, 72, 153, 0.2));
            border-radius: 8px;
            color: var(--primary-light);
            font-size: 0.9rem;
        }

        .feature-item span {
            color: var(--text-white);
            font-size: 0.8rem;
            font-weight: 500;
        }

        .left-footer {
            margin-top: auto;
            padding-top: 2rem;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }

        .left-footer p {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .btn-outline-glass {
            background: transparent;
            border: 1px solid rgba(255, 255, 255, 0.15);
            color: var(--text-white);
            padding: 0.6rem 2rem;
            border-radius: 12px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-outline-glass:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: var(--primary-light);
            color: var(--text-white);
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(108, 60, 225, 0.2);
        }

        /* Right Panel */
        .register-right {
            padding: 2.5rem 2.5rem 3rem;
        }

        .register-right .header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .register-right .header h3 {
            color: var(--text-white);
            font-weight: 700;
            font-size: 1.5rem;
        }

        .register-right .header p {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 1.2rem;
        }

        .form-label {
            color: var(--text-white);
            font-weight: 500;
            font-size: 0.8rem;
            margin-bottom: 0.4rem;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .form-label .required {
            color: var(--secondary);
            font-size: 0.7rem;
        }

        .form-control, .form-select {
            background: rgba(255, 255, 255, 0.06) !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            border-radius: 12px !important;
            padding: 0.7rem 1rem !important;
            color: var(--text-white) !important;
            font-size: 0.9rem !important;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.3);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary-light) !important;
            box-shadow: 0 0 0 4px rgba(108, 60, 225, 0.15) !important;
            background: rgba(255, 255, 255, 0.08) !important;
        }

        .form-control option {
            background: #1a1028;
            color: white;
        }

        .password-strength {
            height: 3px;
            background: rgba(255, 255, 255, 0.06);
            border-radius: 2px;
            margin-top: 0.5rem;
            overflow: hidden;
        }

        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.4s ease;
        }

        .strength-weak { background: #EF4444; width: 33%; }
        .strength-medium { background: #F59E0B; width: 66%; }
        .strength-strong { background: #10B981; width: 100%; }

        .form-check {
            display: flex;
            align-items: center;
            gap: 10px;
            padding-left: 0;
        }

        .form-check-input {
            width: 18px;
            height: 18px;
            border-radius: 4px;
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.1);
            cursor: pointer;
            flex-shrink: 0;
        }

        .form-check-input:checked {
            background: linear-gradient(135deg, var(--primary-light), var(--secondary));
            border-color: var(--primary-light);
        }

        .form-check-label {
            color: var(--text-muted);
            font-size: 0.85rem;
        }

        .form-check-label a {
            color: var(--primary-light);
            text-decoration: none;
        }

        .form-check-label a:hover {
            text-decoration: underline;
        }

        .btn-register {
            width: 100%;
            padding: 0.8rem;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            color: white;
            background: linear-gradient(135deg, var(--primary-light), var(--secondary));
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            margin-top: 0.5rem;
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 40px rgba(108, 60, 225, 0.35);
        }

        .btn-register::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            transform: rotate(45deg);
            transition: all 0.6s ease;
        }

        .btn-register:hover::after {
            left: 100%;
        }

        .login-link {
            text-align: center;
            margin-top: 1.5rem;
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .login-link a {
            color: var(--primary-light);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        .login-link a:hover {
            color: var(--secondary);
        }

        /* Alerts */
        .alert {
            border-radius: 12px;
            border: none;
            padding: 0.8rem 1.2rem;
            font-size: 0.9rem;
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.15);
            color: #FCA5A5;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.15);
            color: #6EE7B7;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .alert ul {
            padding-left: 1.2rem;
            margin: 0;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .register-left {
                border-right: none;
                border-bottom: 1px solid var(--glass-border);
                padding: 2rem;
            }

            .features-grid {
                grid-template-columns: 1fr 1fr;
            }

            .register-right {
                padding: 2rem;
            }
        }

        @media (max-width: 576px) {
            .features-grid {
                grid-template-columns: 1fr;
            }

            .register-left, .register-right {
                padding: 1.5rem;
            }

            .welcome-text h2 {
                font-size: 1.5rem;
            }

            .register-container {
                border-radius: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Particles -->
    <div class="particles">
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
        <div class="particle"></div>
    </div>

    <div class="register-container">
        <div class="row g-0">
            <!-- Left Panel -->
            <div class="col-lg-5 register-left">
                <div class="brand-logo">
                    <div class="icon-wrapper">
                        <i class="fas fa-home"></i>
                    </div>
                    <div>
                        <h1>Girls<span>Hostel</span></h1>
                        <small>Management System</small>
                    </div>
                </div>

                <div class="welcome-text">
                    <h2>Welcome to <span class="highlight">Safe Space</span></h2>
                    <p>Join our community of empowered women. Experience comfort, security, and growth in a nurturing environment.</p>
                </div>

                <div class="features-grid">
                    <div class="feature-item">
                        <i class="fas fa-shield-alt"></i>
                        <span>24/7 Security</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-wifi"></i>
                        <span>High-Speed WiFi</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-utensils"></i>
                        <span>Healthy Meals</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-users"></i>
                        <span>Community</span>
                    </div>
                </div>

                <div class="left-footer">
                    <p>Already a member?</p>
                    <a href="login.php" class="btn btn-outline-glass">
                        <i class="fas fa-sign-in-alt me-2"></i>Sign In
                    </a>
                </div>
            </div>

            <!-- Right Panel -->
            <div class="col-lg-7 register-right">
                <div class="header">
                    <h3>Create Your Account</h3>
                    <p>Fill in the details to get started</p>
                </div>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i> Registration successful! Redirecting...
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Full Name <span class="required">*</span></label>
                                <input type="text" class="form-control" name="name" placeholder="Enter your full name" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Email Address <span class="required">*</span></label>
                                <input type="email" class="form-control" name="email" placeholder="your@email.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Phone Number <span class="required">*</span></label>
                                <input type="tel" class="form-control" name="phone" placeholder="Enter phone number" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Address</label>
                                <input type="text" class="form-control" name="address" placeholder="Enter your address" value="<?php echo htmlspecialchars($_POST['address'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Password <span class="required">*</span></label>
                                <input type="password" class="form-control" name="password" id="password" placeholder="Min 6 characters" required>
                                <div class="password-strength">
                                    <div class="password-strength-bar" id="password-strength-bar"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Confirm Password <span class="required">*</span></label>
                                <input type="password" class="form-control" name="confirm_password" placeholder="Re-enter password" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label">Guardian Name</label>
                                <input type="text" class="form-control" name="guardian_name" placeholder="Guardian name" value="<?php echo htmlspecialchars($_POST['guardian_name'] ?? ''); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label">Guardian Phone</label>
                                <input type="tel" class="form-control" name="guardian_phone" placeholder="Guardian phone" value="<?php echo htmlspecialchars($_POST['guardian_phone'] ?? ''); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label">Relation</label>
                                <select class="form-select" name="guardian_relation">
                                    <option value="">Select</option>
                                    <option value="Father" <?php echo ($_POST['guardian_relation'] ?? '') == 'Father' ? 'selected' : ''; ?>>Father</option>
                                    <option value="Mother" <?php echo ($_POST['guardian_relation'] ?? '') == 'Mother' ? 'selected' : ''; ?>>Mother</option>
                                    <option value="Brother" <?php echo ($_POST['guardian_relation'] ?? '') == 'Brother' ? 'selected' : ''; ?>>Brother</option>
                                    <option value="Sister" <?php echo ($_POST['guardian_relation'] ?? '') == 'Sister' ? 'selected' : ''; ?>>Sister</option>
                                    <option value="Uncle" <?php echo ($_POST['guardian_relation'] ?? '') == 'Uncle' ? 'selected' : ''; ?>>Uncle</option>
                                    <option value="Aunt" <?php echo ($_POST['guardian_relation'] ?? '') == 'Aunt' ? 'selected' : ''; ?>>Aunt</option>
                                    <option value="Other" <?php echo ($_POST['guardian_relation'] ?? '') == 'Other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="terms" required>
                            <label class="form-check-label" for="terms">
                                I agree to the <a href="#">Terms & Conditions</a> and <a href="#">Privacy Policy</a>
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-register">
                        <i class="fas fa-user-plus me-2"></i>Create Account
                    </button>
                </form>

                <div class="login-link">
                    Already have an account? <a href="login.php">Sign In</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Password strength indicator
        document.getElementById('password').addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.getElementById('password-strength-bar');
            let strength = 0;
            
            if (password.length >= 6) strength += 1;
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength += 1;
            if (password.match(/\d/)) strength += 1;
            if (password.match(/[^a-zA-Z\d]/)) strength += 1;
            
            strengthBar.className = 'password-strength-bar';
            if (password.length === 0) {
                strengthBar.style.width = '0%';
            } else if (strength <= 1) {
                strengthBar.className += ' strength-weak';
            } else if (strength <= 2) {
                strengthBar.className += ' strength-medium';
            } else {
                strengthBar.className += ' strength-strong';
            }
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const password = document.querySelector('input[name="password"]').value;
            const confirmPassword = document.querySelector('input[name="confirm_password"]').value;
            const terms = document.getElementById('terms');
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
                return;
            }
            
            if (!terms.checked) {
                e.preventDefault();
                alert('Please agree to the Terms & Conditions');
                return;
            }
        });
    </script>
</body>
</html>