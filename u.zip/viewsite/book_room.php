<?php
session_start();
include 'config/database.php';

// Check if user is logged in as student
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'student') {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$room_id = $_GET['id'] ?? 0;
$room = null;
$student = null;
$error = '';
$success = '';

// Fetch room details
if ($room_id) {
    try {
        $stmt = $db->prepare("SELECT * FROM rooms WHERE id = ?");
        $stmt->execute([$room_id]);
        $room = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$room) {
            $error = "Room not found!";
        } elseif ($room['status'] !== 'available') {
            $error = "This room is not available for booking!";
        } elseif ($room['occupied'] >= $room['capacity']) {
            $error = "This room is already full!";
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
} else {
    $error = "No room specified!";
}

// Fetch student details
try {
    $stmt = $db->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Check if student already has a room
    if ($student && $student['room_id']) {
        $error = "You already have a room assigned! Please contact administration for room change.";
    }
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Handle room booking form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_booking']) && !$error) {
    $move_in_date = $_POST['move_in_date'] ?? '';
    $requirements = $_POST['requirements'] ?? '';
    
    // Validate move-in date
    $min_date = date('Y-m-d', strtotime('+1 day'));
    if (empty($move_in_date) || $move_in_date < $min_date) {
        $error = "Please select a valid move-in date (tomorrow or later).";
    } else {
        try {
            $db->beginTransaction();
            
            // 1. Update student's room assignment
            $stmt = $db->prepare("UPDATE students SET room_id = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$room_id, $_SESSION['user_id']]);
            
            // 2. Update room occupancy and status
            $new_occupied = $room['occupied'] + 1;
            $new_status = ($new_occupied >= $room['capacity']) ? 'occupied' : 'available';
            
            $stmt = $db->prepare("UPDATE rooms SET occupied = ?, status = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$new_occupied, $new_status, $room_id]);
            
            // 3. Create room allocation record
            $stmt = $db->prepare("INSERT INTO room_allocations (student_id, room_id, move_in_date, special_requirements, status) 
                                 VALUES (?, ?, ?, ?, 'confirmed')");
            $stmt->execute([$_SESSION['user_id'], $room_id, $move_in_date, $requirements]);
            $allocation_id = $db->lastInsertId();
            
            // 4. Create initial rent payment record
            $receipt_number = 'RENT' . date('YmdHis') . rand(100, 999);
            $due_date = date('Y-m-d', strtotime('+7 days'));
            
            $stmt = $db->prepare("INSERT INTO payments (student_id, amount, payment_type, payment_date, due_date, status, description, receipt_number) 
                                 VALUES (?, ?, 'rent', NULL, ?, 'pending', ?, ?)");
            $stmt->execute([
                $_SESSION['user_id'],
                $room['rent'],
                $due_date,
                "Monthly hostel rent for Room " . $room['room_number'] . " - " . date('F Y'),
                $receipt_number
            ]);
            
            // 5. Create security deposit payment
            $security_amount = $room['rent'] * 2;
            $security_receipt = 'SEC' . date('YmdHis') . rand(100, 999);
            
            $stmt = $db->prepare("INSERT INTO payments (student_id, amount, payment_type, payment_date, due_date, status, description, receipt_number) 
                                 VALUES (?, ?, 'security', NULL, ?, 'pending', ?, ?)");
            $stmt->execute([
                $_SESSION['user_id'],
                $security_amount,
                $due_date,
                "Security deposit for Room " . $room['room_number'],
                $security_receipt
            ]);
            
            $db->commit();
            
            $success = "Room booked successfully! Your move-in date is " . date('F j, Y', strtotime($move_in_date)) . ". Please complete the payments within 7 days.";
            
            // Refresh room data
            $stmt = $db->prepare("SELECT * FROM rooms WHERE id = ?");
            $stmt->execute([$room_id]);
            $room = $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            $db->rollBack();
            $error = "Booking failed: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Room - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .booking-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
        }
        .room-highlight {
            border-left: 4px solid #8a2be2;
            background: #f8f9fa;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="indexview.php">Home</a></li>
                        <li class="breadcrumb-item"><a href="rooms.php">Rooms</a></li>
                        <li class="breadcrumb-item active">Book Room</li>
                    </ol>
                </nav>
                
                <h2><i class="fas fa-door-open me-2"></i>Book Room</h2>
            </div>
        </div>

        <!-- Messages -->
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
            <div class="text-center mt-3">
                <a href="booking.php" class="btn btn-primary me-2">View My Bookings</a>
                <a href="payments.php" class="btn btn-success">Make Payment</a>
            </div>
        <?php endif; ?>

        <?php if ($room && !$success): ?>
        <div class="row mt-4">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">Room Details</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Room <?php echo $room['room_number']; ?></h5>
                                <p><strong>Floor:</strong> <?php echo $room['floor']; ?></p>
                                <p><strong>Type:</strong> <?php echo ucfirst($room['type']); ?></p>
                                <p><strong>Rent:</strong> ₹<?php echo number_format($room['rent']); ?>/month</p>
                            </div>
                            <div class="col-md-6">
                                <?php if (!empty($room['facilities'])): 
                                    $facilities = json_decode($room['facilities'], true); ?>
                                    <h6>Facilities:</h6>
                                    <?php foreach ($facilities as $facility): ?>
                                        <span class="badge bg-primary me-1"><?php echo $facility; ?></span>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <form method="POST" class="mt-4">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0">Booking Information</h4>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Move-in Date</label>
                                <input type="date" class="form-control" name="move_in_date" 
                                       min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Special Requirements</label>
                                <textarea class="form-control" name="requirements" rows="3"></textarea>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" required>
                                <label class="form-check-label">I agree to the terms and conditions</label>
                            </div>
                            <button type="submit" name="confirm_booking" class="btn btn-primary">Confirm Booking</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>