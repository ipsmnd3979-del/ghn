<?php
session_start();

// Get user data from session if logged in
$user_name = $_SESSION['user_name'] ?? '';
$user_email = $_SESSION['user_email'] ?? '';
$user_role = $_SESSION['user_role'] ?? 'guest';

// Handle form submission
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    
    // Basic validation
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error_message = 'Please fill in all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = 'Please enter a valid email address.';
    } else {
        // In a real application, you would send an email or save to database
        $success_message = 'Thank you for your message! We will get back to you soon.';
        
        // Here you would typically:
        // 1. Save to database
        // 2. Send email notification
        // 3. Redirect or clear form
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Graceful Living</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: rgba(255, 255, 255, 0.04);
            --glass-border: rgba(255, 255, 255, 0.06);
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.6);
            --text-muted: rgba(255, 255, 255, 0.35);
            --gradient-1: linear-gradient(135deg, #8B5CF6, #EC4899);
            --gradient-2: linear-gradient(135deg, #3B82F6, #8B5CF6);
            --gradient-3: linear-gradient(135deg, #10B981, #34D399);
            --shadow-glow: 0 8px 32px rgba(139, 92, 246, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Animated Background */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .bg-orbs {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.12;
            animation: floatOrbs 20s infinite ease-in-out;
        }

        .bg-orbs:nth-child(1) {
            width: 600px;
            height: 600px;
            background: #8B5CF6;
            top: -200px;
            left: -200px;
            animation-delay: 0s;
        }

        .bg-orbs:nth-child(2) {
            width: 400px;
            height: 400px;
            background: #EC4899;
            bottom: -150px;
            right: -100px;
            animation-delay: -7s;
        }

        .bg-orbs:nth-child(3) {
            width: 300px;
            height: 300px;
            background: #3B82F6;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation-delay: -14s;
        }

        @keyframes floatOrbs {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        /* Top Navigation */
        .top-nav {
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(10, 10, 15, 0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--glass-border);
            padding: 0.75rem 2rem;
        }

        .top-nav .nav-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
        }

        .top-nav .brand-icon {
            width: 40px;
            height: 40px;
            background: var(--gradient-1);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            color: white;
        }

        .top-nav .brand-text {
            font-size: 1rem;
            font-weight: 800;
            color: var(--text-primary);
        }

        .top-nav .brand-text span {
            color: #8B5CF6;
        }

        .top-nav .brand-sub {
            display: block;
            font-size: 0.5rem;
            font-weight: 400;
            color: var(--text-muted);
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .top-nav .nav-links {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .top-nav .nav-link {
            color: var(--text-secondary);
            padding: 0.4rem 1rem;
            border-radius: 10px;
            font-size: 0.8rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .top-nav .nav-link:hover,
        .top-nav .nav-link.active {
            background: rgba(139, 92, 246, 0.1);
            color: var(--text-primary);
        }

        .top-nav .nav-link.active {
            color: #8B5CF6;
        }

        .top-nav .auth-btn {
            padding: 0.4rem 1.2rem;
            border-radius: 10px;
            font-size: 0.8rem;
            font-weight: 600;
            border: none;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .top-nav .auth-btn.login {
            background: transparent;
            border: 1px solid var(--glass-border);
            color: var(--text-secondary);
        }

        .top-nav .auth-btn.login:hover {
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-primary);
        }

        .top-nav .auth-btn.register {
            background: var(--gradient-1);
            color: white;
        }

        .top-nav .auth-btn.register:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
            color: white;
        }

        .top-nav .user-dropdown {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 0.3rem 0.8rem 0.3rem 0.3rem;
            border-radius: 50px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: var(--text-primary);
        }

        .top-nav .user-dropdown:hover {
            background: rgba(255, 255, 255, 0.08);
        }

        .top-nav .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: white;
        }

        .top-nav .user-name {
            font-size: 0.8rem;
            font-weight: 500;
        }

        /* Hero Section */
        .hero-section {
            position: relative;
            z-index: 1;
            padding: 3rem 2rem 2rem;
            text-align: center;
        }

        .hero-section .hero-badge {
            display: inline-block;
            padding: 0.2rem 1rem;
            background: rgba(139, 92, 246, 0.12);
            border: 1px solid rgba(139, 92, 246, 0.2);
            border-radius: 50px;
            font-size: 0.7rem;
            font-weight: 600;
            color: #8B5CF6;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            margin-bottom: 1rem;
        }

        .hero-section h1 {
            font-size: 2.5rem;
            font-weight: 900;
            margin-bottom: 0.5rem;
            letter-spacing: -1px;
        }

        .hero-section h1 .highlight {
            background: var(--gradient-1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero-section p {
            color: var(--text-secondary);
            font-size: 1rem;
            max-width: 600px;
            margin: 0 auto;
        }

        /* Main Content */
        .main-content {
            position: relative;
            z-index: 1;
            max-width: 1100px;
            margin: 0 auto;
            padding: 0 1rem 2rem;
        }

        .contact-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }

        /* Contact Info Cards */
        .info-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 2rem;
        }

        .info-card .card-title {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
        }

        .info-card .card-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .contact-item {
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            padding: 0.75rem 0;
            border-bottom: 1px solid var(--glass-border);
        }

        .contact-item:last-child {
            border-bottom: none;
        }

        .contact-item .contact-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: rgba(139, 92, 246, 0.12);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #8B5CF6;
            font-size: 1rem;
            flex-shrink: 0;
        }

        .contact-item .contact-content .contact-label {
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-muted);
        }

        .contact-item .contact-content .contact-value {
            font-size: 0.9rem;
            color: var(--text-primary);
        }

        .contact-item .contact-content .contact-value a {
            color: var(--text-primary);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .contact-item .contact-content .contact-value a:hover {
            color: #8B5CF6;
        }

        /* Social Links */
        .social-links {
            display: flex;
            gap: 0.75rem;
            margin-top: 1rem;
        }

        .social-link {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--glass-border);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .social-link:hover {
            background: rgba(139, 92, 246, 0.12);
            border-color: #8B5CF6;
            color: #8B5CF6;
            transform: translateY(-3px);
        }

        /* Map */
        .map-container {
            border-radius: 16px;
            overflow: hidden;
            margin-top: 1.5rem;
            border: 1px solid var(--glass-border);
        }

        .map-container iframe {
            width: 100%;
            height: 200px;
            border: none;
        }

        /* Contact Form */
        .form-card {
            background: rgba(18, 18, 26, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 2rem;
        }

        .form-card .card-title {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
        }

        .form-card .card-title i {
            color: #8B5CF6;
            margin-right: 0.5rem;
        }

        .form-group {
            margin-bottom: 1.25rem;
        }

        .form-group label {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 0.3rem;
            display: block;
        }

        .form-group label .required {
            color: #EC4899;
        }

        .form-control,
        .form-select {
            background: rgba(255, 255, 255, 0.04) !important;
            border: 1px solid var(--glass-border) !important;
            border-radius: 12px !important;
            padding: 0.7rem 1rem !important;
            color: var(--text-primary) !important;
            font-size: 0.85rem !important;
            transition: all 0.3s ease;
        }

        .form-control::placeholder {
            color: var(--text-muted);
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #8B5CF6 !important;
            box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15) !important;
            background: rgba(255, 255, 255, 0.06) !important;
        }

        .form-control option {
            background: var(--bg-secondary);
            color: var(--text-primary);
        }

        textarea.form-control {
            resize: vertical;
            min-height: 120px;
        }

        .btn-submit {
            width: 100%;
            padding: 0.8rem;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.95rem;
            color: white;
            background: var(--gradient-1);
            transition: all 0.3s ease;
        }

        .btn-submit:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
        }

        /* Alerts */
        .alert {
            border-radius: 12px;
            border: none;
            padding: 0.8rem 1.2rem;
            font-size: 0.85rem;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.12);
            color: #34D399;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.12);
            color: #F87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        /* Footer */
        .footer {
            position: relative;
            z-index: 1;
            text-align: center;
            padding: 2rem 1rem 1.5rem;
            border-top: 1px solid var(--glass-border);
            max-width: 1100px;
            margin: 0 auto;
        }

        .footer p {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin: 0;
        }

        .footer .footer-links {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            margin-top: 0.5rem;
            flex-wrap: wrap;
        }

        .footer .footer-links a {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.7rem;
            transition: color 0.3s ease;
        }

        .footer .footer-links a:hover {
            color: var(--text-secondary);
        }

        /* Responsive */
        @media (max-width: 992px) {
            .contact-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .top-nav {
                padding: 0.5rem 1rem;
            }

            .top-nav .nav-links .nav-link {
                display: none;
            }

            .hero-section h1 {
                font-size: 1.8rem;
            }

            .info-card,
            .form-card {
                padding: 1.5rem;
            }
        }

        @media (max-width: 480px) {
            .hero-section h1 {
                font-size: 1.4rem;
            }

            .contact-item {
                flex-direction: column;
                gap: 0.3rem;
            }

            .contact-item .contact-icon {
                width: 32px;
                height: 32px;
                font-size: 0.8rem;
            }
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg-primary);
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(139, 92, 246, 0.3);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: rgba(139, 92, 246, 0.5);
        }

        /* Modal Override */
        .dropdown-menu {
            background: var(--bg-secondary) !important;
            border: 1px solid var(--glass-border) !important;
        }

        .dropdown-item {
            color: var(--text-secondary) !important;
        }

        .dropdown-item:hover {
            background: rgba(139, 92, 246, 0.1) !important;
            color: var(--text-primary) !important;
        }

        .dropdown-divider {
            border-color: var(--glass-border) !important;
        }
    </style>
</head>
<body>
    <!-- Background Animation -->
    <div class="bg-animation">
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
        <div class="bg-orbs"></div>
    </div>

    <!-- Top Navigation -->
    <nav class="top-nav">
        <div class="d-flex align-items-center justify-content-between">
            <a href="indexview.php" class="nav-brand">
                <div class="brand-icon">
                    <i class="fas fa-home"></i>
                </div>
                <div>
                    <div class="brand-text">Graceful<span>Living</span></div>
                    <span class="brand-sub">Girls Hostel</span>
                </div>
            </a>
            <div class="nav-links">
                <a href="indexview.php" class="nav-link">Home</a>
                <a href="viewrooms.php" class="nav-link">Rooms</a>
                <a href="payments.php" class="nav-link">Payments</a>
                <a href="mess_menu.php" class="nav-link">Mess Menu</a>
                <a href="contact.php" class="nav-link active">Contact</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="indexview.php" class="user-dropdown" data-bs-toggle="dropdown">
                        <div class="user-avatar"><?php echo substr($_SESSION['user_name'] ?? 'U', 0, 1); ?></div>
                        <span class="user-name"><?php echo $_SESSION['user_name'] ?? 'User'; ?></span>
                        <i class="fas fa-chevron-down" style="font-size:0.6rem; color: var(--text-muted);"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end">
                        <a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a>
                        <a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="auth-btn login">Login</a>
                    <a href="register.php" class="auth-btn register">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="hero-badge">
            <i class="fas fa-phone me-1"></i> Get in Touch
        </div>
        <h1>Contact <span class="highlight">Us</span></h1>
        <p>Have questions or want to book a visit? We'd love to hear from you!</p>
    </section>

    <!-- Main Content -->
    <div class="main-content">
        <div class="contact-grid">
            <!-- Contact Information -->
            <div>
                <div class="info-card">
                    <div class="card-title">
                        <i class="fas fa-info-circle"></i> Contact Information
                    </div>

                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="contact-content">
                            <div class="contact-label">Address</div>
                            <div class="contact-value">123 Hostel Road, City, State - 123456</div>
                        </div>
                    </div>

                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div class="contact-content">
                            <div class="contact-label">Phone</div>
                            <div class="contact-value">
                                <a href="tel:+919876543210">+91 98765 43210</a>
                            </div>
                        </div>
                    </div>

                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="contact-content">
                            <div class="contact-label">Email</div>
                            <div class="contact-value">
                                <a href="mailto:info@girlshostel.com">info@girlshostel.com</a>
                            </div>
                        </div>
                    </div>

                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="contact-content">
                            <div class="contact-label">Office Hours</div>
                            <div class="contact-value">Mon - Sat: 9:00 AM - 8:00 PM</div>
                        </div>
                    </div>

                    <div style="margin-top: 1.5rem;">
                        <div class="contact-label" style="font-size:0.65rem; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; color:var(--text-muted); margin-bottom:0.5rem;">Follow Us</div>
                        <div class="social-links">
                            <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>

                    <!-- Map -->
                    <div class="map-container">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2691.5424618871084!2d78.4500853101255!3d17.439799228976366!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb90c7b1c19745%3A0x2b372d7a718acfd4!2sflat%20no%2020%2C%20a%2F5%2C%207-1-11%2C%20Shivbagh%20Colony%20Road%2C%20ShivBagh%2C%20Balkampet%2C%20Hyderabad%2C%20Telangana%20500016!5e0!3m2!1sen!2sin!4v1782639896808!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div>
                <div class="form-card">
                    <div class="card-title">
                        <i class="fas fa-paper-plane"></i> Send a Message
                    </div>

                    <?php if ($success_message): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo $success_message; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($error_message): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="form-group">
                            <label>Your Name <span class="required">*</span></label>
                            <input type="text" class="form-control" name="name" placeholder="Enter your full name" 
                                   value="<?php echo htmlspecialchars($user_name ?? ''); ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Email Address <span class="required">*</span></label>
                            <input type="email" class="form-control" name="email" placeholder="Enter your email address" 
                                   value="<?php echo htmlspecialchars($user_email ?? ''); ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Subject <span class="required">*</span></label>
                            <select class="form-select" name="subject" required>
                                <option value="">Select a subject...</option>
                                <option value="general">General Inquiry</option>
                                <option value="booking">Room Booking</option>
                                <option value="visit">Book a Visit</option>
                                <option value="complaint">Complaint</option>
                                <option value="suggestion">Suggestion</option>
                                <option value="other">Other</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Message <span class="required">*</span></label>
                            <textarea class="form-control" name="message" placeholder="Write your message here..." required></textarea>
                        </div>

                        <button type="submit" class="btn-submit">
                            <i class="fas fa-paper-plane me-2"></i>Send Message
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; <?php echo date('Y'); ?> Graceful Living Girls Hostel. All rights reserved.</p>
        <div class="footer-links">
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
            <a href="terms.php">Terms</a>
            <a href="privacy.php">Privacy</a>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>